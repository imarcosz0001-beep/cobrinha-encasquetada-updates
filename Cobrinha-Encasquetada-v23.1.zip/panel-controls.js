(function () {
  "use strict";

  var STATE_KEY = "cobrinhaPanelStateV1";
  var GAP_KEY = "cobrinhaPanelGapV1";
  var TEAM_MODE_KEY = "cobrinhaTeamPanelMode";
  var TEAM_COMPACT_LAYOUT_KEY = "cobrinhaTeamCompactLayoutV1";
  var BOX_MODE_KEY = "cobrinhaBoxVisualMode";
  var MINIMAL_BG_ENABLED_KEY = "cobrinhaMinimalBackgroundEnabled";
  var MINIMAL_BG_COLOR_KEY = "cobrinhaMinimalBackgroundColor";
  var MINIMAL_BG_OPACITY_KEY = "cobrinhaMinimalBackgroundOpacity";
  var TECH_HUD_OPACITY_KEY = "cobrinhaTechHudOpacity";
  var TECH_HUD_SIZE_KEY = "cobrinhaTechHudSize";
  var state = loadState();
  var resizeObservers = {};
  var saveTimer = 0;

  function loadState() {
    try {
      var saved = JSON.parse(localStorage.getItem(STATE_KEY) || "{}");
      return saved && typeof saved === "object" ? saved : {};
    } catch (error) {
      return {};
    }
  }

  function saveStateSoon() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      try { localStorage.setItem(STATE_KEY, JSON.stringify(state)); } catch (error) {}
    }, 120);
  }

  function panelState(name) {
    if (!state[name]) state[name] = {};
    return state[name];
  }

  function updateButton(button, collapsed) {
    button.textContent = collapsed ? "+" : "−";
    button.title = collapsed ? "Expandir painel" : "Minimizar painel";
    button.setAttribute("aria-label", button.title);
  }

  function togglePanel(panel, name, button) {
    var saved = panelState(name);
    var collapsing = !panel.classList.contains("cobrinha-panel-collapsed");
    if (collapsing) {
      saved.width = Math.round(panel.getBoundingClientRect().width) + "px";
      saved.height = Math.round(panel.getBoundingClientRect().height) + "px";
    }
    saved.collapsed = collapsing;
    panel.classList.toggle("cobrinha-panel-collapsed", collapsing);
    if (!collapsing) {
      if (saved.width) panel.style.width = saved.width;
      if (saved.height) panel.style.height = saved.height;
    }
    updateButton(button, collapsing);
    saveStateSoon();
  }

  function observeSize(panel, name) {
    if (typeof ResizeObserver !== "function") return;
    if (resizeObservers[name] && resizeObservers[name].panel === panel) return;
    if (resizeObservers[name]) resizeObservers[name].observer.disconnect();
    var observer = new ResizeObserver(function () {
      if (panel.classList.contains("cobrinha-panel-collapsed")) return;
      if (name === "team" && panel.classList.contains("cobrinha-team-minimal")) return;
      var rect = panel.getBoundingClientRect();
      if (rect.width < 1 || rect.height < 1) return;
      var saved = panelState(name);
      saved.width = Math.round(rect.width) + "px";
      saved.height = Math.round(rect.height) + "px";
      saveStateSoon();
    });
    resizeObservers[name] = { panel: panel, observer: observer };
    observer.observe(panel);
  }

  function applySavedPanelState(panel, name) {
    if (panel.dataset.cobrinhaPanelState === "1") return;
    panel.dataset.cobrinhaPanelState = "1";
    var saved = panelState(name);
    if (saved.width) panel.style.width = saved.width;
    if (saved.height && !saved.collapsed) panel.style.height = saved.height;
    if (saved.left != null && saved.top != null) {
      panel.style.left = saved.left;
      panel.style.top = saved.top;
      panel.style.right = "auto";
      panel.style.bottom = "auto";
    }
    panel.style.setProperty("--cobrinha-panel-opacity", String(saved.opacity == null ? 1 : saved.opacity));
    panel.classList.toggle("cobrinha-panel-collapsed", saved.collapsed === true);
    observeSize(panel, name);
  }

  function makeToggle(panel, name) {
    var button = panel.querySelector(":scope > .cobrinha-panel-toggle");
    if (!button) {
      button = document.createElement("button");
      button.type = "button";
      button.className = "cobrinha-panel-toggle";
      button.addEventListener("mousedown", function (event) {
        event.preventDefault();
        event.stopPropagation();
      });
      button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        togglePanel(panel, name, button);
      });
      panel.appendChild(button);
    }
    updateButton(button, panel.classList.contains("cobrinha-panel-collapsed"));
  }

  function makeOpacityControl(panel, name) {
    var input = panel.querySelector(":scope > .cobrinha-panel-opacity");
    var saved = panelState(name);
    if (!input) {
      input = document.createElement("input");
      input.type = "range";
      input.className = "cobrinha-panel-opacity";
      input.min = "0.3";
      input.max = "1";
      input.step = "0.05";
      input.title = "Opacidade do painel";
      input.setAttribute("aria-label", input.title);
      input.addEventListener("pointerdown", function (event) { event.stopPropagation(); });
      input.addEventListener("mousedown", function (event) { event.stopPropagation(); });
      input.addEventListener("click", function (event) { event.stopPropagation(); });
      input.addEventListener("input", function (event) {
        event.stopPropagation();
        var opacity = Math.max(0.3, Math.min(1, Number(input.value) || 1));
        panel.style.setProperty("--cobrinha-panel-opacity", String(opacity));
        panelState(name).opacity = opacity;
        saveStateSoon();
        window.dispatchEvent(new CustomEvent("cobrinha-panel-opacity-changed", { detail: { name: name, opacity: opacity } }));
      });
      panel.appendChild(input);
    }
    input.value = String(saved.opacity == null ? 1 : saved.opacity);
  }

  function savePanelPosition(panel, name) {
    var saved = panelState(name);
    saved.left = panel.style.left;
    saved.top = panel.style.top;
    saveStateSoon();
    if (name === "shortcuts" || name === "chat") {
      try {
        var info = JSON.parse(localStorage.getItem("infobox") || "{}");
        if (!info || typeof info !== "object") info = {};
        var key = name === "shortcuts" ? "eemenu" : "bchat";
        if (!info[key]) info[key] = {};
        info[key].left = panel.style.left;
        info[key].top = panel.style.top;
        info[key].right = "";
        info[key].bottom = "";
        localStorage.setItem("infobox", JSON.stringify(info));
      } catch (error) {}
    }
  }

  function enableDrag(panel, name, handle) {
    if (!handle || handle.dataset.cobrinhaDrag === "1") return;
    handle.dataset.cobrinhaDrag = "1";
    handle.addEventListener("pointerdown", function (event) {
      if (event.button !== 0 || event.target.closest && event.target.closest("button, input")) return;
      event.preventDefault();
      event.stopPropagation();
      var rect = panel.getBoundingClientRect();
      var offsetX = event.clientX - rect.left;
      var offsetY = event.clientY - rect.top;
      panel.style.left = Math.round(rect.left) + "px";
      panel.style.top = Math.round(rect.top) + "px";
      panel.style.right = "auto";
      panel.style.bottom = "auto";
      panel.classList.add("cobrinha-panel-dragging");

      function move(moveEvent) {
        moveEvent.preventDefault();
        moveEvent.stopPropagation();
        var maxLeft = Math.max(0, window.innerWidth - panel.offsetWidth);
        var maxTop = Math.max(0, window.innerHeight - panel.offsetHeight);
        var left = Math.max(0, Math.min(maxLeft, moveEvent.clientX - offsetX));
        var top = Math.max(0, Math.min(maxTop, moveEvent.clientY - offsetY));
        panel.style.left = Math.round(left) + "px";
        panel.style.top = Math.round(top) + "px";
      }

      function finish(finishEvent) {
        if (finishEvent) finishEvent.stopPropagation();
        document.removeEventListener("pointermove", move, true);
        document.removeEventListener("pointerup", finish, true);
        document.removeEventListener("pointercancel", finish, true);
        panel.classList.remove("cobrinha-panel-dragging");
        savePanelPosition(panel, name);
      }

      document.addEventListener("pointermove", move, true);
      document.addEventListener("pointerup", finish, true);
      document.addEventListener("pointercancel", finish, true);
    });
  }

  function makeDragHandle(panel, name) {
    var handle = panel.querySelector(":scope > .cobrinha-panel-drag-handle");
    if (!handle) {
      handle = document.createElement("div");
      handle.className = "cobrinha-panel-drag-handle";
      handle.title = "Arraste para mover o painel";
      panel.appendChild(handle);
    }
    enableDrag(panel, name, handle);
  }

  function prepareShortcutPanel() {
    var panel = document.getElementById("eemenu");
    if (!panel) return false;
    separateShortcutRows(panel);
    applySavedPanelState(panel, "shortcuts");
    makeToggle(panel, "shortcuts");
    makeOpacityControl(panel, "shortcuts");
    makeDragHandle(panel, "shortcuts");
    return true;
  }

  function separateShortcutRows(panel) {
    Array.prototype.forEach.call(panel.querySelectorAll(".eem"), function (key, index) {
      if (index === 0) return;
      var before = key.previousSibling;
      if (!before || before.nodeType !== 3) return;
      var text = before.nodeValue || "";
      var bracket = text.lastIndexOf("[");
      if (bracket < 0) return;
      var previous = before.previousSibling;
      if (text === "[" && previous && previous.nodeName === "BR") return;
      before.nodeValue = text.slice(0, bracket).replace(/[ \t]+$/, "");
      var line = document.createElement("br");
      line.className = "cobrinha-shortcut-line";
      key.parentNode.insertBefore(line, key);
      key.parentNode.insertBefore(document.createTextNode("["), key);
    });
  }

  function prepareChatPanel() {
    var panel = document.getElementById("bchat");
    if (!panel) return false;
    applySavedPanelState(panel, "chat");
    var bar = panel.querySelector(":scope > .cobrinha-chat-bar");
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "cobrinha-chat-bar";
      bar.textContent = "Mensagens e informações";
      panel.insertBefore(bar, panel.firstChild);
    }
    makeChatExitButton(panel);
    makeToggle(panel, "chat");
    makeOpacityControl(panel, "chat");
    enableDrag(panel, "chat", bar);
    return true;
  }

  function releaseChatFocus() {
    var input = document.getElementById("ichat");
    if (!input) return;
    try {
      if (window.jQuery && jQuery.data(input, "emojiPicker")) jQuery(input).emojiPicker("hide");
    } catch (error) {}
    try { input.blur(); } catch (error) {}
    setTimeout(function () {
      try { input.blur(); } catch (error) {}
      try { window.focus(); } catch (error) {}
    }, 0);
  }

  function makeChatExitButton(panel) {
    var button = panel.querySelector(":scope > .cobrinha-chat-exit");
    if (button) return;
    button = document.createElement("button");
    button.type = "button";
    button.className = "cobrinha-chat-exit";
    button.textContent = "Sair";
    button.title = "Sair do chat e devolver as teclas ao jogo";
    button.setAttribute("aria-label", button.title);
    button.addEventListener("pointerdown", function (event) {
      event.preventDefault();
      event.stopPropagation();
    });
    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      releaseChatFocus();
    });
    panel.appendChild(button);
  }

  function prepareTeamPanel() {
    var panel = document.getElementById("lovable-team-panel");
    if (!panel) return false;
    try {
      if (localStorage.getItem(TEAM_COMPACT_LAYOUT_KEY) !== "1") {
        delete panelState("team").width;
        delete panelState("team").height;
        localStorage.setItem(TEAM_COMPACT_LAYOUT_KEY, "1");
        saveStateSoon();
      }
    } catch (error) {}
    applySavedPanelState(panel, "team");
    applyTeamPanelMode(panel);
    makeToggle(panel, "team");
    makeOpacityControl(panel, "team");
    enableDrag(panel, "team", panel.querySelector(":scope > .lovable-team-title"));
    return true;
  }

  function currentTeamPanelMode() {
    try { return localStorage.getItem(TEAM_MODE_KEY) === "minimal" ? "minimal" : "full"; }
    catch (error) { return "full"; }
  }

  function currentBoxVisualMode() {
    try { return localStorage.getItem(BOX_MODE_KEY) === "minimal" ? "minimal" : "standard"; }
    catch (error) { return "standard"; }
  }

  function applyBoxVisualMode() {
    document.documentElement.classList.toggle("cobrinha-boxes-minimal", currentBoxVisualMode() === "minimal");
  }

  function minimalBackgroundSettings() {
    var enabled = false;
    var color = "#000000";
    var opacity = 0.15;
    try {
      enabled = localStorage.getItem(MINIMAL_BG_ENABLED_KEY) === "1";
      var savedColor = localStorage.getItem(MINIMAL_BG_COLOR_KEY);
      var savedOpacityValue = localStorage.getItem(MINIMAL_BG_OPACITY_KEY);
      var savedOpacity = Number(savedOpacityValue);
      if (/^#[0-9a-f]{6}$/i.test(savedColor || "")) color = savedColor;
      if (savedOpacityValue != null && Number.isFinite(savedOpacity)) opacity = Math.max(0, Math.min(1, savedOpacity));
    } catch (error) {}
    return { enabled: enabled, color: color, opacity: opacity };
  }

  function backgroundRgba(color, opacity) {
    var value = String(color || "#000000").replace("#", "");
    if (!/^[0-9a-f]{6}$/i.test(value)) value = "000000";
    return "rgba(" + parseInt(value.slice(0, 2), 16) + ", " + parseInt(value.slice(2, 4), 16) + ", " + parseInt(value.slice(4, 6), 16) + ", " + opacity + ")";
  }

  function applyMinimalBackground() {
    var settings = minimalBackgroundSettings();
    document.documentElement.classList.toggle("cobrinha-minimal-background", settings.enabled);
    document.documentElement.style.setProperty("--cobrinha-minimal-panel-bg", backgroundRgba(settings.color, settings.opacity));
  }

  function technicalHudSettings() {
    var opacity = 1;
    var size = 13;
    try {
      var savedOpacity = localStorage.getItem(TECH_HUD_OPACITY_KEY);
      var savedSize = localStorage.getItem(TECH_HUD_SIZE_KEY);
      if (savedOpacity != null && Number.isFinite(Number(savedOpacity))) opacity = Math.max(0, Math.min(1, Number(savedOpacity)));
      if (savedSize != null && Number.isFinite(Number(savedSize))) size = Math.max(8, Math.min(24, Number(savedSize)));
    } catch (error) {}
    return { opacity: opacity, size: size };
  }

  function applyTechnicalHud() {
    var settings = technicalHudSettings();
    document.documentElement.style.setProperty("--cobrinha-tech-hud-opacity", String(settings.opacity));
    document.documentElement.style.setProperty("--cobrinha-tech-hud-size", settings.size + "px");
  }

  function applyTeamPanelMode(panel) {
    panel = panel || document.getElementById("lovable-team-panel");
    if (!panel) return;
    panel.classList.toggle("cobrinha-team-minimal", currentTeamPanelMode() === "minimal");
  }

  function applyPanelGap() {
    try { if (localStorage.getItem(GAP_KEY) === "1") return true; } catch (error) {}
    var shortcuts = document.getElementById("eemenu");
    var chat = document.getElementById("bchat");
    if (!shortcuts || !chat) return false;

    var shortcutTop = parseFloat(shortcuts.style.top) || 4;
    var shortcutHeight = shortcuts.offsetHeight || parseFloat(shortcuts.style.height) || 215;
    var chatTop = parseFloat(chat.style.top) || 220;
    var requiredChatTop = shortcutTop + shortcutHeight + 12;
    if (chatTop < requiredChatTop) {
      chatTop = requiredChatTop;
      chat.style.top = Math.round(chatTop) + "px";
    }

    var details = document.getElementById("divtl");
    if (details) {
      var chatHeight = chat.offsetHeight || parseFloat(chat.style.height) || 230;
      var detailsTop = parseFloat(details.style.top) || 450;
      var requiredDetailsTop = chatTop + chatHeight + 12;
      if (detailsTop < requiredDetailsTop) details.style.top = Math.round(requiredDetailsTop) + "px";
    }

    try {
      var info = JSON.parse(localStorage.getItem("infobox") || "{}");
      if (!info || typeof info !== "object") info = {};
      if (!info.bchat) info.bchat = {};
      info.bchat.top = chat.style.top;
      if (details) {
        if (!info.divtl) info.divtl = {};
        info.divtl.top = details.style.top;
      }
      localStorage.setItem("infobox", JSON.stringify(info));
      localStorage.setItem(GAP_KEY, "1");
    } catch (error) {}
    return true;
  }

  function prepareAll() {
    var shortcutsReady = prepareShortcutPanel();
    var chatReady = prepareChatPanel();
    prepareTeamPanel();
    if (shortcutsReady && chatReady) applyPanelGap();
    return shortcutsReady && chatReady;
  }

  function defaultWindowLayout() {
    var viewportWidth = Math.max(640, window.innerWidth || document.documentElement.clientWidth || 1280);
    var viewportHeight = Math.max(600, window.innerHeight || document.documentElement.clientHeight || 720);
    var shortcutsTop = Math.round(Math.max(84, Math.min(132, viewportHeight * 0.146)));
    var shortcutsHeight = Math.round(Math.max(170, Math.min(238, viewportHeight * 0.263)));
    var groupGap = Math.round(Math.max(34, Math.min(70, viewportHeight * 0.0775)));
    var chatTop = shortcutsTop + shortcutsHeight + groupGap;
    var chatHeight = Math.round(Math.max(190, Math.min(254, viewportHeight * 0.281)));
    var teamWidth = 195;
    var teamTop = Math.round(Math.max(150, Math.min(230, viewportHeight * 0.255)));
    return {
      panels: {
        shortcuts: { left: "0px", top: shortcutsTop + "px", width: "300px", height: shortcutsHeight + "px", opacity: 1, collapsed: false },
        chat: { left: "0px", top: chatTop + "px", width: "300px", height: chatHeight + "px", opacity: 1, collapsed: false },
        team: { left: Math.max(0, viewportWidth - teamWidth - 4) + "px", top: teamTop + "px", width: teamWidth + "px", opacity: 1, collapsed: false }
      },
      infobox: {
        eemenu: { left: "0px", top: shortcutsTop + "px", right: "", bottom: "", width: "300px", height: shortcutsHeight + "px" },
        bchat: { left: "0px", top: chatTop + "px", right: "", bottom: "", width: "300px", height: chatHeight + "px" },
        mgraph: { left: "0px", right: "", top: "", bottom: "40px", width: "545px", height: "110px" }
      },
      native: {
        minimap: { position: "fixed", left: "auto", top: "auto", right: "16px", bottom: "16px", width: "104px", height: "104px" }
      }
    };
  }

  window.cobrinhaGetDefaultWindowLayout = defaultWindowLayout;

  window.addEventListener("cobrinha-apply-default-panel-layout", function (event) {
    var name = event.detail && event.detail.name;
    var defaults = defaultWindowLayout();
    var placement = defaults.panels && defaults.panels[name];
    if (!placement) return;
    var saved = panelState(name);
    ["left", "top", "width", "height"].forEach(function (property) {
      saved[property] = placement[property];
    });
    clearTimeout(saveTimer);
    try { localStorage.setItem(STATE_KEY, JSON.stringify(state)); } catch (error) {}
  });

  function resetWindowLayout() {
    clearTimeout(saveTimer);
    var defaults = defaultWindowLayout();
    state = defaults.panels;
    Object.keys(resizeObservers).forEach(function (name) {
      resizeObservers[name].observer.disconnect();
    });
    resizeObservers = {};
    try {
      localStorage.setItem(STATE_KEY, JSON.stringify(state));
      localStorage.setItem(GAP_KEY, "1");
      localStorage.setItem("cobrinhaGraphVisible", "1");
      localStorage.removeItem("cobrinhaInterfaceStudioV1");
      localStorage.removeItem("cobrinhaInterfaceProfile");
      localStorage.removeItem("cobrinhaInterfaceCustomProfileV1");
      localStorage.setItem("infobox", JSON.stringify(defaults.infobox));
    } catch (error) {}
    location.reload();
  }

  function createLayoutResetControl() {
    if (!document.body || document.getElementById("cobrinha-layout-gear")) return;

    var gear = document.createElement("button");
    gear.id = "cobrinha-layout-gear";
    gear.type = "button";
    gear.textContent = "⚙";
    gear.title = "Ajustar janelas";
    gear.setAttribute("aria-label", gear.title);

    var popup = document.createElement("section");
    popup.id = "cobrinha-layout-popup";
    popup.hidden = true;
    popup.setAttribute("role", "dialog");
    popup.setAttribute("aria-label", "Ajustes das janelas");

    var title = document.createElement("strong");
    title.textContent = "Janelas da interface";
    var description = document.createElement("p");
    description.textContent = "Escolha o visual dos painéis ou restaure seus tamanhos e posições.";

    var boxMode = document.createElement("label");
    boxMode.className = "cobrinha-layout-team-mode";
    var boxModeText = document.createElement("span");
    boxModeText.textContent = "Todos os painéis";
    var boxModeSelect = document.createElement("select");
    var standardBoxOption = document.createElement("option");
    standardBoxOption.value = "standard";
    standardBoxOption.textContent = "Padrão";
    var minimalBoxOption = document.createElement("option");
    minimalBoxOption.value = "minimal";
    minimalBoxOption.textContent = "Minimalista";
    boxModeSelect.appendChild(standardBoxOption);
    boxModeSelect.appendChild(minimalBoxOption);
    boxModeSelect.value = currentBoxVisualMode();
    boxMode.appendChild(boxModeText);
    boxMode.appendChild(boxModeSelect);

    var teamMode = document.createElement("label");
    teamMode.className = "cobrinha-layout-team-mode";
    var teamModeText = document.createElement("span");
    teamModeText.textContent = "Equipe — sala";
    var teamModeSelect = document.createElement("select");
    var fullOption = document.createElement("option");
    fullOption.value = "full";
    fullOption.textContent = "Completa";
    var minimalOption = document.createElement("option");
    minimalOption.value = "minimal";
    minimalOption.textContent = "Minimalista";
    teamModeSelect.appendChild(fullOption);
    teamModeSelect.appendChild(minimalOption);
    teamModeSelect.value = currentTeamPanelMode();
    teamMode.appendChild(teamModeText);
    teamMode.appendChild(teamModeSelect);

    var minimalBackground = document.createElement("div");
    minimalBackground.className = "cobrinha-layout-background";
    var backgroundToggleLabel = document.createElement("label");
    backgroundToggleLabel.className = "cobrinha-layout-background-toggle";
    var backgroundToggle = document.createElement("input");
    backgroundToggle.type = "checkbox";
    var backgroundToggleText = document.createElement("span");
    backgroundToggleText.textContent = "Fundo no minimalista";
    backgroundToggleLabel.appendChild(backgroundToggle);
    backgroundToggleLabel.appendChild(backgroundToggleText);
    var backgroundControls = document.createElement("div");
    backgroundControls.className = "cobrinha-layout-background-controls";
    var colorLabel = document.createElement("label");
    colorLabel.textContent = "Cor";
    var colorInput = document.createElement("input");
    colorInput.type = "color";
    colorLabel.appendChild(colorInput);
    var opacityLabel = document.createElement("label");
    opacityLabel.className = "cobrinha-layout-background-opacity";
    var opacityText = document.createElement("span");
    opacityText.textContent = "Opacidade";
    var opacityNumber = document.createElement("input");
    opacityNumber.type = "number";
    opacityNumber.min = "0";
    opacityNumber.max = "100";
    opacityNumber.step = "1";
    opacityNumber.inputMode = "numeric";
    opacityNumber.setAttribute("aria-label", "Opacidade do fundo em porcentagem");
    var opacityInput = document.createElement("input");
    opacityInput.type = "range";
    opacityInput.min = "0";
    opacityInput.max = "100";
    opacityInput.step = "1";
    opacityLabel.appendChild(opacityText);
    opacityLabel.appendChild(opacityNumber);
    opacityLabel.appendChild(opacityInput);
    backgroundControls.appendChild(colorLabel);
    backgroundControls.appendChild(opacityLabel);
    minimalBackground.appendChild(backgroundToggleLabel);
    minimalBackground.appendChild(backgroundControls);

    var savedBackground = minimalBackgroundSettings();
    backgroundToggle.checked = savedBackground.enabled;
    colorInput.value = savedBackground.color;
    opacityInput.value = String(Math.round(savedBackground.opacity * 100));
    opacityNumber.value = opacityInput.value;
    backgroundControls.classList.toggle("is-disabled", !savedBackground.enabled);

    var technicalHud = document.createElement("div");
    technicalHud.className = "cobrinha-layout-tech";
    var technicalTitle = document.createElement("strong");
    technicalTitle.textContent = "Informações técnicas";
    technicalHud.appendChild(technicalTitle);
    var savedTechnical = technicalHudSettings();

    function createTechnicalControl(labelText, min, max, value, suffix, idPrefix) {
      var label = document.createElement("label");
      var text = document.createElement("span");
      text.textContent = labelText;
      var number = document.createElement("input");
      number.type = "number";
      number.min = String(min);
      number.max = String(max);
      number.step = "1";
      number.value = String(value);
      number.title = suffix;
      number.id = idPrefix + "-number";
      var range = document.createElement("input");
      range.type = "range";
      range.min = String(min);
      range.max = String(max);
      range.step = "1";
      range.value = String(value);
      range.id = idPrefix + "-range";
      label.appendChild(text);
      label.appendChild(number);
      label.appendChild(range);
      technicalHud.appendChild(label);
      return { number: number, range: range };
    }

    var technicalOpacity = createTechnicalControl("Opacidade (%)", 0, 100, Math.round(savedTechnical.opacity * 100), "%", "cobrinha-tech-opacity");
    var technicalSize = createTechnicalControl("Tamanho (px)", 8, 24, savedTechnical.size, "px", "cobrinha-tech-size");

    var reset = document.createElement("button");
    reset.type = "button";
    reset.className = "cobrinha-layout-reset";
    reset.textContent = "Redefinir janelas";

    var confirmation = document.createElement("div");
    confirmation.className = "cobrinha-layout-confirmation";
    confirmation.hidden = true;
    var question = document.createElement("span");
    question.textContent = "Confirmar redefinição?";
    var actions = document.createElement("div");
    var cancel = document.createElement("button");
    cancel.type = "button";
    cancel.textContent = "Cancelar";
    var confirm = document.createElement("button");
    confirm.type = "button";
    confirm.className = "is-confirm";
    confirm.textContent = "Confirmar";
    actions.appendChild(cancel);
    actions.appendChild(confirm);
    confirmation.appendChild(question);
    confirmation.appendChild(actions);

    popup.appendChild(title);
    popup.appendChild(description);
    popup.appendChild(boxMode);
    popup.appendChild(teamMode);
    popup.appendChild(minimalBackground);
    popup.appendChild(technicalHud);
    popup.appendChild(reset);
    popup.appendChild(confirmation);
    document.body.appendChild(popup);
    document.body.appendChild(gear);

    gear.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      boxModeSelect.value = currentBoxVisualMode();
      teamModeSelect.value = currentTeamPanelMode();
      savedBackground = minimalBackgroundSettings();
      backgroundToggle.checked = savedBackground.enabled;
      colorInput.value = savedBackground.color;
      opacityInput.value = String(Math.round(savedBackground.opacity * 100));
      opacityNumber.value = opacityInput.value;
      backgroundControls.classList.toggle("is-disabled", !savedBackground.enabled);
      popup.hidden = !popup.hidden;
      confirmation.hidden = true;
      reset.hidden = false;
    });
    popup.addEventListener("click", function (event) { event.stopPropagation(); });
    boxModeSelect.addEventListener("change", function () {
      try { localStorage.setItem(BOX_MODE_KEY, boxModeSelect.value === "minimal" ? "minimal" : "standard"); } catch (error) {}
      applyBoxVisualMode();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    });
    teamModeSelect.addEventListener("change", function () {
      try { localStorage.setItem(TEAM_MODE_KEY, teamModeSelect.value === "minimal" ? "minimal" : "full"); } catch (error) {}
      applyTeamPanelMode();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    });
    backgroundToggle.addEventListener("change", function () {
      try { localStorage.setItem(MINIMAL_BG_ENABLED_KEY, backgroundToggle.checked ? "1" : "0"); } catch (error) {}
      backgroundControls.classList.toggle("is-disabled", !backgroundToggle.checked);
      applyMinimalBackground();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    });
    colorInput.addEventListener("input", function () {
      try { localStorage.setItem(MINIMAL_BG_COLOR_KEY, colorInput.value); } catch (error) {}
      applyMinimalBackground();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    });
    function updateBackgroundOpacity(value) {
      var percentage = Number(value);
      if (!Number.isFinite(percentage)) return;
      percentage = Math.max(0, Math.min(100, percentage));
      opacityInput.value = String(percentage);
      opacityNumber.value = String(percentage);
      try { localStorage.setItem(MINIMAL_BG_OPACITY_KEY, String(percentage / 100)); } catch (error) {}
      applyMinimalBackground();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    }
    opacityInput.addEventListener("input", function () {
      updateBackgroundOpacity(opacityInput.value);
    });
    opacityNumber.addEventListener("input", function () {
      if (opacityNumber.value !== "") updateBackgroundOpacity(opacityNumber.value);
    });
    opacityNumber.addEventListener("change", function () {
      updateBackgroundOpacity(opacityNumber.value === "" ? opacityInput.value : opacityNumber.value);
    });
    function bindTechnicalControl(control, min, max, storageKey, convert) {
      function update(value) {
        var number = Number(value);
        if (!Number.isFinite(number)) return;
        number = Math.max(min, Math.min(max, number));
        control.range.value = String(number);
        control.number.value = String(number);
        try { localStorage.setItem(storageKey, String(convert(number))); } catch (error) {}
        applyTechnicalHud();
        window.dispatchEvent(new CustomEvent("cobrinha-tech-hud-changed", { detail: { opacity: technicalOpacity.number.value, size: technicalSize.number.value } }));
      }
      control.range.addEventListener("input", function () { update(control.range.value); });
      control.number.addEventListener("input", function () {
        if (control.number.value !== "") update(control.number.value);
      });
      control.number.addEventListener("change", function () {
        update(control.number.value === "" ? control.range.value : control.number.value);
      });
    }
    bindTechnicalControl(technicalOpacity, 0, 100, TECH_HUD_OPACITY_KEY, function (value) { return value / 100; });
    bindTechnicalControl(technicalSize, 8, 24, TECH_HUD_SIZE_KEY, function (value) { return value; });
    reset.addEventListener("click", function () {
      reset.hidden = true;
      confirmation.hidden = false;
    });
    cancel.addEventListener("click", function () {
      confirmation.hidden = true;
      reset.hidden = false;
    });
    confirm.addEventListener("click", resetWindowLayout);
    document.addEventListener("click", function () {
      popup.hidden = true;
      confirmation.hidden = true;
      reset.hidden = false;
    });
  }

  function updateLayoutResetVisibility() {
    createLayoutResetControl();
    var gear = document.getElementById("cobrinha-layout-gear");
    var popup = document.getElementById("cobrinha-layout-popup");
    var login = document.getElementById("login");
    if (!gear) return;
    var visible = false;
    if (login) {
      var style = getComputedStyle(login);
      var rect = login.getBoundingClientRect();
      visible = style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0.05 && rect.width > 0 && rect.height > 0;
    }
    gear.hidden = !visible;
    if (!visible && popup) popup.hidden = true;
  }

  new MutationObserver(function (changes) {
    var relevant = changes.some(function (change) {
      return change.target && (change.target.id === "eemenu" || change.target.id === "bchat" || change.target.id === "lovable-team-panel") ||
        Array.prototype.some.call(change.addedNodes || [], function (node) {
          return node.nodeType === 1 && (node.id === "eemenu" || node.id === "bchat" || node.id === "lovable-team-panel" || node.querySelector && node.querySelector("#eemenu, #bchat, #lovable-team-panel"));
        });
    });
    if (relevant) setTimeout(prepareAll, 0);
  }).observe(document.documentElement, { childList: true, subtree: true });

  document.addEventListener("keydown", function (event) {
    var input = document.getElementById("ichat");
    if (input && document.activeElement === input && event.key === "Escape") {
      event.preventDefault();
      event.stopImmediatePropagation();
      releaseChatFocus();
    }
  }, true);

  document.addEventListener("pointerdown", function (event) {
    var input = document.getElementById("ichat");
    var chat = document.getElementById("bchat");
    if (input && chat && document.activeElement === input && !chat.contains(event.target)) releaseChatFocus();
  }, true);

  var attempts = 0;
  var timer = setInterval(function () {
    if (prepareAll() || ++attempts > 240) clearInterval(timer);
  }, 50);

  applyBoxVisualMode();
  applyMinimalBackground();
  applyTechnicalHud();
  updateLayoutResetVisibility();
  setInterval(updateLayoutResetVisibility, 300);
})();
