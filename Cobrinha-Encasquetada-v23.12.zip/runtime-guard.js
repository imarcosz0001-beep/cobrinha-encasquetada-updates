(function () {
  "use strict";
  if (window.CobrinhaRuntime) return;

  var VERSION = chrome.runtime.getManifest().version;
  var BOOT_KEY = "cobrinhaRuntimeBootV1";
  var FAILURE_KEY = "cobrinhaRuntimeFailuresV1";
  var SAFE_KEY = "cobrinhaSafeModeV1";
  var LAST_GOOD_KEY = "cobrinhaLastKnownGoodV1";
  var ERROR_KEY = "cobrinhaRuntimeErrorsV1";
  var startedAt = Date.now();
  var healthy = false;
  var lastGoodTimer = 0;
  var previous = readJson(sessionStorage, BOOT_KEY, {});
  var failures = Math.max(0, Number(localStorage.getItem(FAILURE_KEY)) || 0);
  var previousAge = startedAt - (Number(previous.startedAt) || 0);

  if (previous.status === "starting" && previous.version === VERSION && previousAge > 1500 && previousAge < 600000) {
    failures += 1;
    localStorage.setItem(FAILURE_KEY, String(failures));
  }

  var forced = localStorage.getItem(SAFE_KEY) === "1" || /(?:\?|&)cobrinha-safe=1(?:&|$)/.test(location.search);
  var safeMode = forced || failures >= 2;
  sessionStorage.setItem(BOOT_KEY, JSON.stringify({ version: VERSION, status: "starting", startedAt: startedAt }));
  document.documentElement.dataset.cobrinhaSafeMode = safeMode ? "1" : "0";

  function readJson(store, key, fallback) {
    try {
      var value = JSON.parse(store.getItem(key) || "null");
      return value && typeof value === "object" ? value : fallback;
    } catch (error) { return fallback; }
  }

  function rememberError(detail) {
    var errors = readJson(localStorage, ERROR_KEY, []);
    if (!Array.isArray(errors)) errors = [];
    errors.push({
      module: String(detail && detail.module || "runtime").slice(0, 40),
      message: String(detail && detail.message || "Erro desconhecido").slice(0, 300),
      time: new Date().toISOString()
    });
    localStorage.setItem(ERROR_KEY, JSON.stringify(errors.slice(-20)));
  }

  function layoutSnapshot() {
    var keys = [
      "cobrinhaInterfaceStateV2", "cobrinhaInterfaceStudioV1", "cobrinhaPanelStateV1",
      "cobrinhaInterfaceProfile", "cobrinhaInterfaceCustomProfileV1", "cobrinhaBoxVisualMode",
      "cobrinhaTeamPanelMode", "cobrinhaMinimalBackgroundEnabled", "cobrinhaMinimalBackgroundColor",
      "cobrinhaMinimalBackgroundOpacity", "cobrinhaTechHudOpacity", "cobrinhaTechHudSize",
      "cobrinhaPanelGapV1", "cobrinhaGraphVisible", "cobrinhaFriendPrivacyV1", "cobrinhaFriendArrowSettingsV1"
    ];
    var values = {};
    keys.forEach(function (key) {
      var value = localStorage.getItem(key);
      if (value != null) values[key] = value;
    });
    return { version: VERSION, savedAt: new Date().toISOString(), values: values };
  }

  function saveLastGood() {
    if (!safeMode) localStorage.setItem(LAST_GOOD_KEY, JSON.stringify(layoutSnapshot()));
  }

  function restoreLastGood() {
    var snapshot = readJson(localStorage, LAST_GOOD_KEY, null);
    if (!snapshot || !snapshot.values) return false;
    Object.keys(snapshot.values).forEach(function (key) { localStorage.setItem(key, String(snapshot.values[key])); });
    localStorage.removeItem(SAFE_KEY);
    localStorage.setItem(FAILURE_KEY, "0");
    sessionStorage.removeItem(BOOT_KEY);
    location.reload();
    return true;
  }

  function enterSafeMode() {
    localStorage.setItem(SAFE_KEY, "1");
    sessionStorage.removeItem(BOOT_KEY);
    location.reload();
  }

  function exitSafeMode() {
    localStorage.removeItem(SAFE_KEY);
    localStorage.setItem(FAILURE_KEY, "0");
    sessionStorage.removeItem(BOOT_KEY);
    location.reload();
  }

  function runSmokeTest() {
    var onboarding = document.getElementById("cobrinha-onboarding");
    var selectedProfile = onboarding && onboarding.querySelector("[data-profile].is-selected");
    var canonical = window.CobrinhaInterfaceState && window.CobrinhaInterfaceState.snapshot();
    var positionsValid = true;
    if (canonical && canonical.studio && canonical.studio.elements) {
      Object.keys(canonical.studio.elements).forEach(function (id) {
        var positions = canonical.studio.elements[id] && canonical.studio.elements[id].positions;
        if (!Array.isArray(positions)) return;
        positions.forEach(function (position) {
          if (!position || !Number.isFinite(Number(position.left)) || !Number.isFinite(Number(position.top))) positionsValid = false;
        });
      });
    }
    var checks = {
      document: Boolean(document.documentElement && document.body),
      scheduler: Boolean(window.CobrinhaScheduler && window.CobrinhaScheduler.every),
      interfaceState: Boolean(window.CobrinhaInterfaceState && window.CobrinhaInterfaceState.snapshot),
      menu: Boolean(document.getElementById("login")),
      panelControls: safeMode || window.cobrinhaPanelControlsReady === true,
      interfaceStudio: safeMode || window.cobrinhaInterfaceStudioReady === true,
      onboardingSelection: !onboarding || Boolean(selectedProfile && selectedProfile.getAttribute("aria-checked") === "true"),
      positionsValid: positionsValid,
      finiteViewport: Number.isFinite(window.innerWidth) && Number.isFinite(window.innerHeight),
      safeMode: safeMode
    };
    checks.ok = checks.document && checks.scheduler && checks.interfaceState && checks.panelControls && checks.interfaceStudio && checks.onboardingSelection && checks.positionsValid && checks.finiteViewport;
    try { localStorage.setItem("cobrinhaLastSmokeTestV1", JSON.stringify({ checkedAt: new Date().toISOString(), checks: checks })); } catch (error) {}
    return checks;
  }

  function markHealthy() {
    var smoke = runSmokeTest();
    if (!smoke.ok) return false;
    sessionStorage.setItem(BOOT_KEY, JSON.stringify({ version: VERSION, status: "healthy", startedAt: startedAt, healthyAt: Date.now() }));
    localStorage.setItem(FAILURE_KEY, "0");
    healthy = true;
    saveLastGood();
    return true;
  }

  function createRecoveryBanner() {
    if (!safeMode || !document.body || document.getElementById("cobrinha-safe-mode-banner")) return;
    var banner = document.createElement("aside");
    banner.id = "cobrinha-safe-mode-banner";
    banner.setAttribute("role", "alert");
    banner.innerHTML = '<strong>Modo seguro ativo</strong><span>Os módulos opcionais foram pausados após falhas de inicialização.</span><div><button type="button" data-action="restore">Restaurar última interface funcional</button><button type="button" data-action="diagnostic">Copiar diagnóstico</button><button type="button" data-action="exit">Tentar inicialização normal</button></div>';
    banner.querySelector('[data-action="restore"]').addEventListener("click", function () {
      if (!restoreLastGood()) banner.querySelector("span").textContent = "Ainda não existe uma interface funcional salva.";
    });
    banner.querySelector('[data-action="diagnostic"]').addEventListener("click", function () {
      if (window.CobrinhaDiagnostics) window.CobrinhaDiagnostics.copy();
    });
    banner.querySelector('[data-action="exit"]').addEventListener("click", exitSafeMode);
    document.body.appendChild(banner);
  }

  window.addEventListener("cobrinha-runtime-error", function (event) { rememberError(event.detail || {}); });
  window.addEventListener("cobrinha-interface-state-changed", function () {
    if (!healthy || safeMode) return;
    clearTimeout(lastGoodTimer);
    lastGoodTimer = setTimeout(saveLastGood, 2500);
  });
  window.CobrinhaRuntime = {
    version: VERSION,
    safeMode: safeMode,
    enterSafeMode: enterSafeMode,
    exitSafeMode: exitSafeMode,
    restoreLastGood: restoreLastGood,
    saveLastGood: saveLastGood,
    runSmokeTest: runSmokeTest,
    status: function () { return { version: VERSION, safeMode: safeMode, failures: failures, startedAt: startedAt }; }
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", createRecoveryBanner, { once: true });
  else createRecoveryBanner();
  function healthAttempt() {
    if (markHealthy()) return;
    if (Date.now() - startedAt < 30000) setTimeout(healthAttempt, 3000);
    else rememberError({ module: "smoke-test", message: "A inicialização não passou no teste automático em 30 segundos." });
  }
  setTimeout(healthAttempt, 8000);
})();
