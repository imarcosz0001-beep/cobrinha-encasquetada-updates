(function () {
  "use strict";
  if (window.CobrinhaDiagnostics) return;

  var pageErrors = [];
  var API_URL = window.CobrinhaConfig ? window.CobrinhaConfig.teamApi : "https://cobrinhaencasquetada.lovable.app/api/public/team-api";
  var SAFE_SETTINGS = [
    "cobrinhaInterfaceProfile", "cobrinhaBoxVisualMode", "cobrinhaTeamPanelMode",
    "cobrinhaMinimalBackgroundEnabled", "cobrinhaMinimalBackgroundColor", "cobrinhaMinimalBackgroundOpacity",
    "cobrinhaTechHudOpacity", "cobrinhaTechHudSize", "cobrinhaGraphVisible", "cobrinhaUpdateChannelV1"
  ];

  window.addEventListener("message", function (event) {
    if (event.source !== window || !event.data || event.data.source !== "cobrinha-diagnostics") return;
    var entry = event.data.entry || {};
    pageErrors.push({ type: String(entry.type || "error"), message: String(entry.message || entry.resource || "").slice(0, 300), time: entry.time || "" });
    if (pageErrors.length > 20) pageErrors.shift();
  });

  function modules() {
    var selectors = {
      login: "#login", team: "#lovable-team-panel", chat: "#bchat", shortcuts: "#eemenu",
      minimap: "#mmap", top10: "#ttbox", graph: "#mgraph-box", studio: "#cobrinha-interface-studio"
    };
    var result = {};
    Object.keys(selectors).forEach(function (name) { result[name] = Boolean(document.querySelector(selectors[name])); });
    return result;
  }

  function settings() {
    var result = {};
    SAFE_SETTINGS.forEach(function (key) {
      var value = localStorage.getItem(key);
      if (value != null) result[key] = String(value).slice(0, 120);
    });
    return result;
  }

  function collect() {
    var runtime = window.CobrinhaRuntime;
    return {
      app: "Cobrinha Encasquetada",
      generatedAt: new Date().toISOString(),
      version: chrome.runtime.getManifest().version,
      page: location.origin + location.pathname,
      viewport: { width: window.innerWidth, height: window.innerHeight, pixelRatio: window.devicePixelRatio || 1, hidden: document.hidden },
      runtime: runtime ? runtime.status() : null,
      smokeTest: runtime ? runtime.runSmokeTest() : null,
      scheduler: window.CobrinhaScheduler ? window.CobrinhaScheduler.status() : [],
      backend: {
        status: document.documentElement.dataset.cobrinhaBackendStatus || "unknown",
        failures: Number(document.documentElement.dataset.cobrinhaBackendFailures) || 0,
        latency: Number(document.documentElement.dataset.cobrinhaBackendLatency) || 0
      },
      interfaceRevision: window.CobrinhaInterfaceState ? window.CobrinhaInterfaceState.snapshot().revision : null,
      modules: modules(),
      settings: settings(),
      errors: pageErrors.slice(-20)
    };
  }

  function copy() {
    var text = JSON.stringify(collect(), null, 2);
    function fallback() {
      var area = document.createElement("textarea");
      area.value = text;
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.appendChild(area);
      area.select();
      try { document.execCommand("copy"); } catch (error) {}
      area.remove();
      return Promise.resolve(text);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text).then(function () { return text; }).catch(fallback);
    return fallback();
  }

  function send() {
    var controller = new AbortController();
    var timeout = setTimeout(function () { controller.abort(); }, 10000);
    return fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "submit_diagnostic", report: collect() }),
      signal: controller.signal
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (data) {
        if (!response.ok || data.ok === false) throw new Error(data.error || "Não foi possível enviar o diagnóstico.");
        return { reportId: String(data.report_id || "") };
      });
    }).finally(function () { clearTimeout(timeout); });
  }

  window.CobrinhaDiagnostics = { collect: collect, copy: copy, send: send };
})();
