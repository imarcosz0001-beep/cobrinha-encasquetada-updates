(function (root, factory) {
  var config = factory();
  if (typeof module === "object" && module.exports) module.exports = config;
  if (root) root.CobrinhaConfig = Object.freeze(config);
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";
  var site = "https://cobrinhaencasquetada.lovable.app";
  var updatesRepository = "imarcosz0001-beep/cobrinha-encasquetada-updates";
  return {
    site: site,
    teamApi: site + "/api/public/team-api",
    updatesRepository: updatesRepository,
    githubManifestBase: "https://api.github.com/repos/" + updatesRepository + "/contents/",
    storage: Object.freeze({
      updateChannel: "cobrinhaUpdateChannelV1",
      interfaceState: "cobrinhaInterfaceStateV2",
      safeMode: "cobrinhaSafeModeV1",
    }),
  };
});

