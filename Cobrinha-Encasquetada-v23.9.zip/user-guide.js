(function () {
  "use strict";
  if (window.CobrinhaUserGuide) return;

  var topics = [
    ["Começar a jogar", "Escolha seu apelido, selecione o servidor por ping e clique em Jogar. A configuração inicial pode ser aberta novamente pela engrenagem."],
    ["Interface", "Use a engrenagem para alternar o visual, controlar fundo e texto técnico. Em Abrir Estúdio da Interface você move e redimensiona cada painel; Redefinir devolve exatamente ao padrão."],
    ["Amigos", "Abra o ícone de pessoas ao lado da engrenagem. Crie um convite, envie o código ao amigo e use a aba Convite para adicionar. Convites são de uso único e podem ser revogados."],
    ["Identidade", "Exporte sua identidade na área Ajuda e recuperação. Guarde o arquivo e a senha separados. Assim seus amigos continuam reconhecendo você após reinstalar ou trocar de computador."],
    ["Equipe e sala", "Crie ou entre em uma sala de oito caracteres. Compartilhamento de servidor e posição começa ativo, mas pode ser desligado na Central de Amigos."],
    ["Estável e Beta", "Estável recebe versões aprovadas. Beta recebe novidades primeiro. Trocar o canal não altera suas configurações; em caso de problema, o aviso de atualização oferece a versão anterior."],
    ["Diagnóstico", "Copiar diagnóstico gera informações técnicas sem senhas ou tokens. Enviar diagnóstico sempre pede confirmação e os relatórios expiram no serviço."],
    ["Modo seguro", "Se algo impedir a abertura do jogo, use Reiniciar em modo seguro. O MOD desativa recursos opcionais sem apagar suas configurações."],
    ["Atalhos", "Abra o painel Atalhos para ver as teclas atuais. ON significa ativo e OFF significa desativado. O balão superior confirma alterações feitas durante o modo minimalista."],
    ["Atualização manual", "Baixe somente pacotes indicados pelo próprio MOD. A extensão confere o SHA-256 antes de iniciar o download; nunca instale ZIP recebido por terceiros."],
  ];

  function build() {
    var dialog = document.createElement("dialog");
    dialog.id = "cobrinha-user-guide";
    dialog.className = "cobrinha-user-guide";
    dialog.setAttribute("aria-labelledby", "cobrinha-user-guide-title");
    dialog.innerHTML =
      '<header><div><strong id="cobrinha-user-guide-title">Manual da Cobrinha</strong><span>Ajuda rápida sem sair do jogo</span></div>' +
      '<button type="button" aria-label="Fechar manual">×</button></header>' +
      '<label class="cobrinha-guide-search"><span>Buscar</span><input type="search" placeholder="Ex.: amigos, atualização, interface"></label>' +
      '<div class="cobrinha-guide-topics"></div>' +
      '<footer>Site oficial: cobrinhaencasquetada.lovable.app</footer>';
    document.body.appendChild(dialog);
    var container = dialog.querySelector(".cobrinha-guide-topics");
    var search = dialog.querySelector("input");
    var close = dialog.querySelector("header button");

    function render() {
      var query = search.value.trim().toLocaleLowerCase("pt-BR");
      container.textContent = "";
      topics.filter(function (topic) {
        return !query || (topic[0] + " " + topic[1]).toLocaleLowerCase("pt-BR").indexOf(query) !== -1;
      }).forEach(function (topic, index) {
        var item = document.createElement("details");
        item.open = Boolean(query) || index === 0;
        var summary = document.createElement("summary");
        summary.textContent = topic[0];
        var text = document.createElement("p");
        text.textContent = topic[1];
        item.appendChild(summary);
        item.appendChild(text);
        container.appendChild(item);
      });
      if (!container.children.length) {
        var empty = document.createElement("p");
        empty.className = "cobrinha-guide-empty";
        empty.textContent = "Nenhum tópico encontrado.";
        container.appendChild(empty);
      }
    }
    search.addEventListener("input", render);
    close.addEventListener("click", function () { dialog.close(); });
    dialog.addEventListener("click", function (event) {
      if (event.target === dialog) dialog.close();
    });
    render();
    return { dialog: dialog, search: search };
  }

  var instance;
  window.CobrinhaUserGuide = {
    open: function () {
      if (!document.body) return;
      instance = instance || build();
      if (!instance.dialog.open) instance.dialog.showModal();
      instance.search.value = "";
      instance.search.dispatchEvent(new Event("input"));
      setTimeout(function () { instance.search.focus(); }, 0);
    },
  };
})();

