(function () {
  "use strict";
  if (document.documentElement.dataset.cobrinhaSafeMode === "1") return;

  const SITE_OFICIAL = (window.CobrinhaConfig ? window.CobrinhaConfig.site : "https://cobrinhaencasquetada.lovable.app") + "/";
  const ROTA_LEGADA_SITE = /(?:snake-den-hub\.lovable\.app|ntl-slither\.com\/slither\/modhelp\.php)/i;

  const textos = {
    "Play": "Jogar",
    "Save": "Salvar",
    "Save Message": "Salvar mensagem",
    "Save as:": "Salvar como:",
    "Save & Close": "Salvar e fechar",
    "Cancel": "Cancelar",
    "Close": "Fechar",
    "close": "fechar",
    "Open": "Abrir",
    "Clear": "Limpar",
    "Delete": "Excluir",
    "Select": "Selecionar",
    "Apply": "Aplicar",
    "Set": "Definir",
    "New": "Novo",
    "Old": "Antigo",
    "Default": "Padrão",
    "default": "padrão",
    "Browser default": "Padrão do navegador",
    "Disabled": "Desativado",
    "Forced": "Forçado",
    "Always": "Sempre",
    "Off": "OFF",
    "On": "ON",
    "Left": "Esquerda",
    "Right": "Direita",
    "Current:": "Atual:",
    "Loading... please wait": "Carregando... aguarde",
    "connection error": "erro de conexão",
    "available commands:": "comandos disponíveis:",
    "Leaderboard": "Classificação",
    "Leaderboards": "Classificações",
    "RealTime Leaderboards": "Classificações em tempo real",
    "News & info": "Notícias e informações",
    "Change Skin": "Trocar visual",
    "Keep playing": "Continuar",
    "Select server by ping": "Servidor por ping",
    "Add this server to favorites": "Adicionar este servidor aos favoritos",
    "Mark as favorite (favorites are listed first)": "Marcar como favorito (os favoritos aparecem primeiro)",
    "Remap Keyboard Shortcuts": "Reconfigurar atalhos do teclado",
    "Remap keys": "Atalhos",
    "[EE] toggles shortcut keys menu": "[EE] alterna o menu de atalhos",
    "Reserved keys:": "Teclas reservadas:",
    "Saved keys": "Teclas salvas",
    "Show current keys": "Mostrar teclas atuais",
    "Reset defaults": "Restaurar padrões",
    "Reset all to defaults": "Restaurar padrões",
    "Reset infoboxes": "Restaurar painéis",
    "Backup all settings": "Backup",
    "Restore": "Restaurar",
    "Import skins": "Importar",
    "Export skins": "Exportar",
    "Upload Tag": "Enviar tag",
    "Select Tag": "Tag",
    "Build a Slither": "Criar visual",
    "Select Cosmetic": "Acessório",
    "Search Results": "Resultados da pesquisa",
    "Recently Used": "Usados recentemente",
    "Clear search": "Limpar pesquisa",

    "Common Settings:": "Configurações comuns:",
    "General Settings:": "Configurações gerais:",
    "Team settings:": "Configurações da equipe:",
    "Chat settings:": "Configurações do chat:",
    "Bot & zoom settings:": "Configurações do bot e do zoom:",
    "Assist Settings:": "Configurações de assistência:",
    "Graphics presets:": "Predefinições gráficas:",
    "Recently introduced options:": "Opções adicionadas recentemente:",
    "Top 10 settings:": "Configurações do Top 10:",
    "MOD Defaults": "Padrões do MOD",
    "Game Defaults": "Padrões do jogo",
    "Low Quality": "Baixa qualidade",
    "High Quality": "Alta qualidade",
    "Competitive": "Competitivo",
    "Graphics: High": "Gráficos: altos",
    "Graphics: Normal": "Gráficos: normais",
    "Graphics: Skinless": "Gráficos: sem visual",

    "Enable zoom:": "Ativar zoom:",
    "Start zoom:": "Zoom inicial:",
    "Adjust zoom speed:": "Ajustar velocidade do zoom:",
    "Dynamic slow zoom release:": "Retorno lento e dinâmico do zoom:",
    "Invert mouse scroll zoom:": "Inverter zoom da roda do mouse:",
    "Reset zoom on scroll click:": "Restaurar zoom ao clicar na roda:",
    "Instant reset zoom ratio (X):": "Proporção de restauração instantânea do zoom (X):",
    "2nd click restores zoom:": "O segundo clique restaura o zoom:",
    "Bot circles after length:": "Bot circula após o tamanho:",
    "FPS limiter:": "Limite de FPS:",
    "FPS Graph hidden until F8:": "Gráfico de FPS oculto até F8:",
    "RRM:": "Multiplicador de resolução:",
    "Browser:": "Navegador:",
    "Native:": "Nativa:",
    "Opacity:": "Opacidade:",
    "Mobile UI:": "Interface móvel:",

    "Background choice": "Escolha do plano de fundo",
    "Background: Custom": "Plano de fundo: personalizado",
    "Background: Default": "Plano de fundo: padrão",
    "Background: Default 2016": "Plano de fundo: padrão de 2016",
    "Background: Flowers": "Plano de fundo: flores",
    "Background: Green Lava": "Plano de fundo: lava verde",
    "Background: Grid": "Plano de fundo: grade",
    "Background: Mars": "Plano de fundo: Marte",
    "Background: Metal Grid": "Plano de fundo: grade metálica",
    "Background: Noise": "Plano de fundo: ruído",
    "Background: None (Black)": "Plano de fundo: nenhum (preto)",
    "Background: NTL": "Plano de fundo: clássico",
    "Background: Red Lava": "Plano de fundo: lava vermelha",
    "Custom background tile:": "Imagem de fundo personalizada:",
    "Menu image:": "Imagem do menu:",
    "Disable logo animation:": "Desativar animação do logotipo:",
    "Alternative menu layout:": "Layout alternativo do menu:",

    "Food texture:": "Textura da comida:",
    "Food jiggle:": "Movimento da comida:",
    "Food glow in high graphics:": "Brilho da comida em gráficos altos:",
    "Square food size:": "Tamanho da comida quadrada:",
    "Monochrome food color:": "Cor monocromática da comida:",
    "Default 2016": "Padrão de 2016",
    "Square": "Quadrada",
    "Skin texture:": "Textura dos visuais:",
    "Rounded plain": "Lisa arredondada",
    "Squared plain": "Lisa quadrada",
    "Striped plain": "Lisa listrada",
    "NTL textured": "Texturizada clássica",
    "High visibility skins:": "Visuais de alta visibilidade:",
    "Disable atypical skins (neon, uk, slugs, one eyed):": "Desativar visuais atípicos (neon, Reino Unido, lesmas e um olho):",
    "Own true skin in skinless mode:": "Visual real próprio no modo sem visual:",
    "Team true skin in skinless mode:": "Visual real da equipe no modo sem visual:",
    "Skinless transparency:": "Transparência no modo sem visual:",
    "Skinless only": "Somente sem visual",
    "Snakes dying animation:": "Animação de morte das cobras:",
    "Rings spacing:": "Espaçamento dos anéis:",
    "No dynamic ring spacing while zooming:": "Sem espaçamento dinâmico dos anéis durante o zoom:",
    "Disable boost glow effect:": "Desativar brilho do impulso:",
    "Own boost glow effect:": "Brilho do impulso na própria cobra:",

    "Border Assist:": "Assistência de borda:",
    "Border assist offset:": "Distância da assistência de borda:",
    "Safewall:": "Parede segura:",
    "Safewall script:": "Script da parede segura:",
    "Glass Border:": "Borda de vidro:",
    "Dynamic border semaphore:": "Semáforo dinâmico da borda:",
    "Border line color (no semaphore) / ellipse color:": "Cor da borda (sem semáforo) / cor da elipse:",
    "Assist front laser:": "Laser frontal da assistência:",
    "Assist go skinless:": "Assistência sem visual:",
    "Assist hide food:": "Ocultar comida durante a assistência:",
    "Assist hide own tag and cosmetic:": "Ocultar tag e cosmético próprios durante a assistência:",
    "Assist hide tags&cosmetics:": "Ocultar tags e cosméticos na assistência:",
    "Assist laser on top:": "Laser da assistência por cima:",
    "Assist show spine:": "Mostrar eixo na assistência:",
    "Assist turn path:": "Trajetória de curva da assistência:",
    "Assist turn path active above:": "Ativar trajetória de curva acima de:",

    "Dynamic minimap:": "Minimapa dinâmico:",
    "Map/radar size:": "Tamanho do mapa/radar:",
    "Own dot:": "Ponto próprio:",
    "Nick filter list:": "Lista de filtro de apelidos:",
    "Nicks font size:": "Tamanho da fonte dos apelidos:",
    "Snake nicks on top:": "Apelidos sobre as cobras:",
    "Snake Nicks+:": "Apelidos das cobras+:",
    "All nameless (except team):": "Todos sem nome (exceto a equipe):",
    "Show player details:": "Mostrar detalhes dos jogadores:",
    "Online players status:": "Status dos jogadores on-line:",
    "Top 10 Title:": "Título do Top 10:",
    "Top 10 Title color:": "Cor do título do Top 10:",
    "Top 10 color (if enabled):": "Cor do Top 10 (se ativada):",
    "Top 10 gradient:": "Gradiente do Top 10:",
    "Top 10 single color:": "Cor única do Top 10:",
    "Own line color in Top 10:": "Cor da sua linha no Top 10:",
    "Own line color in players list:": "Cor da sua linha na lista de jogadores:",

    "Team ID:": "ID da equipe:",
    "Auth Key:": "Chave de autenticação:",
    "Team nick color (if nicks+ ON):": "Cor dos apelidos da equipe (com apelidos+ ATIVO):",
    "Use own tag for team:": "Usar sua tag para a equipe:",
    "Use own cosmetic for team:": "Usar seu cosmético para a equipe:",
    "Tag chain length:": "Comprimento da corrente da tag:",
    "Tag swing:": "Balanço da tag:",
    "Small tags (JJ):": "Tags pequenas (JJ):",
    "Disable tags for everyone:": "Desativar tags de todos:",
    "Disable cosmetics and tags for snakes outside the team:": "Desativar cosméticos e tags de cobras fora da equipe:",
    "KeyOwners in chat:": "Donos das chaves no chat:",
    "KeyOwners in players list:": "Donos das chaves na lista de jogadores:",

    "Chat always selectable:": "Chat sempre selecionável:",
    "Unhide chat on message:": "Exibir chat ao receber mensagem:",
    "Timestamps in chat:": "Horários no chat:",
    "Enable chat emoji icon:": "Ativar ícone de emoji no chat:",
    "Disable all chat SCRIPTBOT:": "Desativar todas as mensagens do SCRIPTBOT:",
    "Beep when chat msg:": "Som ao receber mensagem:",
    "Beep on incoming SOS:": "Som ao receber SOS:",
    "Beep when new player:": "Som quando entrar um jogador:",
    "Chat alert when new player:": "Alerta no chat quando entrar um jogador:",
    "Send chat alert when SOS:": "Enviar alerta no chat ao usar SOS:",
    "Quick chat message (Q1):": "Mensagem rápida (Q1):",
    "Quick chat message (Q2):": "Mensagem rápida (Q2):",
    "Quick chat message (Q3):": "Mensagem rápida (Q3):",
    "Quick chat message (Q4):": "Mensagem rápida (Q4):",
    "Quick chat message (Q5):": "Mensagem rápida (Q5):",
    "Quick chat message (Q6):": "Mensagem rápida (Q6):",
    "Chat message color:": "Cor das mensagens do chat:",
    "Chat nick color:": "Cor dos apelidos no chat:",
    "SCRIPTBOT (#) chat color:": "Cor do SCRIPTBOT (#) no chat:",
    "Show hint when EE hidden:": "Mostrar dica quando EE estiver oculto:",
    "Stealth mode:": "Modo furtivo:",
    "Instant gameover:": "Fim de jogo instantâneo:",
    "Auto hide flying preys:": "Ocultar presas voadoras automaticamente:",
    "Skin Peek (W) always on:": "Espiar visual (W) sempre ativo:",
    "Peek (W) shows own nick:": "Espiar (W) mostra seu apelido:",
    "Peek (W) shows own skin:": "Espiar (W) mostra seu visual:",
    "Peek (W) shows keyowners:": "Espiar (W) mostra donos das chaves:",
    "Peek (W) shows big food:": "Espiar (W) mostra comida grande:",
    "Auto": "Automático",
    "Default Small": "Padrão pequeno",
    "Default 2016 Small": "Padrão de 2016 pequeno",
    "Adjust settings as in MOD defaults:": "Ajustar conforme os padrões do MOD:",
    "Adjust settings for competitive gaming:": "Ajustar para jogo competitivo:",
    "Adjust settings for high quality original game:": "Ajustar para o jogo original em alta qualidade:",
    "Adjust settings for lowest quality:": "Ajustar para a menor qualidade:",
    "Adjust settings for normal original game:": "Ajustar para o jogo original normal:",
    "Own spine:": "Eixo da própria cobra:",
    "No sufficient data to show suggestions. Close and re-open this list when leaderboard is loaded and / or snakes are nearby": "Não há dados suficientes para mostrar sugestões. Feche e reabra a lista quando a classificação carregar ou houver cobras por perto",
    "You can copy-paste words, parts of nicks or entire nicks from the following suggestions:": "Você pode copiar e colar palavras, partes de apelidos ou apelidos inteiros das sugestões abaixo:",
    "Rotate L/R:": "Girar E/D:",
    "Take screenshot": "Capturar tela",
    "Download bar:": "Barra de downloads:",
    "Players list": "Lista de jogadores",
    "Menu": "Menu",
    "Toggle Chat": "Alternar chat",
    "Write Chat": "Escrever no chat",
    "Respawn": "Renascer",
    "Quit": "Sair",
    "Reset zoom": "Restaurar zoom",
    "Zoom out/in": "Afastar/aproximar",
    "Clear chat": "Limpar chat",
    "Assist": "Assistência",
    "] Assist": "] Assistência",
    "Time&Rates": "Tempo e taxas",
    "Death Point keep:": "Manter ponto da morte:",
    "Auto no prey:": "Sem presas automático:",
    "Toggle Food": "Alternar comida",
    "Map Size": "Tamanho do mapa",
    "Small Tags:": "Tags pequenas:",
    "Toggle graphics": "Alternar gráficos",
    "Skin/Nick Peek": "Espiar visual/apelido",
    "Graph": "Gráfico",
    "Toggle Online players": "Alternar jogadores on-line",
    "Show QQs": "Mostrar QQs",
    "Hide all Addons.": "Ocultar todos os complementos.",
    "Open RTL": "Abrir classificação em tempo real",
    "Open Settings": "Abrir configurações",
    "Scaling": "Escala",
    "Own dot": "Ponto próprio",
    "Tiny dots": "Pontos pequenos",
    "Auto Respawn:": "Renascimento automático:",
    "Auto-Screenshots:": "Capturas automáticas:",
    "Smart bot:": "Bot inteligente:",
    "toggles shortcut keys menu": "alterna o menu de atalhos",
    "Bot must be ON to open settings during play": "O bot precisa estar ligado para abrir as configurações durante a partida",
    "Bot must be ON to open realtime during play": "O bot precisa estar ligado para abrir o painel em tempo real durante a partida",
    "chat unavailable without teamID": "Este chat antigo exige um Team ID válido",
    "Food:": "Comida:",
    "SOS:": "SOS:",
    "No team membership": "Sem participação em uma equipe",
    "Invalid auth keys": "Chaves de autenticação inválidas",
    "no team": "sem equipe",
    "red": "vermelho",
    "orange": "laranja",
    "green": "verde",
    "lime": "verde-limão",
    "blue": "azul",
    "dodgerblue": "azul-claro",
    "magenta": "magenta",
    "pink": "rosa",
    "hotpink": "rosa-choque",
    "plum": "ameixa",
    "cyan": "ciano",
    "yellow": "amarelo",
    "white": "branco",
    "Custom skin [N,M]# :": "Visual personalizado [N,M] nº:",
    "Normal skin [n,m]# :": "Visual normal [n,m] nº:",
    "FPS:": "FPS:",
    "Hex": "Hexadecimal",
    "Snap to": "Encaixar em",
    "Open Settings [": "Abrir configurações [",
    "Settings": "Configurações",
    "please use copy-paste": "cole aqui usando copiar e colar",
    "eg: team name / key owner (used for saving)": "ex.: nome da equipe / dono da chave (usado ao salvar)",
    "Quick search settings by name or comment": "Pesquisar configurações por nome ou descrição",
    "Your final length was": "Seu comprimento final foi",
    "Best length:": "Melhor comprimento:",
    "Server time:": "Horário do servidor:",
    "Rank:": "Posição:",
    "of": "de",
    "Length:": "Comprimento:",
    "Players list:": "Lista de jogadores:",
    "Online players (key owner, nick": "Jogadores on-line (dono da chave, apelido",
    "* Hold mouse over various checkboxes for a short info": "* Passe o mouse sobre as opções para ver uma breve explicação",
    "* list of unwanted words in/or nicks, one per line": "* palavras indesejadas em apelidos, uma por linha",
    "* press DD during play to replace default dot on map": "* pressione DD durante o jogo para substituir o ponto padrão no mapa",
    "*open settings with [..] or chat with [hh]": "* abra as configurações com [..] ou o chat com [hh]",
    "*use SHIFT + scroll for custom skins": "* use SHIFT + roda do mouse para visuais personalizados",
    "--- NTL tag uploader ---": "--- Envio de tags ---",
    "--- Slither.io RealTime Status - by NTL ---": "--- Status do Slither.io em tempo real ---",
    "- !clearhistory : clears command history": "- !clearhistory: limpa o histórico de comandos",
    "- !ellipse : modifies the position and shape of the default center circle": "- !ellipse: altera a posição e a forma do círculo central padrão",
    "- !forcecleanupdate : will check for new tags when reloads but first deletes all current downloaded updates": "- !forcecleanupdate: limpa o cache e baixa novamente as tags do nosso servidor",
    "- !forceupdate : will check for new tags when reloads": "- !forceupdate: atualiza as tags usando o nosso servidor Lovable",
    "- !history : shows last 100 commands used": "- !history: mostra os últimos 100 comandos usados",
    "- !loadtag : test your own tag uploaded on my site using the stored id": "- !loadtag: baixa e testa uma tag do servidor Cobrinha Encasquetada",
    "- !newtag : fine tune loaded tag position and string colors": "- !newtag: ajusta a posição e as cores da tag carregada",
    "- !protocol : toggles protocol between the default v12 and experimental v13 (high res minimap only). gets saved permanently": "- !protocol: alterna entre o protocolo v12 padrão e o v13 experimental (minimapa em alta resolução). A opção é salva",
    "- !rst : reset custom tag password": "- !rst: redefine a senha da tag personalizada",
    "- !sbcx : unbinds C&X keys. gets saved permanently.": "- !sbcx: remove os atalhos C e X. A opção é salva",
    "- !tag : activate custom tag": "- !tag: ativa a tag personalizada",
    "- !ts : toggles showing of connected server ip. does not get saved permanently": "- !ts: alterna a exibição do IP do servidor conectado. A opção não é salva",
    "- timedemo : self clones +10 snakes for benchmarking in choosing skin": "- !timedemo: cria 10 clones da sua cobra para testar o desempenho na escolha de visual",
    "- timedemo1 : adds 10k worth of food for benchmarking. this can also be used during game": "- !timedemo1: cria 10 mil partículas de comida para testar o desempenho; também funciona durante o jogo"
  };

  const titulos = {
    "Change or disable keyboard shortcuts": "Altere ou desative os atalhos do teclado",
    "Browse custom skins": "Procurar visuais personalizados",
    "Browse normal skins": "Procurar visuais normais",
    "Background choice": "Escolha do plano de fundo",
    "Clear search": "Limpar pesquisa",
    "Click IPv6 to use IPv6 server": "Clique em IPv6 para usar um servidor IPv6",
    "Click to choose a color (with transparency)": "Clique para escolher uma cor (com transparência)",
    "Click to choose a color (with transparency), or use game default": "Clique para escolher uma cor (com transparência) ou use o padrão do jogo",
    "Current browser window size": "Tamanho atual da janela do navegador",
    "Current calculated render resolution (multiplier applied)": "Resolução de renderização calculada (com multiplicador)",
    "Default zoom when starting game": "Zoom padrão ao iniciar o jogo",
    "Drag to adjust border assist offset": "Arraste para ajustar a distância da assistência de borda",
    "Drag to change bot circling threshold": "Arraste para alterar o limite em que o bot começa a circular",
    "Drag to change instant-reset zoom ratio": "Arraste para alterar a proporção de restauração instantânea do zoom",
    "Drag to change map/radar size": "Arraste para alterar o tamanho do mapa/radar",
    "Drag to change nicks font size": "Arraste para alterar o tamanho da fonte dos apelidos",
    "Drag to change rendering resolution multiplier.": "Arraste para alterar o multiplicador da resolução de renderização.",
    "Drag to change settings panel opacity": "Arraste para alterar a opacidade do painel de configurações",
    "Drag to change start zoom": "Arraste para alterar o zoom inicial",
    "Drag to change zoom adjust speed": "Arraste para alterar a velocidade de ajuste do zoom",
    "Drag to set the score threshold for the assist turn path": "Arraste para definir a pontuação mínima da trajetória de curva da assistência",
    "Enable/disable ZOOM MOD.": "Ativa ou desativa o MOD DE ZOOM.",
    "Food color #": "Cor da comida nº",
    "Game default is 15, mod default is 15.5": "O padrão do jogo é 15; o padrão do mod é 15,5",
    "Rendering Resolution Multiplier": "Multiplicador da resolução de renderização",
    "Settings panel opacity": "Opacidade do painel de configurações",
    "Settings panel opacity (0.3 - 1.0)": "Opacidade do painel de configurações (0,3 a 1,0)",
    "Shows the predicted minimum-turn trajectory.": "Mostra a trajetória prevista para a curva mínima.",
    "Try if nothing else works": "Tente se nada mais funcionar",
    "Use game default color": "Usar a cor padrão do jogo",
    "Useful in tight places where big cosmetics or tags are in the way.": "Útil em locais apertados onde cosméticos grandes ou tags atrapalham.",
    "When disabled food no longer bounces around a little.": "Quando desativado, a comida deixa de balançar.",
    "When enabled will limit tag size to snake width.": "Quando ativado, limita o tamanho da tag à largura da cobra.",
    "When checked will play a sound at incoming chat messages": "Quando ativado, toca um som ao receber mensagens no chat",
    "When checked will play a sound at incoming SOS": "Quando ativado, toca um som ao receber um SOS",
    "When checked will play a sound when new player joins the team": "Quando ativado, toca um som quando um novo jogador entra na equipe",
    "When checked will show timestamps in chat": "Quando ativado, mostra os horários no chat",
    "When checked will show if online players are in menu or playing in a server": "Quando ativado, mostra se os jogadores on-line estão no menu ou jogando em um servidor",
    "When checked there will be no logo animation when loading slither": "Quando ativado, não haverá animação do logotipo ao carregar o slither",
    "When checked there will be no glowing around snakes while boosting": "Quando ativado, não haverá brilho ao redor das cobras durante o impulso",
    "When checked snakes will be transparent in skinless mode": "Quando ativado, as cobras ficam transparentes no modo sem visual",
    "When checked snake nicks will be shown on top of snakes bodies": "Quando ativado, os apelidos aparecem sobre o corpo das cobras",
    "When checked own snake will have boosting effect": "Quando ativado, sua cobra terá o efeito de impulso",
    "When checked main menu will have different order of buttons": "Quando ativado, os botões do menu principal terão outra ordem",
    "When checked mod will hide tags for all snakes": "Quando ativado, o mod oculta as tags de todas as cobras",
    "When checked mod will hide cosmetics & tags for snakes outside of team": "Quando ativado, o mod oculta cosméticos e tags de cobras fora da equipe",
    "When checked flying preys will appear only below 1k score": "Quando ativado, as presas voadoras só aparecem abaixo de 1 mil pontos",
    "When checked dying snakes will have an animation before becoming food. On weak computers it can cause low FPS.": "Quando ativado, cobras morrendo têm uma animação antes de virarem comida. Em computadores fracos, isso pode reduzir o FPS.",
    "When checked Border is Glass like transparent": "Quando ativado, a borda fica transparente como vidro",
    "When checked assist will temporarily hide the food for better visibility": "Quando ativado, a assistência oculta temporariamente a comida para melhorar a visibilidade",
    "When checked assist will activate front laser for better directional visibility": "Quando ativado, a assistência usa um laser frontal para melhorar a percepção da direção",
    "When checked assist laser will be shown on top of snakes bodies": "Quando ativado, o laser da assistência aparece sobre o corpo das cobras",
    "Activating SOS flag automatically sends chat message Help me! for you": "Ativar a bandeira SOS envia automaticamente a mensagem 'Ajude-me!' no chat",
    "Allows for different speed increments in zooming": "Permite diferentes incrementos de velocidade no zoom",
    "Always get back slowly to game's original zoom level": "Sempre retorna lentamente ao nível de zoom original do jogo",
    "Assist turn path will only be drawn when snake score is greater or equal to this.": "A trajetória de curva da assistência só será desenhada quando a pontuação da cobra for igual ou superior a este valor.",
    "Auto-calculate the best multiplier so render resolution matches your browser window size exactly. If no exact match exists, picks the highest multiplier whose resolution still fits within the browser window. Best to set this while in fullscreen or however you actually play.": "Calcula automaticamente o melhor multiplicador para que a resolução corresponda ao tamanho da janela. Se não houver correspondência exata, usa o maior valor que ainda caiba na janela. Ajuste no modo em que você costuma jogar.",
    "Browser default is usually best and equal with your display refresh rate, anything between 60 and 300, but still some browser versions could disregard this. Higher FPS means better smoothness if your system can handle it but with increased CPU usage. Select 50 FPS for original game fps and lowest CPU usage.\nIf you select a fps limiter lower than your refresh rate it will help if you disable vsync and/or enable freesync/g-sync.": "O padrão do navegador costuma ser a melhor opção e acompanha a taxa de atualização da tela. Mais FPS oferece maior fluidez, mas aumenta o uso da CPU. Use 50 FPS para reproduzir o jogo original e reduzir o uso da CPU.\nSe o limite de FPS for menor que a taxa da tela, desativar o VSync ou ativar FreeSync/G-Sync pode ajudar.",
    "Calculated rendering resolution exceeds your window size. Pixels above the window size are wasted GPU load. Use only for testing/benchmarking!": "A resolução calculada excede o tamanho da janela. Pixels além da janela desperdiçam GPU. Use apenas para testes de desempenho!",
    "Causes scroll up/down zooming to have reversed action.": "Inverte a ação do zoom ao girar a roda do mouse.",
    "Chat will become visible when incoming message from players except SCRIPTBOT": "O chat será exibido ao receber mensagens de jogadores, exceto do SCRIPTBOT",
    "Default: normal big textured food. Small: smaller textured food, easier on your eyes. Square: food rendered as transparent colored squares with size controlled by Square food size.": "Padrão: comida grande com textura. Pequena: comida texturizada menor e mais confortável. Quadrada: quadrados coloridos transparentes, com tamanho definido na opção correspondente.",
    "Decent computers work best with Default or NTL textures. NTL textures will increase your FPS in certain rare and very busy areas when zoomed out at the sacrifice of some visual quality.": "Computadores razoáveis funcionam melhor com texturas Padrão ou Clássica. A textura clássica pode aumentar o FPS em áreas muito movimentadas e com zoom afastado, sacrificando parte da qualidade visual.",
    "Disable if you want to see full server radius in the minimap. Can be changed only from the main menu and only works with protocol v13 (the default)": "Desative para ver todo o raio do servidor no minimapa. Só pode ser alterado no menu principal e funciona apenas com o protocolo v13 (padrão)",
    "Disable monochrome food color (use original per-food colors)": "Desativar cor monocromática (usar as cores originais de cada comida)",
    "Disables all SCRIPTBOT messages from the chat like confirmations and notifications": "Desativa no chat todas as mensagens do SCRIPTBOT, como confirmações e notificações",
    "In case border assist kills you too often increase the offset which causes your snake to stay a little further from the border. If you have very low delay you can even decrease it to make it even tighter. It also applies to safewall mode 2.": "Se a assistência de borda causar muitas mortes, aumente a distância para manter a cobra mais afastada. Com latência muito baixa, você pode diminuí-la. Também se aplica ao modo 2 da parede segura.",
    "Makes a SCRIPTBOT log entry when new player joins the team": "Registra no SCRIPTBOT quando um novo jogador entra na equipe",
    "Multiplier applied to food size when Food texture is set to Square. Default 0.4.": "Multiplicador aplicado ao tamanho da comida quando a textura é Quadrada. Padrão: 0,4.",
    "No spectating after death.": "Não permite assistir após morrer.",
    "Plays a sound when new player joins the team": "Toca um som quando um novo jogador entra na equipe",
    "Pressing (middle) mouse scroll instantly resets zoom to the value specified above": "Clicar na roda do mouse restaura instantaneamente o zoom para o valor acima",
    "Rounded plain, Squared plain and Striped are not implemented for WebGL GPU acceleration and are not recommended. For best FPS use Default or NTL textured.": "As opções Lisa arredondada, Lisa quadrada e Lisa listrada não usam aceleração WebGL e não são recomendadas. Para obter mais FPS, use Padrão ou Texturizada clássica.",
    "Show middle line on own snake.\nDisabled: never.\nAlways: in all graphics modes.\nSkinless only: only when own snake is drawn as skinless.": "Mostra a linha central da sua cobra.\nDesativado: nunca.\nSempre: em todos os modos gráficos.\nSomente sem visual: apenas quando sua cobra estiver sem visual.",
    "Skinless and any other option activating skinless like assist or team options will drop optimisations for normal textures": "O modo sem visual e qualquer opção que o ative reduzem as otimizações das texturas normais",
    "Skinless not implemented for WebGL GPU acceleration and is not recommended. In most cases skinless will be slower than Default or NTL skin textures.": "O modo sem visual não usa aceleração WebGL e não é recomendado. Na maioria dos casos, ele é mais lento que as texturas Padrão ou Clássica.",
    "Top10 will have fading transparency towards #10": "O Top 10 ficará gradualmente transparente em direção ao 10º lugar",
    "Top10 will have single color for all": "O Top 10 usará uma única cor para todos",
    "Up to this score the bot gathers food. After this size, it starts forming a circle": "Até esta pontuação, o bot coleta comida. Depois disso, começa a formar um círculo",
    "When checked all snakes except team will be nameless, also in leaderboard. This is meant to prevent possible disturbing nicknames like insults, racism, political controversy and so on.": "Quando ativado, todas as cobras fora da equipe ficam sem nome, inclusive na classificação. Isso evita apelidos ofensivos ou perturbadores.",
    "When checked and EE hidden, instead of empty, will show EE keyboard hint and own nick": "Quando ativado e EE estiver oculto, mostra a dica da tecla EE e seu apelido em vez de deixar o espaço vazio",
    "When checked chat will show keyowner instead of IGN": "Quando ativado, o chat mostra o dono da chave no lugar do nome no jogo",
    "When checked clicking on the emoji icon is enabled. Some people prefer this disabled to not interfere with the game.": "Quando ativado, permite clicar no ícone de emoji. Algumas pessoas preferem desativar para não interferir no jogo.",
    "When checked during assist own snake will have spine on top": "Quando ativado, sua cobra mostra o eixo por cima durante a assistência",
    "When checked nicks will have the score of the snake attached to the end in the form @scoreK,\nand colors will be aplied if in the same team, or on flags like SOS, FOOD.": "Quando ativado, os apelidos exibem a pontuação da cobra no formato @pontosK e recebem cores conforme a equipe ou bandeiras como SOS e COMIDA.",
    "When checked players list will show FPS, delay, rates": "Quando ativado, a lista de jogadores mostra FPS, latência e taxas",
    "When checked players list will show Keyowner instead of IGN": "Quando ativado, a lista de jogadores mostra o dono da chave no lugar do nome no jogo",
    "When checked pressing peek button (W) will also show big food if it was small": "Quando ativado, espiar com W também mostra a comida grande se ela estiver pequena",
    "When checked pressing peek button (W) will also show your own snake nick": "Quando ativado, espiar com W também mostra o apelido da sua cobra",
    "When checked pressing peek button (W) will also show your own snake true skin (if in skinless)": "Quando ativado, espiar com W também mostra o visual real da sua cobra no modo sem visual",
    "When checked skins appear brighter and more clear. It applies to normal skin in normal graphics": "Quando ativado, os visuais ficam mais claros e brilhantes nos gráficos normais",
    "When checked will replace team cosmetics (even if not any) with your own": "Quando ativado, substitui os cosméticos da equipe pelos seus",
    "When checked will replace team tag (even if not any) with your own": "Quando ativado, substitui a tag da equipe pela sua",
    "When checked your own skin will be rendered in medium quality even in skinless": "Quando ativado, seu visual é renderizado em qualidade média mesmo no modo sem visual",
    "When checked your team members' skin will be rendered in medium quality even in skinless": "Quando ativado, os visuais da equipe são renderizados em qualidade média mesmo no modo sem visual",
    "When set, all food pellets will be drawn using this color regardless of their original color.": "Quando definida, toda a comida usa esta cor, independentemente da cor original.",
    "Add this server to favorites": "Adicionar este servidor aos favoritos",
    "Chat is always selectable with mouse click. It will interfere with boost if mouse clicks over chat. Use this in favor of keeping pressed ` (backtick) which allows temporary mouse selection": "Permite selecionar o chat sempre com o mouse. Clicar sobre o chat pode interferir na aceleração. Use esta opção em vez de manter a tecla ` pressionada para selecionar temporariamente.",
    "Choose the script used for safewall: 1 - based on linear calculations and mouse position relative to snake's head or 2 - based on parameters calculations like speed, angles, width, inertia.": "Escolhe o método da parede segura: 1 — cálculos lineares e posição do mouse em relação à cabeça; 2 — parâmetros como velocidade, ângulo, largura e inércia.",
    "Click to choose a color (with transparency) when semaphore is not in use. Only the transparency will also apply to semaphore.": "Clique para escolher uma cor com transparência quando o semáforo não estiver em uso. No semáforo, somente a transparência será aplicada.",
    "Controls the mobile touch UI (top button bar, virtual joystick, pinch zoom, touch listeners). Auto: enable only when a mobile device is detected (default). Disabled: never enable mobile UI, regardless of device. Forced: always enable mobile UI, regardless of device. Changing this reloads the page.": "Controla a interface móvel: barra superior, controle virtual, zoom por pinça e comandos de toque. Automático: ativa somente em dispositivo móvel. Desativado: nunca ativa. Forçado: ativa em qualquer dispositivo. Alterar esta opção recarrega a página.",
    "Disable if you want to manual drive along the border while keeping the laser for instance, or disable in favor of safewall.": "Desative para conduzir manualmente junto à borda mantendo apenas o laser, ou para usar somente a parede segura.",
    "Drag to change the density of the ring/segment pattern along the snake body. Lower = more, denser rings (heavier CPU/GPU). Higher = fewer, sparser rings (lighter). Default 6 for default textures or 7 for NTL textures.": "Arraste para alterar a densidade dos anéis ao longo da cobra. Valores menores criam mais anéis e exigem mais do computador; valores maiores criam menos anéis. Padrão: 6 para texturas normais ou 7 para a textura clássica.",
    "Drag to change the length of the cable/chain/rope between the snake head and the tag bobble. 1 = legacy mod, 3 = three times as long.": "Arraste para alterar o comprimento da corrente entre a cabeça da cobra e a tag. 1 corresponde ao mod antigo; 3 deixa a corrente três vezes maior.",
    "Inertia / oscillation strength only; per-segment length stays fixed (same as tsw=1). Higher = more lag and wobble after motion changes. Overall cable length: Tag chain length. 1 = mod default.": "Ajusta somente a força da inércia e da oscilação; o tamanho de cada segmento permanece fixo. Valores maiores causam mais atraso e balanço após mudanças de movimento. O comprimento total é definido em Comprimento da corrente da tag. Padrão: 1.",
    "Instead of your chosen color it will draw the border as red when it shrinks, orange when standing still and green when expanding. Orange and green are safer in combination with border assist/safewall": "Em vez da cor escolhida, a borda fica vermelha quando encolhe, laranja quando está parada e verde quando expande. Laranja e verde são mais seguros com assistência de borda ou parede segura.",
    "It saves in your downloads folder a file with your custom skins that can be safely shared with friends and imported. It will not contain any tags or cosmetics, just the built snakes.": "Salva na pasta de downloads um arquivo com seus visuais personalizados, que pode ser compartilhado e importado. O arquivo contém somente as cobras criadas, sem tags ou cosméticos.",
    "Mark as favorite (favorites are listed first)": "Marcar como favorito; os favoritos aparecem primeiro",
    "Multiplier for the per-segment rest length of the tag cable. 1 = legacy mod default, 2 = double, 3 = triple.": "Multiplicador do comprimento de repouso de cada segmento da corrente da tag. 1 = padrão antigo, 2 = dobro, 3 = triplo.",
    "Native game render resolution (multiplier = 1)": "Resolução nativa de renderização do jogo (multiplicador = 1)",
    "Pressing W during play replaces team snake nicknames with key owners. This is just for the snakes, as the players list will show keyowners on W regardless of this setting for the purpose of easy and clear association.": "Durante a partida, pressionar W substitui os apelidos das cobras da equipe pelos donos das chaves. Esta opção afeta apenas as cobras; a lista de jogadores continuará mostrando os donos das chaves ao pressionar W.",
    "Swing and inertia only: softer spring and velocity decay, so the cable lags and oscillates (turns, speed changes, boost off). Does not change cable length; use Tag chain length for that. 1 = mod default.": "Ajusta somente o balanço e a inércia da corrente, alterando seu atraso e oscilação em curvas, mudanças de velocidade e fim do impulso. Não altera o comprimento; use Comprimento da corrente da tag. Padrão: 1.",
    "This is a multiplier to increase game resolution proportionally before it is stretched to your browser window size. 1 = original game default 1.2-1.3 = sharper around 1080p 1.7 = sharper around 1440p 2.5 = sharper for 4K+ Beware this increases the load on your gpu exponentially: multiplier of 2 = 4x more gpu load. Monitor your fps.": "Multiplica proporcionalmente a resolução do jogo antes de ajustá-la à janela. 1 = padrão original; 1,2–1,3 = mais nitidez em 1080p; 1,7 = mais nitidez em 1440p; 2,5 = mais nitidez em 4K. O consumo da GPU cresce rapidamente: multiplicador 2 usa aproximadamente quatro vezes mais processamento. Monitore o FPS.",
    "This will adjust all concerning settings in order to make the game visually identical to the original game (except the zoom option). If you want default NTL MOD options press the Reset all to defaults button": "Ajusta as opções para deixar o jogo visualmente igual ao original, exceto pelo zoom. Para voltar aos padrões da Cobrinha Encasquetada, use Restaurar padrões.",
    "This will adjust all concerning settings in order to make the game visually identical to the original game with high quality": "Ajusta as opções para deixar o jogo visualmente igual ao original em alta qualidade.",
    "This will adjust graphic settings as favored by the NTL creator for competitive gaming: defaults + NTL textures, no atypical skins, high visibility skins": "Aplica uma configuração voltada ao jogo competitivo: padrões do mod, textura clássica, sem visuais atípicos e com visuais de alta visibilidade.",
    "This will adjust graphic settings as set by a clean install of NTL MOD": "Aplica as configurações gráficas de uma instalação limpa da Cobrinha Encasquetada.",
    "This will remove all slither settings from localstorage except team keys, skins, highscore, nick filter list, and realtime leaderboards preferences. It will keep KA MI KA ZE UUID. Beware it removes everything slither related, even the settings of other mods. It will first save current values and then reloads slither.": "Remove do armazenamento local todas as configurações do Slither, preservando dados da equipe, visuais, recorde, filtro de apelidos e identificador do jogador. Isso também pode apagar configurações de outros mods. Os valores atuais serão salvos antes de recarregar o jogo.",
    "When checked assist temporarily forces skinless mode which hurts performance. Disable for full WebGL acceleration during assist.": "Quando ativado, a assistência força temporariamente o modo sem visual, o que pode reduzir o desempenho. Desative para manter a aceleração WebGL completa durante a assistência.",
    "When checked assist will temporarily switch to skinless mode": "Quando ativado, a assistência muda temporariamente para o modo sem visual.",
    "When checked atypical skins will be replaced. Uk skin will replaced by blue/red rings and neon skins will practically become like normal one-colored skin. Same for slugs and one eyed. It gives 30%+ performance when rendering those skins.": "Quando ativado, substitui visuais atípicos. O visual do Reino Unido vira anéis azuis e vermelhos; visuais neon, lesmas e cobras de um olho são simplificados. Isso pode melhorar bastante o desempenho ao renderizá-los.",
    "When checked everyone in the game except you and your team members (if nicks+ is ON) will see your snake as nameless with a new random skin generated at each respawn. Can be changed only from the main menu.": "Quando ativado, todos os jogadores, exceto você e os integrantes da sua equipe com Apelidos+ ligado, verão sua cobra sem nome e com um novo visual aleatório a cada renascimento. Só pode ser alterado no menu principal.",
    "When checked pressing again X or mouse scroll (middle) click causes the zoom to instantly get back to the level it was when before you first pressed X or scroll click": "Quando ativado, pressionar X ou clicar novamente na roda do mouse restaura imediatamente o nível de zoom anterior.",
    "When checked skin peek will always be on (skinless shows all in true skin except your own)": "Quando ativado, a visualização dos visuais permanece sempre ligada. No modo sem visual, mostra o visual verdadeiro de todos, exceto o seu.",
    "When checked snake will autodrive along the border without engaging assist using an alternate method, but border assist will take precedence if used by pressing R or KK": "Quando ativado, a cobra acompanha automaticamente a borda por um método alternativo, sem ligar a assistência. A assistência de borda terá prioridade quando acionada por R ou KK.",
    "When checked, fps graph stays hidden unless toggled with F8 even in main menu. It will still record data.": "Quando ativado, o gráfico de FPS permanece oculto até ser exibido com F8, inclusive no menu principal. Os dados continuam sendo registrados.",
    "When checked, high graphics will render food glow. Disabled by default because it can heavily reduce FPS.": "Quando ativado, os gráficos altos exibem brilho na comida. Vem desativado porque pode reduzir bastante o FPS.",
    "When checked, ring/segment spacing stays at the Rings spacing setting and is not sparsified further when zoomed out. Default behavior raises spacing as zoom decreases to reduce ring count in the viewport (CPU/GPU). With WebGL this is usually unnecessary.": "Quando ativado, o espaçamento dos anéis permanece no valor configurado mesmo com o zoom afastado. O comportamento padrão aumenta o espaçamento para reduzir a quantidade de anéis e o uso de CPU/GPU. Com WebGL, isso geralmente não é necessário.",
    "When checked, while assist is active your own snake's tag and cosmetic will be hidden.": "Quando ativado, sua tag e seu cosmético ficam ocultos enquanto a assistência estiver ativa.",
    "When pressing X or mouse scroll (middle) click (if enabled) zoom is instantly set to this default ratio": "Ao pressionar X ou clicar na roda do mouse, se ativado, o zoom muda imediatamente para esta proporção padrão.",
    "You might also be able to input ALT+code special chars & emoji. If the message starts with ! it will be executed as a chat command instead of being sent as a chat message.": "Você também pode inserir caracteres especiais e emojis com ALT+código. Se a mensagem começar com !, ela será executada como comando em vez de enviada ao chat.",
    "GPU accelerated WebGL not available (mod uses classic rendering).": "A aceleração WebGL por GPU não está disponível; o mod está usando a renderização clássica.",
    "WebGL renderer not ready yet. It may still in init? Try later.": "O renderizador WebGL ainda não está pronto. Aguarde a inicialização e tente novamente.",
    "GPU accelerated WebGL is enabled. Click to disable.": "A aceleração WebGL por GPU está ativada. Clique para desativar.",
    "GPU accelerated WebGL is disabled (mod uses classic rendering). Click to enable.": "A aceleração WebGL por GPU está desativada; o mod usa a renderização clássica. Clique para ativar.",
    "Toggle GPU accelerated WebGL off or on": "Ativar ou desativar a aceleração WebGL por GPU",
    "coming asap": "Estou indo o mais rápido possível",
    "I have trap": "Tenho uma armadilha",
    "I'm trapped": "Estou preso",
    "deleted! please select new keys.": "Excluído! Selecione novas chaves.",
    "not saved! typing error, key too short?": "Não foi salvo! Verifique se a chave digitada está completa.",
    "nothing deleted: no saved item selected.": "Nada foi excluído: nenhum item salvo foi selecionado.",
    "saved! (empty - no team)": "Salvo! (vazio — sem equipe)",
    "Search...": "Pesquisar...",
    "NTL Mod - Top 10": "TOP 10"
  };

  function normalizarAtributo(valor) {
    return String(valor || "").replace(/\s+/g, " ").trim();
  }

  const atributosNormalizados = {};
  for (const [ingles, portugues] of Object.entries(textos)) {
    atributosNormalizados[normalizarAtributo(ingles)] = portugues;
  }
  for (const [ingles, portugues] of Object.entries(titulos)) {
    atributosNormalizados[normalizarAtributo(ingles)] = portugues;
  }

  function traduzAtributoDinamico(valor) {
    const limpo = normalizarAtributo(valor);
    const cor = limpo.match(/^Food color #(\d+)$/i);
    if (cor) return "Cor da comida nº " + cor[1];
    if (limpo.includes("* cannot be seen outside NTL compatible mods or mobile.")) {
      return aplicarMarca(valor)
        .replace("* cannot be seen outside Cobrinha Encasquetada compatible mods or mobile.", "* não pode ser visto fora de mods compatíveis ou no celular.")
        .replace("Go to Enter Code to unlock all.", "Acesse Inserir código para desbloquear todos.");
    }
    return null;
  }

  // Os painéis do canto esquerdo intercalam texto e elementos <span> para
  // colorir as teclas. Por isso, suas frases precisam ser traduzidas por
  // fragmentos, e não apenas pela correspondência exata usada no restante.
  const frasesPaineis = {
    "Food:": "Comida:",
    "Smart bot:": "Bot inteligente:",
    "Auto Respawn:": "Renascimento automático:",
    "Auto-Screenshots:": "Capturas automáticas:",
    "Rotate L/R:": "Girar E/D:",
    "Take screenshot": "Capturar tela",
    "Download bar:": "Barra de downloads:",
    "Own dot": "Ponto próprio",
    "Tiny dots": "Pontos pequenos",
    "Players list": "Lista de jogadores",
    "Toggle Chat": "Alternar chat",
    "Write Chat": "Escrever no chat",
    "Respawn": "Renascer",
    "Quit": "Sair",
    "Reset zoom": "Restaurar zoom",
    "Zoom out/in": "Afastar/aproximar",
    "Clear chat": "Limpar chat",
    "Time&Rates": "Tempo e taxas",
    "Death Point keep:": "Manter ponto da morte:",
    "Snake Nicks+:": "Apelidos das cobras+:",
    "Auto no prey:": "Sem presas automático:",
    "Toggle Food": "Alternar comida",
    "Map Size": "Tamanho do mapa",
    "Small Tags:": "Tags pequenas:",
    "Toggle graphics": "Alternar gráficos",
    "Skin/Nick Peek": "Espiar visual/apelido",
    "Graph": "Gráfico",
    "Toggle Online players": "Alternar jogadores on-line",
    "Show QQs": "Mostrar QQs",
    "Hide all Addons": "Ocultar todos os complementos",
    "Stealth mode:": "Modo furtivo:",
    "Open RTL": "Abrir classificação em tempo real",
    "Open Settings": "Abrir configurações",
    "Scaling": "Escala",
    "Press F11 for fullscreen": "Pressione F11 para usar a tela cheia",
    "Use [ctrl] + mouse scroll to change text size": "Use [Ctrl] + roda do mouse para alterar o tamanho do texto",
    "Press DEL or -- during play to clear this box": "Pressione DEL ou -- durante o jogo para limpar esta caixa",
    "Type !help for a list of commands": "Pressione ,, ou digite !comandos para abrir a central de comandos",
    "checking updates for public tags": "verificando atualizações das tags públicas",
    "found public tags v": "tags públicas encontradas: v",
    "checking updates for custom tags": "verificando atualizações das tags personalizadas",
    "found custom tags v": "tags personalizadas encontradas: v",
    "tag versions:": "Tags sincronizadas com o servidor Cobrinha Encasquetada:",
    "authorizing used custom tags": "carregando as tags personalizadas salvas localmente",
    "tag server timeout": "tempo limite excedido no servidor de tags",
    "authorization server mismatch error": "erro de divergência no servidor de autorização",
    "authorization server error": "erro no servidor de autorização",
    "Use right click to drag & left click to release anywhere inside any info box, pull on the red square to resize, click on the buton 'reset infoboxes' to restore them to default positions. New positions get saved AFTER closing the settings.": "Use o botão direito para arrastar e o esquerdo para soltar dentro de qualquer caixa. Redimensione pelo canto inferior direito. Clique em 'Restaurar painéis' para voltar às posições padrão. As posições são salvas ao fechar as configurações.",
    "custom background not found, fallback to none": "plano de fundo personalizado não encontrado; usando nenhum"
  };

  function tituloTop10EhPadrao(valor) {
    return !String(valor || "").trim() || /^(?:NTL\s*MOD|Cobrinha Encasquetada)\s*[-—]\s*Top 10$/i.test(String(valor).trim());
  }

  function normalizarTituloTop10Salvo() {
    try {
      const salvo = localStorage.getItem("NTLtop");
      if (tituloTop10EhPadrao(salvo)) localStorage.setItem("NTLtop", "TOP 10");
    } catch (erro) {}
  }

  function aplicarMarca(valor) {
    return valor
      .replace(/\bNTL\s*MOD\b/gi, "Cobrinha Encasquetada")
      .replace(/\bNTL\s+Mod\b/gi, "Cobrinha Encasquetada")
      .replace(/\bby\s+NTL\b/gi, "")
      .replace(/\bNTL\s+tag\s+uploader\b/gi, "Envio de tags")
      .replace(/\bNTL\s+textured\b/gi, "Texturizada clássica")
      .replace(/\bBackground:\s*NTL\b/gi, "Plano de fundo: clássico")
      .replace(/\bNTL\s+textures?\b/gi, "textura clássica")
      .replace(/\bNTL\b/g, "Cobrinha Encasquetada")
      .replace(/\bSettings\b/g, "Configurações");
  }

  function traduzTexto(no) {
    const pai = no.parentElement;
    const original = no.nodeValue;
    const textoLimpo = original.trimStart();
    // O MOD antigo consulta a Chrome Web Store e pode anunciar uma atualização
    // inexistente. Nosso canal usa o manifesto próprio da Cobrinha Encasquetada.
    if (/Update available in webstore|Click,\s*Remove then Add and Reload Slither/i.test(textoLimpo)) {
      no.nodeValue = "";
      if (pai && pai.id !== "chat" && pai.closest("#chat")) {
        queueMicrotask(function () {
          if (!pai.textContent.trim() && !pai.querySelector("input, button, img")) pai.remove();
        });
      }
      return;
    }
    if (/^(?:NTL\s*MOD|Cobrinha Encasquetada)\s*[-—]\s*Top 10$/i.test(original.trim())) {
      no.nodeValue = original.replace(original.trim(), "TOP 10");
      return;
    }
    // Esses contadores pertenciam ao catálogo do servidor anterior e não
    // representam as versões retornadas pela API própria do Lovable.
    if (/^tag versions:/i.test(textoLimpo)) {
      no.nodeValue = "";
      return;
    }
    const mensagemDoSistema = Boolean(
      pai && pai.closest("#chat") && textoLimpo.startsWith("#")
    );
    const ajudaDeComandos = Boolean(
      pai &&
      pai.closest("#chat") &&
      (/^available commands:/i.test(textoLimpo) || /^-\s*!/.test(textoLimpo) || /^-\s*timedemo/i.test(textoLimpo))
    );
    if (
      pai &&
      pai.closest("#chat, #ichat, [contenteditable='true']") &&
      !pai.closest("#divtl") &&
      !mensagemDoSistema &&
      !ajudaDeComandos
    ) return;
    if (pai && (pai.closest("#eemenu, #divtl") || mensagemDoSistema || ajudaDeComandos)) {
      let traduzido = original;
      for (const [ingles, portugues] of Object.entries(frasesPaineis)) {
        if (traduzido.includes(ingles)) traduzido = traduzido.split(ingles).join(portugues);
      }
      traduzido = traduzido.replace(/\ball (\d+) ok\b/gi, function (_, quantidade) {
        return quantidade === "1"
          ? "1 tag carregada localmente"
          : quantidade + " tags carregadas localmente";
      });
      if (traduzido !== original) {
        no.nodeValue = traduzido;
        return;
      }
    }
    const limpo = original.trim();
    if (!limpo) return;
    if (pai && pai.closest("#fps-hud") && /^MOD\s+v/i.test(limpo)) {
      no.nodeValue = original.replace(limpo, limpo.replace(/^MOD\s+/i, ""));
      return;
    }
    const traduzido = textos[limpo] || aplicarMarca(limpo);
    if (traduzido === limpo) return;
    no.nodeValue = original.replace(limpo, traduzido);
  }

  function traduzElemento(el) {
    if (!(el instanceof Element)) return;
    if (el.id === "set_toptitle" && el instanceof HTMLInputElement && tituloTop10EhPadrao(el.value)) {
      el.value = "TOP 10";
      el.placeholder = "TOP 10";
      try { localStorage.setItem("NTLtop", "TOP 10"); } catch (erro) {}
    }
    if (
      el.matches("button") &&
      ["RealTime Leaderboards", "Classificações em tempo real"].includes(el.textContent.trim())
    ) {
      el.style.display = "none";
      if (el.dataset.remocaoAgendada !== "1") {
        el.dataset.remocaoAgendada = "1";
        queueMicrotask(function () {
          const recipiente = el.parentElement;
          el.remove();
          if (recipiente && !recipiente.textContent.trim() && !recipiente.querySelector("input, button, select")) {
            recipiente.remove();
          }
        });
      }
      return;
    }
    if (el.matches("a[href*='chrome.google.com/webstore/detail/ntl-mod'], a[href*='youtube.com/watch?v=GE6jjPjds98']")) {
      el.style.display = "none";
      if (el.dataset.remocaoAgendada !== "1") {
        el.dataset.remocaoAgendada = "1";
        queueMicrotask(function () {
          const pai = el.parentElement;
          const anterior = el.previousSibling;
          if (anterior && anterior.nodeName === "BR") anterior.remove();
          el.remove();
          if (pai && !pai.textContent.trim() && !pai.querySelector("img, input, button")) pai.style.display = "none";
        });
      }
      return;
    }
    for (const atributo of ["title", "placeholder", "aria-label"]) {
      const valor = el.getAttribute(atributo);
      if (valor) {
        const traduzido = titulos[valor] || textos[valor] || atributosNormalizados[normalizarAtributo(valor)] || traduzAtributoDinamico(valor) || aplicarMarca(valor);
        if (traduzido !== valor) el.setAttribute(atributo, traduzido);
      }
    }
    if (el instanceof HTMLInputElement && ["button", "submit", "reset"].includes(el.type) && textos[el.value]) {
      const traduzido = textos[el.value];
      if (traduzido !== el.value) el.value = traduzido;
    }
    if (el instanceof HTMLInputElement && el.value && /\bNTL\b/i.test(el.value)) {
      el.value = aplicarMarca(el.value);
    }
    const href = el.getAttribute("href");
    const ehLinkNoticias = el instanceof HTMLAnchorElement && /^(?:notícias e informações|news\s*&\s*info)$/i.test(el.textContent.trim());
    if (el instanceof HTMLAnchorElement && ((href && ROTA_LEGADA_SITE.test(href)) || ehLinkNoticias)) {
      if (href !== SITE_OFICIAL) el.setAttribute("href", SITE_OFICIAL);
      if (el.getAttribute("target") !== "_blank") el.setAttribute("target", "_blank");
      if (el.getAttribute("rel") !== "noopener noreferrer") el.setAttribute("rel", "noopener noreferrer");
    }
    const src = el.getAttribute("src");
    if (el instanceof HTMLIFrameElement && src && ROTA_LEGADA_SITE.test(src)) {
      el.setAttribute("src", SITE_OFICIAL);
    }
  }

  function traduzArvore(raiz) {
    if (raiz.nodeType === Node.TEXT_NODE) {
      traduzTexto(raiz);
      return;
    }
    if (raiz.nodeType !== Node.ELEMENT_NODE && raiz.nodeType !== Node.DOCUMENT_NODE) return;
    if (raiz.nodeType === Node.ELEMENT_NODE) traduzElemento(raiz);
    const walker = document.createTreeWalker(raiz, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    let no;
    while ((no = walker.nextNode())) {
      if (no.nodeType === Node.TEXT_NODE) traduzTexto(no);
      else traduzElemento(no);
    }
  }

  normalizarTituloTop10Salvo();
  traduzArvore(document);
  new MutationObserver(function (mudancas) {
    for (const mudanca of mudancas) {
      if (mudanca.type === "characterData") traduzTexto(mudanca.target);
      if (mudanca.type === "attributes") traduzElemento(mudanca.target);
      for (const no of mudanca.addedNodes) traduzArvore(no);
    }
  }).observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true,
    attributes: true,
    attributeFilter: ["title", "placeholder", "aria-label", "href", "src"]
  });

  document.addEventListener("click", function (evento) {
    const link = evento.target instanceof Element ? evento.target.closest("a") : null;
    if (!link) return;
    const href = link.getAttribute("href") || "";
    const ehLinkNoticias = /^(?:notícias e informações|news\s*&\s*info)$/i.test(link.textContent.trim());
    if (!ROTA_LEGADA_SITE.test(href) && !ehLinkNoticias) return;
    if (href !== SITE_OFICIAL) link.setAttribute("href", SITE_OFICIAL);
    if (link.getAttribute("target") !== "_blank") link.setAttribute("target", "_blank");
    if (link.getAttribute("rel") !== "noopener noreferrer") link.setAttribute("rel", "noopener noreferrer");
  }, true);

  document.documentElement.lang = "pt-BR";
})();
