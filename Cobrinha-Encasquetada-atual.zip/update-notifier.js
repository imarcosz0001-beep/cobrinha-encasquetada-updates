(function () {
  "use strict";

  var API_URL = "https://snake-den-hub.lovable.app/api/public/team-api";
  var GITHUB_MANIFEST_URL = "https://raw.githubusercontent.com/imarcosz0001-beep/cobrinha-encasquetada-updates/main/addon-update.json";
  var currentVersion = chrome.runtime.getManifest().version;
  var update = null;
  var dismissed = false;

  function versionParts(value) {
    return String(value || "0").split(".").map(function (part) {
      var number = parseInt(part, 10);
      return Number.isFinite(number) ? number : 0;
    });
  }

  function isNewer(candidate, installed) {
    var left = versionParts(candidate);
    var right = versionParts(installed);
    var length = Math.max(left.length, right.length);
    for (var index = 0; index < length; index++) {
      var a = left[index] || 0;
      var b = right[index] || 0;
      if (a !== b) return a > b;
    }
    return false;
  }

  function menuIsVisible() {
    var login = document.getElementById("login");
    if (!login) return false;
    var style = getComputedStyle(login);
    var rect = login.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0.05 && rect.width > 0 && rect.height > 0;
  }

  function setMessage(text, kind) {
    var message = document.getElementById("cobrinha-update-message");
    if (!message) return;
    message.textContent = text;
    message.dataset.kind = kind || "info";
  }

  function refreshVisibility() {
    var banner = document.getElementById("cobrinha-update-banner");
    if (!banner) return;
    banner.hidden = dismissed || !update || !menuIsVisible();
  }

  function createBanner() {
    if (!document.body || document.getElementById("cobrinha-update-banner") || !update) return;
    var banner = document.createElement("aside");
    banner.id = "cobrinha-update-banner";
    banner.setAttribute("role", "status");

    var text = document.createElement("div");
    var title = document.createElement("strong");
    title.textContent = "Atualização disponível";
    var message = document.createElement("span");
    message.id = "cobrinha-update-message";
    message.textContent = "Versão " + update.version + (update.notes ? " · " + update.notes : "");
    text.appendChild(title);
    text.appendChild(message);

    var install = document.createElement("button");
    install.type = "button";
    install.className = "cobrinha-update-action";
    install.textContent = "Atualizar";
    install.addEventListener("click", function () {
      install.disabled = true;
      install.textContent = "Baixando…";
      setMessage("Preparando o pacote da versão " + update.version + "…", "busy");
      chrome.runtime.sendMessage({
        type: "cobrinhaDownloadUpdate",
        url: update.downloadUrl,
        version: update.version
      }, function (response) {
        if (chrome.runtime.lastError || !response || !response.ok) {
          install.disabled = false;
          install.textContent = "Tentar novamente";
          setMessage(response && response.error || "Não foi possível baixar a atualização.", "error");
          return;
        }
        install.textContent = "Download iniciado";
        setMessage("Pacote baixado. Substitua a pasta do addon e recarregue-o em Extensões.", "success");
      });
    });

    var close = document.createElement("button");
    close.type = "button";
    close.className = "cobrinha-update-close";
    close.textContent = "×";
    close.title = "Lembrar depois";
    close.setAttribute("aria-label", close.title);
    close.addEventListener("click", function () {
      dismissed = true;
      refreshVisibility();
    });

    banner.appendChild(text);
    banner.appendChild(install);
    banner.appendChild(close);
    document.body.appendChild(banner);
    refreshVisibility();
  }

  function normalizeUpdate(data) {
    var source = data && (data.update || data.data || data);
    if (!source || typeof source !== "object") return null;
    var version = String(source.version || source.latest_version || "").trim();
    var downloadUrl = String(source.download_url || source.package_url || source.url || "").trim();
    if (!version || !isNewer(version, currentVersion) || !/^https:\/\//i.test(downloadUrl)) return null;
    return {
      version: version,
      downloadUrl: downloadUrl,
      notes: String(source.notes || source.message || "").trim().slice(0, 140)
    };
  }

  function checkForUpdate() {
    var controller = new AbortController();
    var timeout = setTimeout(function () { controller.abort(); }, 8000);
    var requestBody = JSON.stringify({
      action: "get_addon_update",
      current_version: currentVersion,
      extension_id: chrome.runtime.id,
      browser: navigator.userAgent
    });

    function readLovable() {
      return fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: requestBody,
        signal: controller.signal
      }).then(function (response) {
        if (!response.ok) throw new Error("API do Lovable ainda não publicada");
        return response.json();
      }).then(function (data) {
        var candidate = normalizeUpdate(data);
        if (!candidate) throw new Error("Nenhuma atualização no Lovable");
        return candidate;
      });
    }

    function readGithub() {
      return fetch(GITHUB_MANIFEST_URL + "?installed=" + encodeURIComponent(currentVersion), {
        method: "GET",
        cache: "no-store",
        signal: controller.signal
      }).then(function (response) {
        if (!response.ok) throw new Error("Manifesto do GitHub indisponível");
        return response.json();
      }).then(normalizeUpdate);
    }

    readLovable().catch(function () {
      return readGithub();
    }).then(function (candidate) {
      update = candidate;
      if (update) createBanner();
    }).catch(function () {
      // Nenhum servidor respondeu. Isso nunca deve impedir o jogo de abrir.
    }).finally(function () {
      clearTimeout(timeout);
    });
  }

  checkForUpdate();
  setInterval(refreshVisibility, 400);
})();
