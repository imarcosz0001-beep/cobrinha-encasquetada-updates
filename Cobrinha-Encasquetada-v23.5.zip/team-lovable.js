(function () {
  "use strict";

  var API_URL = "https://cobrinhaencasquetada.lovable.app/api/public/team-api";
  var ROOM_KEY = "cobrinhaSala";
  var CLIENT_KEY = "cobrinhaCliente";
  var NICK_KEY = "cobrinhaApelido";
  var FRIENDS_KEY = "cobrinhaFriendsV1";
  var FRIEND_PRIVACY_KEY = "cobrinhaFriendPrivacyV1";
  var FRIEND_TOKEN_KEY = "cobrinhaFriendPresenceTokenV1";
  var FRIEND_FOLLOW_KEY = "cobrinhaFriendFollowV1";
  var roomCode = (localStorage.getItem(ROOM_KEY) || "").toUpperCase();
  var clientId = localStorage.getItem(CLIENT_KEY) || makeClientId();
  var nickname = localStorage.getItem(NICK_KEY) || "";
  var busy = false;
  var heartbeatBusy = false;
  var listBusy = false;
  var messageBusy = false;
  var chatApiUnavailable = false;
  var lastMessageId = 0;
  var lastPlayers = [];
  var knownFriendPresence = null;
  var globalFriendPresence = [];
  var globalPresenceBusy = false;
  var globalListBusy = false;
  var presenceToken = localStorage.getItem(FRIEND_TOKEN_KEY) || makePresenceToken();
  var scheduledTasks = [];
  var backendHealth = { status: "waiting", failures: 0, latency: 0, lastSuccess: "", message: "Aguardando uso" };

  function scheduleTask(name, callback, interval, hiddenInterval) {
    scheduledTasks.push({ name: name, callback: callback, interval: interval, hiddenInterval: hiddenInterval || interval, nextAt: Date.now() + interval, running: false });
  }

  setInterval(function () {
    var timestamp = Date.now();
    scheduledTasks.forEach(function (task) {
      if (task.running || timestamp < task.nextAt) return;
      task.nextAt = timestamp + (document.hidden ? task.hiddenInterval : task.interval);
      task.running = true;
      try {
        var result = task.callback();
        if (result && typeof result.finally === "function") result.finally(function () { task.running = false; });
        else task.running = false;
      } catch (error) { task.running = false; }
    });
  }, 250);

  localStorage.setItem(CLIENT_KEY, clientId);
  localStorage.setItem(FRIEND_TOKEN_KEY, presenceToken);

  function makeClientId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return window.crypto.randomUUID();
    }
    return "cobrinha-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
  }

  function makePresenceToken() {
    var values = new Uint8Array(32);
    if (window.crypto && typeof window.crypto.getRandomValues === "function") window.crypto.getRandomValues(values);
    else for (var index = 0; index < values.length; index++) values[index] = Math.floor(Math.random() * 256);
    return Array.prototype.map.call(values, function (value) { return value.toString(16).padStart(2, "0"); }).join("");
  }

  function post(payload) {
    var controller = new AbortController();
    var timeout = setTimeout(function () { controller.abort(); }, 9000);
    var startedAt = Date.now();
    return fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (data) {
        if (response.status >= 500) updateBackendHealth(false, "O serviço respondeu com erro.", Date.now() - startedAt);
        else updateBackendHealth(true, "", Date.now() - startedAt);
        if (!response.ok || data.ok === false) {
          var apiError = new Error(data.error || data.message || "A API recusou a solicitação.");
          apiError.cobrinhaBackendReachable = true;
          throw apiError;
        }
        return data;
      });
    }).catch(function (error) {
      if (!error || !error.cobrinhaBackendReachable) {
        updateBackendHealth(false, error && error.name === "AbortError" ? "Tempo de resposta esgotado." : "Sem conexão com o serviço.", Date.now() - startedAt);
      }
      throw error;
    }).finally(function () {
      clearTimeout(timeout);
    });
  }

  function backendHealthText() {
    if (backendHealth.status === "online") return "Online";
    if (backendHealth.status === "degraded") return "Instável";
    if (backendHealth.status === "offline") return "Indisponível";
    return "Aguardando";
  }

  function renderBackendHealth() {
    var text = "● " + backendHealthText();
    document.querySelectorAll(".lovable-team-health").forEach(function (element) {
      element.textContent = text;
      element.setAttribute("data-status", backendHealth.status);
      element.title = backendHealth.status === "online"
        ? "Serviço de equipe funcionando" + (backendHealth.latency ? " · " + backendHealth.latency + " ms" : "")
        : backendHealth.message + " O jogo continua funcionando normalmente.";
    });
    document.documentElement.dataset.cobrinhaBackendStatus = backendHealth.status;
    document.documentElement.dataset.cobrinhaBackendFailures = String(backendHealth.failures);
    document.documentElement.dataset.cobrinhaBackendLatency = String(backendHealth.latency || 0);
    window.dispatchEvent(new CustomEvent("cobrinha-backend-status", { detail: Object.assign({}, backendHealth) }));
  }

  function updateBackendHealth(success, message, latency) {
    var previous = backendHealth.status;
    if (success) {
      backendHealth.status = "online";
      backendHealth.failures = 0;
      backendHealth.latency = Math.max(0, Math.round(Number(latency) || 0));
      backendHealth.lastSuccess = new Date().toISOString();
      backendHealth.message = "Serviço funcionando";
    } else {
      backendHealth.failures += 1;
      backendHealth.latency = Math.max(0, Math.round(Number(latency) || 0));
      backendHealth.status = backendHealth.failures >= 2 ? "offline" : "degraded";
      backendHealth.message = String(message || "Serviço temporariamente indisponível.");
    }
    renderBackendHealth();
    if (backendHealth.status === "offline" && previous !== "offline") {
      systemMessage("Equipe, presença e chat estão temporariamente indisponíveis. O jogo continua normal e a reconexão será automática.");
    } else if (backendHealth.status === "online" && (previous === "offline" || previous === "degraded")) {
      systemMessage("Serviço de equipe restabelecido.");
    }
  }

  function cleanCode(value) {
    return String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
  }

  function currentNickname() {
    var field = document.getElementById("in_comkey");
    var gameNick = document.getElementById("nick");
    return String((field && field.value) || nickname || (gameNick && gameNick.value) || "").trim().slice(0, 32);
  }

  function currentGameState() {
    var gameSnake = window.snake;
    var isPlaying = Boolean(window.playing && gameSnake);
    var server = "";
    var score = 0;

    if (isPlaying && window.bso && window.bso.ip && window.bso.po) {
      server = window.bso.ip + ":" + window.bso.po;
    } else if (isPlaying && typeof window.KP === "string") {
      server = window.KP;
    }

    if (isPlaying) {
      try {
        score = Math.floor(15 * (window.fpsls[gameSnake.sct] + gameSnake.fam / window.fmlts[gameSnake.sct] - 1) - 5);
      } catch (ignore) {
        score = 0;
      }
    }

    return {
      server_address: server,
      position_x: isPlaying ? Math.round(gameSnake.xx || 0) : 0,
      position_y: isPlaying ? Math.round(gameSnake.yy || 0) : 0,
      score: Math.max(0, score || 0),
      status: isPlaying ? "jogando" : "no menu"
    };
  }

  function setStatus(message, kind) {
    var status = document.getElementById("lovable-team-settings-status");
    if (status) {
      status.textContent = message || "";
      status.setAttribute("data-kind", kind || "ok");
    }
  }

  function systemMessage(message) {
    try {
      if (typeof window.R === "function" && window.y) {
        window.R(window.y, "# " + message);
        return;
      }
    } catch (ignore) {}
    console.log("[Cobrinha Encasquetada]", message);
  }

  function escapeChat(value) {
    return String(value || "").replace(/[&<>]/g, function (character) {
      return character === "&" ? "&amp;" : character === "<" ? "&lt;" : "&gt;";
    });
  }

  function renderRoomMessage(message) {
    if (!message || !message.message) return;
    try {
      if (typeof window.R === "function") {
        window.R(escapeChat(message.nickname || "Jogador"), escapeChat(message.message));
      }
    } catch (ignore) {}
  }

  function sendRoomMessage(text) {
    text = String(text || "").trim().slice(0, 300);
    if (!roomCode || !text || messageBusy) return Promise.resolve();
    messageBusy = true;
    return post({
      action: "send_message",
      room_code: roomCode,
      client_id: clientId,
      nickname: currentNickname() || nickname,
      message: text
    }).then(function () {
      chatApiUnavailable = false;
      return listRoomMessages();
    }).catch(function () {
      if (!chatApiUnavailable) {
        systemMessage("O backend do chat ainda não foi publicado no Lovable. Os comandos com ! continuam funcionando.");
      }
      chatApiUnavailable = true;
    }).finally(function () {
      messageBusy = false;
    });
  }

  function listRoomMessages() {
    if (!roomCode || chatApiUnavailable) return Promise.resolve();
    return post({
      action: "list_messages",
      room_code: roomCode,
      client_id: clientId,
      after_id: lastMessageId
    }).then(function (data) {
      var messages = Array.isArray(data.messages) ? data.messages : [];
      messages.forEach(function (message) {
        var id = Number(message.id) || 0;
        if (id > lastMessageId) {
          renderRoomMessage(message);
          lastMessageId = id;
        }
      });
      var returnedCursor = Number(data.last_id) || 0;
      if (returnedCursor > lastMessageId) lastMessageId = returnedCursor;
    }).catch(function () {
      chatApiUnavailable = true;
    });
  }

  // O campo #ichat passa a usar o chat da sala Lovable. Comandos iniciados por
  // "!" continuam sendo processados pelo próprio mod.
  document.addEventListener("keydown", function (event) {
    var field = event.target;
    if (!field || field.id !== "ichat") return;
    if (!(event.key === "Enter" || event.code === "NumpadEnter" || event.keyCode === 13)) return;
    var value = String(field.value || "").trim();
    if (!value || value.charAt(0) === "!") return;
    if (!roomCode && window.Lf === false) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    field.value = "";
    if (roomCode) sendRoomMessage(value);
    else systemMessage("Entre em uma sala do Lovable antes de enviar mensagens.");
  }, true);

  function setBusy(value) {
    busy = value;
    ["loadkeys", "savekeys", "noteam"].forEach(function (id) {
      var button = document.getElementById(id);
      if (button) button.disabled = value;
    });
  }

  function saveSession(code, nick) {
    var previousRoom = roomCode;
    roomCode = cleanCode(code);
    nickname = String(nick || "").trim().slice(0, 32);
    localStorage.setItem(ROOM_KEY, roomCode);
    localStorage.setItem(NICK_KEY, nickname);
    if (previousRoom !== roomCode) {
      lastMessageId = 0;
      chatApiUnavailable = false;
    }
    updateSettingsValues();
    renderPanel();
  }

  function clearSession() {
    roomCode = "";
    lastMessageId = 0;
    chatApiUnavailable = false;
    lastPlayers = [];
    knownFriendPresence = null;
    window.cobrinhaLovableFriendNames = [];
    localStorage.removeItem(ROOM_KEY);
    updateSettingsValues();
    renderPanel();
    renderFriendArrow();
  }

  function join(code, nick) {
    code = cleanCode(code);
    nick = String(nick || "").trim().slice(0, 32);
    if (code.length !== 8) throw new Error("Digite um código de sala com 8 caracteres.");
    if (!nick) throw new Error("Digite seu apelido.");

    return post({
      action: "join_room",
      room_code: code,
      client_id: clientId,
      nickname: nick
    }).then(function () {
      saveSession(code, nick);
      setStatus("Você entrou na sala " + code + ".", "ok");
      return sendHeartbeat();
    });
  }

  function createRoom() {
    var nick = currentNickname();
    if (!nick) return Promise.reject(new Error("Digite seu apelido antes de criar a sala."));
    return post({ action: "create_room" }).then(function (data) {
      var code = cleanCode(data.code || data.room_code);
      if (code.length !== 8) throw new Error("A API não devolveu um código de sala válido.");
      return join(code, nick).then(function () {
        setStatus("Sala " + code + " criada. Envie este código ao seu amigo.", "ok");
      });
    });
  }

  function leaveRoom() {
    if (!roomCode) {
      clearSession();
      setStatus("Você não está em uma sala.", "ok");
      return Promise.resolve();
    }
    var oldCode = roomCode;
    return post({ action: "leave_room", room_code: oldCode, client_id: clientId })
      .catch(function () {})
      .then(function () {
        clearSession();
        setStatus("Você saiu da sala " + oldCode + ".", "ok");
      });
  }

  function sendHeartbeat() {
    if (!roomCode || heartbeatBusy) return Promise.resolve();
    heartbeatBusy = true;
    var state = currentGameState();
    return post({
      action: "heartbeat",
      room_code: roomCode,
      client_id: clientId,
      nickname: nickname,
      server_address: state.server_address,
      position_x: state.position_x,
      position_y: state.position_y,
      score: state.score,
      status: state.status
    }).catch(function () {
      setStatus("Sem resposta da sala. Tentando novamente...", "error");
    }).finally(function () {
      heartbeatBusy = false;
    });
  }

  function listPlayers() {
    if (!roomCode || listBusy) return Promise.resolve();
    listBusy = true;
    return post({ action: "list_players", room_code: roomCode }).then(function (data) {
      lastPlayers = Array.isArray(data.players) ? data.players : [];
      syncFriendMetadata(lastPlayers);
      publishSameServerFriends();
      trackFriendPresence();
      renderPanel();
      renderTeammatesOnMinimap();
      renderFriendArrow();
    }).catch(function () {
      renderPanel("Não foi possível atualizar a equipe.");
    }).finally(function () {
      listBusy = false;
    });
  }

  function normalizedServer(value) {
    return String(value || "").trim().toLowerCase().replace(/^wss?:\/\//, "").replace(/\/ptc\/?$/, "");
  }

  function normalizedNickname(value) {
    return String(value || "").trim().toLocaleLowerCase();
  }

  function savedFriends() {
    try {
      var friends = JSON.parse(localStorage.getItem(FRIENDS_KEY) || "[]");
      return Array.isArray(friends) ? friends : [];
    } catch (error) { return []; }
  }

  function friendPrivacy() {
    var defaults = { sharePresence: true, shareServer: true, sharePosition: true, notifications: true };
    try {
      var saved = JSON.parse(localStorage.getItem(FRIEND_PRIVACY_KEY) || "{}");
      return Object.assign(defaults, saved && typeof saved === "object" ? saved : {});
    } catch (error) { return defaults; }
  }

  function setFriendPrivacy(next) {
    var privacy = Object.assign(friendPrivacy(), next || {});
    if (next && next.sharePosition === true) {
      privacy.sharePresence = true;
      privacy.shareServer = true;
    } else if (next && next.shareServer === true) {
      privacy.sharePresence = true;
    }
    if (!privacy.sharePresence) {
      privacy.shareServer = false;
      privacy.sharePosition = false;
    }
    if (!privacy.shareServer) privacy.sharePosition = false;
    localStorage.setItem(FRIEND_PRIVACY_KEY, JSON.stringify(privacy));
    window.dispatchEvent(new CustomEvent("cobrinha-friend-privacy-changed", { detail: privacy }));
    sendGlobalPresence();
    return privacy;
  }

  function syncFriendMetadata(players) {
    var friends = savedFriends();
    var changed = false;
    (players || []).forEach(function (player) {
      var friend = friends.find(function (item) {
        return item && ((item.clientId && item.clientId === player.client_id) || normalizedNickname(item.nickname || item.name) === normalizedNickname(player.nickname));
      });
      if (!friend) return;
      if (player.nickname) friend.nickname = String(player.nickname).slice(0, 32);
      friend.lastSeen = player.last_seen || new Date().toISOString();
      friend.status = player.online === false ? "offline" : String(player.status || "online");
      friend.server = player.server_address || "";
      changed = true;
    });
    if (changed) {
      localStorage.setItem(FRIENDS_KEY, JSON.stringify(friends));
      window.dispatchEvent(new CustomEvent("cobrinha-friend-presence-updated"));
    }
  }

  function sendGlobalPresence() {
    if (globalPresenceBusy) return Promise.resolve();
    var nick = currentNickname();
    if (!nick) return Promise.resolve();
    globalPresenceBusy = true;
    var privacy = friendPrivacy();
    var game = currentGameState();
    return post({
      action: "update_friend_presence",
      client_id: clientId,
      presence_token: presenceToken,
      nickname: nick,
      server_address: privacy.shareServer ? game.server_address : "",
      position_x: privacy.sharePosition ? game.position_x : 0,
      position_y: privacy.sharePosition ? game.position_y : 0,
      score: game.score,
      status: game.status,
      presence_visible: privacy.sharePresence,
      share_server: privacy.shareServer,
      share_position: privacy.sharePosition
    }).catch(function () {}).finally(function () { globalPresenceBusy = false; });
  }

  function listGlobalFriendPresence() {
    if (globalListBusy) return Promise.resolve();
    var ids = savedFriends().map(function (friend) { return friend && friend.clientId; }).filter(Boolean);
    if (!ids.length) {
      globalFriendPresence = [];
      return Promise.resolve();
    }
    globalListBusy = true;
    return post({ action: "get_friend_presence", client_id: clientId, friend_ids: ids }).then(function (data) {
      globalFriendPresence = Array.isArray(data.friends) ? data.friends : [];
      syncFriendMetadata(globalFriendPresence);
      publishSameServerFriends();
      trackFriendPresence();
      renderTeammatesOnMinimap();
      renderFriendArrow();
    }).catch(function () {}).finally(function () { globalListBusy = false; });
  }

  function isSavedFriend(player, friends) {
    if (!player) return false;
    friends = friends || savedFriends();
    var normalized = normalizedNickname(player.nickname);
    return friends.some(function (friend) {
      return friend && ((friend.clientId && friend.clientId === player.client_id) || normalizedNickname(friend.nickname || friend.name) === normalized);
    });
  }

  function toggleSavedFriend(player) {
    if (!player || player.client_id === clientId) return;
    var friends = savedFriends();
    var normalized = normalizedNickname(player.nickname);
    var existing = friends.findIndex(function (friend) {
      return friend && ((friend.clientId && friend.clientId === player.client_id) || normalizedNickname(friend.nickname || friend.name) === normalized);
    });
    if (existing >= 0) {
      friends.splice(existing, 1);
      systemMessage((player.nickname || "Amigo") + " foi removido dos amigos.");
    } else {
      friends.push({ clientId: player.client_id || "", nickname: String(player.nickname || "Amigo").slice(0, 32), addedAt: Date.now(), lastSeen: player.last_seen || new Date().toISOString(), status: player.status || "online", server: player.server_address || "" });
      systemMessage("★ " + (player.nickname || "Amigo") + " foi adicionado aos amigos.");
    }
    localStorage.setItem(FRIENDS_KEY, JSON.stringify(friends));
    window.dispatchEvent(new CustomEvent("cobrinha-friends-changed"));
    renderPanel();
    renderTeammatesOnMinimap();
    renderFriendArrow();
  }

  function activeSavedFriends() {
    var ownServer = normalizedServer(currentGameState().server_address);
    var friends = savedFriends();
    if (!ownServer) return [];
    var combined = lastPlayers.concat(globalFriendPresence).filter(function (player, index, list) {
      var key = player && (player.client_id || normalizedNickname(player.nickname));
      return key && list.findIndex(function (candidate) { return (candidate.client_id || normalizedNickname(candidate.nickname)) === key; }) === index;
    });
    return combined.filter(function (player) {
      return player && player.client_id !== clientId && isSavedFriend(player, friends) &&
        normalizedServer(player.server_address) === ownServer &&
        String(player.status || "").toLowerCase() === "jogando";
    });
  }

  function trackFriendPresence() {
    var active = activeSavedFriends();
    var current = {};
    active.forEach(function (player) {
      var key = player.client_id || normalizedNickname(player.nickname);
      current[key] = true;
      if (friendPrivacy().notifications && knownFriendPresence && !knownFriendPresence[key]) systemMessage("★ " + (player.nickname || "Amigo") + " entrou no seu servidor.");
    });
    knownFriendPresence = current;
  }

  function publishSameServerFriends() {
    var ownServer = normalizedServer(currentGameState().server_address);
    if (!roomCode || !ownServer) {
      window.cobrinhaLovableFriendNames = [];
      return;
    }
    window.cobrinhaLovableFriendNames = activeSavedFriends().filter(function (player) {
      return player &&
        player.client_id !== clientId &&
        normalizedServer(player.server_address) === ownServer;
    }).map(function (player) {
      return normalizedNickname(player.nickname);
    }).filter(Boolean);
  }

  function playerCoordinate(player, primary, fallback) {
    var value = Number(player && player[primary]);
    if (!Number.isFinite(value)) value = Number(player && player[fallback]);
    return Number.isFinite(value) ? value : 0;
  }

  function markerColor(value) {
    value = String(value || "amigo");
    var hash = 0;
    for (var index = 0; index < value.length; index++) hash = ((hash << 5) - hash + value.charCodeAt(index)) | 0;
    return "hsl(" + Math.abs(hash % 360) + " 88% 62%)";
  }

  function renderTeammatesOnMinimap() {
    var minimap = document.getElementById("mmap");
    if (!minimap) return;
    var layer = document.getElementById("lovable-team-map-layer");
    if (!layer) {
      layer = document.createElement("div");
      layer.id = "lovable-team-map-layer";
      minimap.appendChild(layer);
    }
    layer.textContent = "";

    var ownState = currentGameState();
    var friends = savedFriends();
    var ownServer = normalizedServer(ownState.server_address);
    if (!roomCode || !ownServer || ownState.status !== "jogando") return;

    var size = minimap.getBoundingClientRect().width || minimap.offsetWidth || 104;
    var scale = size / 104;
    var center = 52 * scale;
    var mapRadius = 40 * scale;
    var worldCenter = Number(window.af);
    if (!Number.isFinite(worldCenter) || worldCenter <= 0) worldCenter = 16384;
    var worldRadius = window.V0 && window.rs ? Number(window.BQ) : worldCenter;
    if (!Number.isFinite(worldRadius) || worldRadius <= 0) worldRadius = worldCenter;

    var mapPlayers = lastPlayers.concat(globalFriendPresence).filter(function (player, index, list) {
      var key = player && (player.client_id || normalizedNickname(player.nickname));
      return key && list.findIndex(function (candidate) { return (candidate.client_id || normalizedNickname(candidate.nickname)) === key; }) === index;
    });
    mapPlayers.forEach(function (player) {
      if (!player || player.client_id === clientId || normalizedServer(player.server_address) !== ownServer) return;
      if (String(player.status || "").toLowerCase() !== "jogando") return;
      var worldX = playerCoordinate(player, "position_x", "x");
      var worldY = playerCoordinate(player, "position_y", "y");
      if (!worldX && !worldY) return;

      var dx = mapRadius * (worldX - worldCenter) / worldRadius;
      var dy = mapRadius * (worldY - worldCenter) / worldRadius;
      var distance = Math.sqrt(dx * dx + dy * dy);
      if (distance > mapRadius - 2) {
        dx *= (mapRadius - 2) / distance;
        dy *= (mapRadius - 2) / distance;
      }

      var marker = document.createElement("div");
      marker.className = "lovable-team-map-marker";
      if (isSavedFriend(player, friends)) marker.classList.add("is-favorite");
      marker.style.left = (center + dx) + "px";
      marker.style.top = (center + dy) + "px";
      marker.style.setProperty("--friend-color", markerColor(player.client_id || player.nickname));
      marker.title = (player.nickname || "Amigo") + " · tamanho " + (Number(player.score) || 0);

      var dot = document.createElement("span");
      dot.className = "lovable-team-map-dot";
      marker.appendChild(dot);
      var label = document.createElement("span");
      label.className = "lovable-team-map-label";
      label.textContent = (isSavedFriend(player, friends) ? "★ " : "") + String(player.nickname || "Amigo").slice(0, 14);
      marker.appendChild(label);
      layer.appendChild(marker);
    });
  }

  function renderFriendArrow() {
    var arrow = document.getElementById("lovable-friend-arrow");
    var ownState = currentGameState();
    var friends = activeSavedFriends();
    if (ownState.status !== "jogando" || !friends.length) {
      if (arrow) arrow.hidden = true;
      return;
    }
    var followedId = localStorage.getItem(FRIEND_FOLLOW_KEY) || "";
    var followed = followedId && friends.find(function (player) { return player.client_id === followedId; });
    if (followed) friends = [followed];
    var nearest = null;
    var nearestDistance = Infinity;
    friends.forEach(function (player) {
      var dx = playerCoordinate(player, "position_x", "x") - ownState.position_x;
      var dy = playerCoordinate(player, "position_y", "y") - ownState.position_y;
      var distance = Math.sqrt(dx * dx + dy * dy);
      if (distance && distance < nearestDistance) {
        nearestDistance = distance;
        nearest = { player: player, dx: dx, dy: dy };
      }
    });
    if (!nearest) {
      if (arrow) arrow.hidden = true;
      return;
    }
    if (!arrow) {
      arrow = document.createElement("div");
      arrow.id = "lovable-friend-arrow";
      var pointer = document.createElement("span");
      pointer.className = "lovable-friend-arrow-pointer";
      pointer.textContent = "➤";
      var label = document.createElement("span");
      label.className = "lovable-friend-arrow-label";
      arrow.appendChild(pointer);
      arrow.appendChild(label);
      document.body.appendChild(arrow);
    }
    var angle = Math.atan2(nearest.dy, nearest.dx);
    var radius = Math.max(90, Math.min(window.innerWidth, window.innerHeight) * 0.32);
    arrow.style.left = Math.round(window.innerWidth / 2 + Math.cos(angle) * radius) + "px";
    arrow.style.top = Math.round(window.innerHeight / 2 + Math.sin(angle) * radius) + "px";
    arrow.style.setProperty("--friend-arrow-angle", angle + "rad");
    arrow.style.setProperty("--friend-color", markerColor(nearest.player.client_id || nearest.player.nickname));
    arrow.querySelector(".lovable-friend-arrow-label").textContent = (followed ? "SEGUINDO ★ " : "★ ") + String(nearest.player.nickname || "Amigo").slice(0, 18) + " · " + Math.round(nearestDistance);
    arrow.hidden = false;
  }

  function renderPanel(errorMessage) {
    var panel = document.getElementById("lovable-team-panel");
    var official = document.getElementById("divpl");

    if (!roomCode) {
      if (panel) panel.remove();
      if (official) official.style.display = "";
      return;
    }

    if (!panel) {
      panel = document.createElement("div");
      panel.id = "lovable-team-panel";
      document.body.appendChild(panel);
    }
    if (official) official.style.display = "none";

    panel.textContent = "";
    var title = document.createElement("div");
    title.className = "lovable-team-title";
    title.appendChild(document.createTextNode("Equipe"));
    var health = document.createElement("span");
    health.className = "lovable-team-health";
    health.setAttribute("role", "status");
    health.setAttribute("aria-live", "polite");
    title.appendChild(health);
    panel.appendChild(title);

    var status = document.createElement("div");
    status.className = "lovable-team-status";
    if (errorMessage) {
      status.textContent = backendHealth.status === "offline"
        ? "Serviço indisponível · tentando reconectar"
        : errorMessage;
    } else {
      status.appendChild(document.createTextNode("sala - "));
      var code = document.createElement("span");
      code.className = "lovable-team-room";
      code.textContent = roomCode;
      status.appendChild(code);
      status.appendChild(document.createTextNode(" - " + lastPlayers.length + (lastPlayers.length === 1 ? " conectado" : " conectados")));
    }
    panel.appendChild(status);

    var friends = savedFriends();
    lastPlayers.forEach(function (player) {
      var row = document.createElement("div");
      row.className = "lovable-team-player";
      var name = document.createElement("div");
      name.className = "lovable-team-player-name";
      name.textContent = (player.client_id === clientId ? "● " : "◆ ") + (player.nickname || "Sem nome") + (player.client_id === clientId ? " (você)" : "");
      if (player.client_id !== clientId) {
        var favorite = document.createElement("button");
        favorite.type = "button";
        favorite.className = "lovable-team-favorite" + (isSavedFriend(player, friends) ? " is-favorite" : "");
        favorite.textContent = isSavedFriend(player, friends) ? "★" : "☆";
        favorite.title = isSavedFriend(player, friends) ? "Remover dos amigos" : "Adicionar aos amigos";
        favorite.setAttribute("aria-label", favorite.title);
        favorite.addEventListener("click", function (event) {
          event.preventDefault();
          event.stopPropagation();
          toggleSavedFriend(player);
        });
        name.appendChild(favorite);
      }
      row.appendChild(name);

      var meta = document.createElement("div");
      meta.className = "lovable-team-player-meta";
      meta.textContent = (player.status || "online") + " · tamanho " + (Number(player.score) || 0) + (player.server_address ? " · " + player.server_address : "");
      row.appendChild(meta);

      panel.appendChild(row);
    });
    renderBackendHealth();
  }

  function updateSettingsValues() {
    var code = document.getElementById("in_tidkey");
    var nick = document.getElementById("in_comkey");
    if (code) code.value = roomCode;
    if (nick) nick.value = nickname;
  }

  function customizeSettings() {
    var page = document.getElementById("settpage");
    var code = document.getElementById("in_tidkey");
    var auth = document.getElementById("in_authkey");
    var nick = document.getElementById("in_comkey");
    if (!page || !code || !auth || !nick) return;
    if (page.getAttribute("data-lovable-team-ready") === "1") return;
    page.setAttribute("data-lovable-team-ready", "1");

    code.maxLength = 8;
    code.placeholder = "código de 8 caracteres";
    code.value = roomCode;
    code.addEventListener("input", function () {
      var cleaned = cleanCode(code.value);
      if (code.value !== cleaned) code.value = cleaned;
    });
    var codeLabel = code.closest("tr").querySelector("td");
    if (codeLabel) codeLabel.textContent = "Código da sala:";

    var authRow = auth.closest("tr");
    if (authRow) authRow.style.display = "none";

    nick.placeholder = "seu nome na equipe";
    nick.value = nickname;
    var nickLabel = nick.closest("tr").querySelector("td");
    if (nickLabel) nickLabel.textContent = "Seu apelido:";

    var create = document.getElementById("loadkeys");
    var enter = document.getElementById("savekeys");
    var leave = document.getElementById("noteam");
    var saved = document.getElementById("select-key");
    var remove = document.getElementById("deletekey");
    if (create) create.textContent = "Criar sala";
    if (enter) enter.textContent = "Entrar";
    if (leave) leave.textContent = "Sair da sala";
    if (saved) saved.style.display = "none";
    if (remove) remove.style.display = "none";

    if (!document.getElementById("lovable-team-settings-row")) {
      var controlsRow = create && create.closest("tr");
      if (controlsRow) {
        var infoRow = document.createElement("tr");
        infoRow.id = "lovable-team-settings-row";
        var cell = document.createElement("td");
        cell.colSpan = 2;
        var info = document.createElement("span");
        info.id = "lovable-team-settings-status";
        info.textContent = roomCode ? "Conectado à sala " + roomCode + "." : "Crie uma sala ou digite o código enviado pelo seu amigo.";
        cell.appendChild(info);
        infoRow.appendChild(cell);
        controlsRow.parentNode.insertBefore(infoRow, controlsRow.nextSibling);
      }
    }
    if (!document.getElementById("lovable-team-health-row")) {
      var referenceRow = document.getElementById("lovable-team-settings-row");
      var healthRow = document.createElement("tr");
      healthRow.id = "lovable-team-health-row";
      var healthCell = document.createElement("td");
      healthCell.colSpan = 2;
      var healthStatus = document.createElement("span");
      healthStatus.className = "lovable-team-health";
      healthStatus.setAttribute("role", "status");
      healthStatus.setAttribute("aria-live", "polite");
      healthCell.appendChild(healthStatus);
      healthRow.appendChild(healthCell);
      if (referenceRow && referenceRow.parentNode) referenceRow.parentNode.insertBefore(healthRow, referenceRow.nextSibling);
    }
    renderBackendHealth();
  }

  document.addEventListener("click", function (event) {
    var button = event.target && event.target.closest ? event.target.closest("button") : null;
    if (!button || ["loadkeys", "savekeys", "noteam"].indexOf(button.id) === -1) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (busy) return;

    setBusy(true);
    setStatus("Aguarde...", "busy");
    var operation;
    try {
      if (button.id === "loadkeys") operation = createRoom();
      else if (button.id === "savekeys") operation = join(document.getElementById("in_tidkey").value, currentNickname());
      else operation = leaveRoom();
    } catch (error) {
      operation = Promise.reject(error);
    }
    operation.catch(function (error) {
      setStatus(error && error.message ? error.message : "Não foi possível concluir a operação.", "error");
    }).finally(function () {
      setBusy(false);
    });
  }, true);

  new MutationObserver(function () {
    customizeSettings();
    if (roomCode && !document.getElementById("lovable-team-panel")) renderPanel();
  }).observe(document.documentElement, { childList: true, subtree: true });

  scheduleTask("presença-e-sala", function () {
    sendGlobalPresence();
    listGlobalFriendPresence();
    if (roomCode) {
      sendHeartbeat();
      listPlayers();
      listRoomMessages();
    }
  }, 3000, 10000);

  scheduleTask("amigos-no-minimapa", renderTeammatesOnMinimap, 500, 60000);
  scheduleTask("seta-de-amigo", renderFriendArrow, 250, 60000);

  window.addEventListener("cobrinha-friends-changed", function () {
    knownFriendPresence = null;
    renderPanel();
    renderTeammatesOnMinimap();
    renderFriendArrow();
  });

  window.cobrinhaFriendPresence = {
    getPrivacy: friendPrivacy,
    setPrivacy: setFriendPrivacy,
    getPresence: function () { return globalFriendPresence.slice(); },
    getFollow: function () { return localStorage.getItem(FRIEND_FOLLOW_KEY) || ""; },
    setFollow: function (friendId) {
      if (friendId) localStorage.setItem(FRIEND_FOLLOW_KEY, String(friendId));
      else localStorage.removeItem(FRIEND_FOLLOW_KEY);
      renderFriendArrow();
      window.dispatchEvent(new CustomEvent("cobrinha-friend-presence-updated"));
    }
  };

  window.cobrinhaBackendHealth = {
    status: function () { return Object.assign({}, backendHealth); },
    retry: function () {
      sendGlobalPresence();
      if (roomCode) return Promise.all([sendHeartbeat(), listPlayers(), listRoomMessages()]);
      return Promise.resolve();
    }
  };

  if (roomCode && nickname) {
    join(roomCode, nickname).catch(function () {
      clearSession();
    });
  }
  customizeSettings();
  renderPanel();
  renderBackendHealth();
})();
