(function () {
  "use strict";
  if (window.CobrinhaScheduler) return;

  var tasks = new Map();
  var nextId = 1;

  function now() { return Date.now(); }

  function runTask(task, timestamp) {
    if (!task || task.running || (!task.runWhenHidden && document.hidden)) return;
    task.running = true;
    task.nextAt = timestamp + task.interval;
    try {
      var result = task.callback();
      if (result && typeof result.then === "function") {
        Promise.resolve(result).catch(function (error) {
          window.dispatchEvent(new CustomEvent("cobrinha-runtime-error", { detail: { module: task.name, message: error.message || String(error) } }));
        }).finally(function () { task.running = false; });
      }
      else task.running = false;
    } catch (error) {
      task.running = false;
      window.dispatchEvent(new CustomEvent("cobrinha-runtime-error", { detail: { module: task.name, message: error.message || String(error) } }));
    }
  }

  function tick() {
    var timestamp = now();
    tasks.forEach(function (task) {
      if (timestamp >= task.nextAt) runTask(task, timestamp);
    });
  }

  function every(name, callback, interval, options) {
    var id = nextId++;
    var settings = options || {};
    tasks.set(id, {
      id: id,
      name: String(name || "tarefa-" + id),
      callback: callback,
      interval: Math.max(100, Number(interval) || 1000),
      nextAt: now() + (settings.immediate ? 0 : Math.max(100, Number(interval) || 1000)),
      runWhenHidden: settings.runWhenHidden === true,
      running: false
    });
    return function cancel() { tasks.delete(id); };
  }

  function run(name) {
    var timestamp = now();
    tasks.forEach(function (task) {
      if (!name || task.name === name) runTask(task, timestamp);
    });
  }

  function status() {
    return Array.from(tasks.values()).map(function (task) {
      return { name: task.name, interval: task.interval, running: task.running, paused: document.hidden && !task.runWhenHidden };
    });
  }

  document.addEventListener("visibilitychange", function () {
    if (!document.hidden) {
      var timestamp = now();
      tasks.forEach(function (task) { task.nextAt = Math.min(task.nextAt, timestamp + 50); });
    }
  });

  setInterval(tick, 100);
  window.CobrinhaScheduler = { every: every, run: run, status: status };
})();
