(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.CobrinhaSettingsBackup = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";

  var APP = "Cobrinha Encasquetada";
  var SCHEMA = 2;
  var SENSITIVE_KEY = /(?:auth|token|password|passwd|secret|cobrinhaCliente|cobrinhaSala|cobrinhaApelido|runtimeId|nyscrID)/i;

  function plainObject(value) {
    return value && typeof value === "object" && !Array.isArray(value);
  }

  function sanitize(entries) {
    var result = {};
    if (!plainObject(entries)) return result;
    Object.keys(entries).forEach(function (key) {
      if (!key || SENSITIVE_KEY.test(key)) return;
      var value = entries[key];
      if (typeof value === "undefined") return;
      result[String(key).slice(0, 160)] = value;
    });
    return result;
  }

  function create(localEntries, extensionEntries, version) {
    return {
      app: APP,
      schema: SCHEMA,
      version: String(version || ""),
      exportedAt: new Date().toISOString(),
      localStorage: sanitize(localEntries),
      extensionStorage: sanitize(extensionEntries)
    };
  }

  function validate(payload) {
    if (!plainObject(payload) || payload.app !== APP) throw new Error("Este arquivo não pertence à Cobrinha Encasquetada.");
    if (payload.schema !== 1 && payload.schema !== SCHEMA) throw new Error("Versão de backup incompatível.");
    if (!plainObject(payload.localStorage)) throw new Error("O backup não contém configurações válidas.");
    return {
      localStorage: sanitize(payload.localStorage),
      extensionStorage: sanitize(payload.extensionStorage || {}),
      sourceVersion: String(payload.version || "anterior")
    };
  }

  return { app: APP, schema: SCHEMA, sensitiveKey: SENSITIVE_KEY, sanitize: sanitize, create: create, validate: validate };
});
