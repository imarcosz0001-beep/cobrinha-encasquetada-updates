(function () {
  "use strict";
  if (document.documentElement.dataset.cobrinhaSafeMode === "1") return;

  var CACHE_KEY = "cobrinhaTagCacheV2";

  // Ponte entre o código da página e a área privada de armazenamento da extensão.
  // Somente imagens, metadados e versões passam por aqui; senhas nunca são salvas.
  window.addEventListener("message", function (event) {
    if (event.source !== window) return;
    var request = event.data && event.data.cobrinhaTagCacheRequest;
    if (!request || !request.id) return;

    function reply(ok, data, error) {
      window.postMessage({ cobrinhaTagCacheResponse: {
        id: request.id,
        ok: ok,
        data: data,
        error: error || ""
      } }, "*");
    }

    if (request.action === "get") {
      chrome.storage.local.get([CACHE_KEY], function (stored) {
        if (chrome.runtime.lastError) return reply(false, null, chrome.runtime.lastError.message);
        reply(true, stored && stored[CACHE_KEY] || null);
      });
    } else if (request.action === "set") {
      var value = {};
      value[CACHE_KEY] = request.data || null;
      chrome.storage.local.set(value, function () {
        reply(!chrome.runtime.lastError, null, chrome.runtime.lastError && chrome.runtime.lastError.message);
      });
    } else if (request.action === "clear") {
      chrome.storage.local.remove([CACHE_KEY], function () {
        reply(!chrome.runtime.lastError, null, chrome.runtime.lastError && chrome.runtime.lastError.message);
      });
    }
  });

  function inject() {
    var script = document.createElement("script");
    script.src = chrome.runtime.getURL("tag-lovable.js");
    script.onload = function () {
      script.remove();
    };
    (document.head || document.documentElement).appendChild(script);
  }

  // O código legado só consulta o servidor antigo quando `lastupd` está vencido.
  // Renovamos esse marcador antes de o jogo iniciar; as atualizações passam a ser
  // feitas pelos comandos abaixo, diretamente na API própria do Lovable.
  try {
    chrome.storage.local.set({ lastupd: Math.floor(Date.now() / 1000) });
  } catch (ignore) {
  }
  // A injeção precisa acontecer antes do código principal para que também possa
  // neutralizar a autorização periódica do servidor antigo.
  inject();
})();
