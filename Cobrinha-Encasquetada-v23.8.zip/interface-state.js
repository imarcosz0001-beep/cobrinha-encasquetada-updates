(function (root, factory) {
  var api = factory(root);
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.CobrinhaInterfaceState = api;
})(typeof window !== "undefined" ? window : globalThis, function (root) {
  "use strict";

  var KEY = "cobrinhaInterfaceStateV2";
  var LEGACY_STUDIO_KEY = "cobrinhaInterfaceStudioV1";
  var LEGACY_PANELS_KEY = "cobrinhaPanelStateV1";
  var memory = {};

  function storage() {
    try { return root && root.localStorage ? root.localStorage : null; }
    catch (error) { return null; }
  }

  function parse(value, fallback) {
    try {
      var parsed = JSON.parse(value || "");
      return parsed && typeof parsed === "object" ? parsed : fallback;
    } catch (error) { return fallback; }
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value == null ? null : value));
  }

  function load() {
    var store = storage();
    var loaded = store ? parse(store.getItem(KEY), null) : memory;
    if (!loaded || loaded.schema !== 2) {
      loaded = {
        schema: 2,
        revision: 0,
        updatedAt: "",
        studio: store ? parse(store.getItem(LEGACY_STUDIO_KEY), {}) : {},
        panels: store ? parse(store.getItem(LEGACY_PANELS_KEY), {}) : {}
      };
    }
    if (!loaded.studio || typeof loaded.studio !== "object") loaded.studio = {};
    if (!loaded.panels || typeof loaded.panels !== "object") loaded.panels = {};
    memory = loaded;
    return loaded;
  }

  var state = load();

  function persist() {
    state.schema = 2;
    state.revision = Math.max(0, Number(state.revision) || 0) + 1;
    state.updatedAt = new Date().toISOString();
    memory = state;
    var store = storage();
    if (store) {
      store.setItem(KEY, JSON.stringify(state));
      store.setItem(LEGACY_STUDIO_KEY, JSON.stringify(state.studio || {}));
      store.setItem(LEGACY_PANELS_KEY, JSON.stringify(state.panels || {}));
    }
    if (root && typeof root.dispatchEvent === "function" && typeof root.CustomEvent === "function") {
      root.dispatchEvent(new root.CustomEvent("cobrinha-interface-state-changed", { detail: snapshot() }));
    }
    return snapshot();
  }

  function snapshot() { return clone(state); }
  function getStudio() { return clone(state.studio || {}); }
  function getPanels() { return clone(state.panels || {}); }

  function setStudio(next) {
    state.studio = clone(next && typeof next === "object" ? next : {});
    return persist();
  }

  function setPanels(next) {
    state.panels = clone(next && typeof next === "object" ? next : {});
    return persist();
  }

  function setPanel(name, patch) {
    if (!name) return snapshot();
    state.panels[name] = Object.assign({}, state.panels[name] || {}, clone(patch || {}));
    return persist();
  }

  function restore(next) {
    if (!next || next.schema !== 2) throw new Error("Estado de interface incompatível.");
    state = clone(next);
    return persist();
  }

  return {
    key: KEY,
    snapshot: snapshot,
    getStudio: getStudio,
    getPanels: getPanels,
    setStudio: setStudio,
    setPanels: setPanels,
    setPanel: setPanel,
    restore: restore
  };
});
