# Atualizações da Cobrinha Encasquetada

O Lovable não participa mais da distribuição de atualizações. A rota `team-api` rejeita tanto
`get_addon_update` quanto `publish_addon_update`, e a tabela histórica `addon_updates` não permite
acesso anônimo.

O addon possui dois canais versionados:

- Estável: `cobrinha-encasquetada-updates/addon-update.json`
- Beta: `cobrinha-encasquetada-updates/addon-update-beta.json`

O canal pode ser escolhido na engrenagem da interface. Se o manifesto Beta estiver indisponível, o
addon consulta o Estável sem impedir a abertura do jogo.

O `download_url` precisa apontar para um ZIP do mesmo repositório em uma URL imutável com o SHA do
commit. URLs de outros domínios, branches mutáveis e pacotes sem SHA-256 são bloqueados pelo service
worker.

## Segurança

Somente quem possui permissão de escrita no repositório oficial consegue alterar o manifesto e os
pacotes. Não existe formulário público de publicação.

Em Chrome/Brave no Windows, um addon instalado manualmente não pode substituir a si próprio silenciosamente. O botão baixa o ZIP automaticamente; o usuário ainda precisa substituir a pasta e recarregar a extensão. Atualização totalmente automática exige distribuição pela Chrome Web Store.

Antes de liberar o download, o service worker busca o pacote pela URL imutável e confere o SHA-256. O manifesto também pode informar a versão anterior para permitir retorno manual verificado.

## Fluxo protegido de publicação

1. Atualize a versão no `manifest.json`.
2. Gere o pacote com `powershell -File tools/build-release.ps1`.
3. Publique primeiro o ZIP imutável e o `addon-update-beta.json`.
4. Execute `node tools/promote-update.js --check` para validar arquivos, SHA-256 e testes locais.
5. Execute `node tools/promote-update.js` para rodar também o teste real no Slither e preparar a
   promoção para o canal Estável.

O script de promoção recusa uma versão que não seja superior à Estável, um ZIP cuja versão interna
seja diferente, uma URL mutável ou um pacote com SHA-256 divergente.

## Promoção privada no GitHub

Na aba **Actions** do repositório oficial, o fluxo **Promover Beta para Estável** só pode ser executado
por quem possui permissão de escrita.

Informe a versão Beta aprovada e digite `PROMOVER`. O GitHub baixa o ZIP imutável, confere o SHA-256,
repete a validação e o teste no navegador e promove exatamente o mesmo pacote. Nenhum ZIP diferente
é criado nesta etapa.

Se qualquer validação falhar, o canal de destino permanece inalterado.
