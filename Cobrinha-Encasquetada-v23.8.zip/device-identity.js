(function () {
  "use strict";
  if (window.CobrinhaDeviceIdentity) return;

  var STORAGE_KEY = "cobrinhaIdentitySecretJwkV1";
  var PUBLIC_KEY = "cobrinhaIdentityPublicJwkV1";
  var encoder = new TextEncoder();
  var current = null;

  function base64Url(bytes) {
    var binary = "";
    Array.prototype.forEach.call(new Uint8Array(bytes), function (value) { binary += String.fromCharCode(value); });
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }

  function fromBase64Url(value) {
    var normalized = String(value || "").replace(/-/g, "+").replace(/_/g, "/");
    while (normalized.length % 4) normalized += "=";
    var binary = atob(normalized);
    return Uint8Array.from(binary, function (character) { return character.charCodeAt(0); });
  }

  function stable(value) {
    if (Array.isArray(value)) return "[" + value.map(stable).join(",") + "]";
    if (value && typeof value === "object") {
      return "{" + Object.keys(value).filter(function (key) { return typeof value[key] !== "undefined"; }).sort().map(function (key) {
        return JSON.stringify(key) + ":" + stable(value[key]);
      }).join(",") + "}";
    }
    return JSON.stringify(value);
  }

  function publicShape(jwk) {
    return { kty: "EC", crv: "P-256", x: String(jwk.x || ""), y: String(jwk.y || "") };
  }

  function deriveClientId(publicJwk) {
    return crypto.subtle.digest("SHA-256", encoder.encode(stable(publicShape(publicJwk)))).then(function (digest) {
      return "ce1-" + base64Url(digest);
    });
  }

  function importIdentity(privateJwk, publicJwk) {
    return Promise.all([
      crypto.subtle.importKey("jwk", privateJwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]),
      crypto.subtle.importKey("jwk", publicJwk, { name: "ECDSA", namedCurve: "P-256" }, true, ["verify"]),
      deriveClientId(publicJwk)
    ]).then(function (values) {
      return { privateKey: values[0], publicKey: values[1], publicJwk: publicShape(publicJwk), clientId: values[2] };
    });
  }

  function generateIdentity() {
    return crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]).then(function (pair) {
      return Promise.all([crypto.subtle.exportKey("jwk", pair.privateKey), crypto.subtle.exportKey("jwk", pair.publicKey)]);
    }).then(function (keys) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(keys[0]));
      localStorage.setItem(PUBLIC_KEY, JSON.stringify(publicShape(keys[1])));
      return importIdentity(keys[0], keys[1]);
    });
  }

  function loadIdentity() {
    try {
      var privateJwk = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      var publicJwk = JSON.parse(localStorage.getItem(PUBLIC_KEY) || "null");
      if (privateJwk && publicJwk) return importIdentity(privateJwk, publicJwk).catch(generateIdentity);
    } catch (ignore) {}
    return generateIdentity();
  }

  function nonce() {
    if (crypto.randomUUID) return crypto.randomUUID();
    var bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return base64Url(bytes);
  }

  var ready = loadIdentity().then(function (identity) {
    current = identity;
    localStorage.setItem("cobrinhaCliente", identity.clientId);
    return { clientId: identity.clientId, publicJwk: identity.publicJwk };
  });

  function sign(payload) {
    return ready.then(function () {
      var secured = Object.assign({}, payload, {
        client_id: current.clientId,
        identity_timestamp: Date.now(),
        identity_nonce: nonce(),
        identity_public_key: current.publicJwk
      });
      var serialized = stable(secured);
      return crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, current.privateKey, encoder.encode(serialized)).then(function (signature) {
        secured.identity_signature = base64Url(signature);
        return secured;
      });
    });
  }

  function friendCode() {
    return ready.then(function (identity) { return "CE1:" + identity.clientId; });
  }

  function deriveBackupKey(password, salt, usages) {
    return crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveKey"]).then(function (material) {
      return crypto.subtle.deriveKey(
        { name: "PBKDF2", salt: salt, iterations: 310000, hash: "SHA-256" },
        material,
        { name: "AES-GCM", length: 256 },
        false,
        usages
      );
    });
  }

  function exportIdentity(password) {
    password = String(password || "");
    if (password.length < 10) return Promise.reject(new Error("Use uma senha com pelo menos 10 caracteres."));
    return ready.then(function (identity) {
      var privateJwk = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (!privateJwk) throw new Error("A identidade deste dispositivo não está disponível.");
      var secret = encoder.encode(JSON.stringify({
        clientId: identity.clientId,
        privateJwk: privateJwk,
        publicJwk: identity.publicJwk
      }));
      var salt = crypto.getRandomValues(new Uint8Array(16));
      var iv = crypto.getRandomValues(new Uint8Array(12));
      return deriveBackupKey(password, salt, ["encrypt"]).then(function (key) {
        return crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, key, secret);
      }).then(function (ciphertext) { return {
        app: "Cobrinha Encasquetada",
        kind: "device-identity",
        schema: 2,
        exportedAt: new Date().toISOString(),
        identityHint: identity.clientId.slice(-8),
        kdf: { name: "PBKDF2", hash: "SHA-256", iterations: 310000, salt: base64Url(salt) },
        cipher: { name: "AES-GCM", iv: base64Url(iv), ciphertext: base64Url(ciphertext) }
      }; });
    });
  }

  function restoreIdentity(payload, password) {
    if (!payload || payload.app !== "Cobrinha Encasquetada" || payload.kind !== "device-identity" || payload.schema !== 2) {
      return Promise.reject(new Error("Arquivo de identidade inválido."));
    }
    password = String(password || "");
    if (password.length < 10) return Promise.reject(new Error("Informe a senha usada na exportação."));
    var salt;
    var iv;
    var encrypted;
    try {
      salt = fromBase64Url(payload.kdf && payload.kdf.salt);
      iv = fromBase64Url(payload.cipher && payload.cipher.iv);
      encrypted = fromBase64Url(payload.cipher && payload.cipher.ciphertext);
    } catch (error) { return Promise.reject(new Error("O arquivo criptografado está corrompido.")); }
    return deriveBackupKey(password, salt, ["decrypt"]).then(function (key) {
      return crypto.subtle.decrypt({ name: "AES-GCM", iv: iv }, key, encrypted);
    }).then(function (plain) {
      try { return JSON.parse(new TextDecoder().decode(plain)); }
      catch (error) { throw new Error("A senha está incorreta ou o arquivo foi alterado."); }
    }).catch(function () {
      throw new Error("A senha está incorreta ou o arquivo foi alterado.");
    }).then(function (secret) {
      var privateJwk = secret.privateJwk;
      var publicJwk = publicShape(secret.publicJwk || {});
      if (!privateJwk || privateJwk.kty !== "EC" || privateJwk.crv !== "P-256" || !privateJwk.d || !publicJwk.x || !publicJwk.y) {
        throw new Error("A chave de identidade está incompleta.");
      }
      return importIdentity(privateJwk, publicJwk).then(function (candidate) {
      if (secret.clientId && candidate.clientId !== secret.clientId) throw new Error("A verificação da identidade falhou.");
      var challenge = encoder.encode("cobrinha-identity-restore:" + candidate.clientId);
      return crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, candidate.privateKey, challenge).then(function (signature) {
        return crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, candidate.publicKey, signature, challenge);
      }).then(function (valid) {
        if (!valid) throw new Error("As chaves pública e privada não correspondem.");
        localStorage.setItem(STORAGE_KEY, JSON.stringify(privateJwk));
        localStorage.setItem(PUBLIC_KEY, JSON.stringify(publicJwk));
        localStorage.setItem("cobrinhaCliente", candidate.clientId);
        return { clientId: candidate.clientId, reloadRequired: true };
      });
      });
    });
  }

  window.CobrinhaDeviceIdentity = {
    ready: ready,
    sign: sign,
    stable: stable,
    friendCode: friendCode,
    exportIdentity: exportIdentity,
    restoreIdentity: restoreIdentity
  };
})();
