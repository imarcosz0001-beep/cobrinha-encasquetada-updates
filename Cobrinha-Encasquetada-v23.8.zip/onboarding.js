(function () {
  "use strict";
  if (document.documentElement.dataset.cobrinhaSafeMode === "1") return;
  var KEY = "cobrinhaOnboardingV1";
  var step = 0;
  var selectedProfile = "clean";

  function menuVisible() {
    var login = document.getElementById("login");
    if (!login) return false;
    var style = getComputedStyle(login);
    var rect = login.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
  }

  function pages(modal) { return Array.prototype.slice.call(modal.querySelectorAll(".cobrinha-onboarding-page")); }

  function renderStep() {
    var modal = document.getElementById("cobrinha-onboarding");
    if (!modal) return;
    var all = pages(modal);
    step = Math.max(0, Math.min(all.length - 1, step));
    all.forEach(function (page, index) { page.hidden = index !== step; });
    modal.querySelector(".cobrinha-onboarding-progress").textContent = (step + 1) + " / " + all.length;
    modal.querySelector('[data-action="back"]').disabled = step === 0;
    modal.querySelector('[data-action="next"]').hidden = step === all.length - 1;
    modal.querySelector('[data-action="finish"]').hidden = step !== all.length - 1;
    var heading = all[step] && all[step].querySelector("h2");
    if (heading) {
      heading.tabIndex = -1;
      heading.focus({ preventScroll: true });
    }
  }

  function chooseProfile(button) {
    selectedProfile = button.getAttribute("data-profile");
    button.parentNode.querySelectorAll("button").forEach(function (item) {
      var selected = item === button;
      item.classList.toggle("is-selected", selected);
      item.setAttribute("aria-checked", selected ? "true" : "false");
    });
    var next = document.querySelector('#cobrinha-onboarding [data-action="next"]');
    if (next) next.focus({ preventScroll: true });
  }

  function finish(skip) {
    var modal = document.getElementById("cobrinha-onboarding");
    if (!skip && window.cobrinhaApplyInterfaceProfile) window.cobrinhaApplyInterfaceProfile(selectedProfile);
    if (!skip && window.cobrinhaFriendPresence) {
      window.cobrinhaFriendPresence.setPrivacy({
        sharePresence: modal.querySelector('[name="presence"]').checked,
        shareServer: modal.querySelector('[name="server"]').checked,
        sharePosition: modal.querySelector('[name="position"]').checked,
        notifications: modal.querySelector('[name="notifications"]').checked
      });
    }
    localStorage.setItem(KEY, "1");
    modal.hidden = true;
  }

  function create() {
    if (!document.body || document.getElementById("cobrinha-onboarding")) return;
    var modal = document.createElement("section");
    modal.id = "cobrinha-onboarding";
    modal.hidden = true;
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "cobrinha-onboarding-title");
    modal.innerHTML = '<header><div><strong id="cobrinha-onboarding-title">Configuração inicial</strong><span class="cobrinha-onboarding-progress"></span></div><button type="button" data-action="skip" title="Fechar" aria-label="Fechar configuração inicial">×</button></header>' +
      '<div class="cobrinha-onboarding-page"><h2>Como você prefere jogar?</h2><p>Você poderá mudar tudo depois na engrenagem.</p><div class="cobrinha-onboarding-profiles" role="radiogroup" aria-label="Modo de jogo"><button type="button" role="radio" aria-checked="false" data-profile="complete">Completo<small>Todas as informações</small></button><button type="button" role="radio" aria-checked="true" data-profile="clean" class="is-selected">Leve<small>Limpo e organizado</small></button><button type="button" role="radio" aria-checked="false" data-profile="competitive">Competitivo<small>Só o essencial</small></button></div></div>' +
      '<div class="cobrinha-onboarding-page" hidden><h2>Amigos e privacidade</h2><p>As opções recomendadas já estão ativadas e podem ser alteradas quando quiser.</p><label><input type="checkbox" name="presence" checked> Aparecer online para amigos</label><label><input type="checkbox" name="server" checked> Compartilhar servidor</label><label><input type="checkbox" name="position" checked> Compartilhar posição para a seta</label><label><input type="checkbox" name="notifications" checked> Avisar quando um amigo entrar</label></div>' +
      '<footer><button type="button" data-action="back">Voltar</button><button type="button" data-action="next">Avançar</button><button type="button" data-action="finish">Concluir</button></footer>';
    modal.querySelectorAll("[data-profile]").forEach(function (button) { button.addEventListener("click", function () { chooseProfile(button); }); });
    modal.querySelector(".cobrinha-onboarding-profiles").addEventListener("keydown", function (event) {
      if (!["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) return;
      var options = Array.prototype.slice.call(modal.querySelectorAll("[data-profile]"));
      var current = Math.max(0, options.indexOf(document.activeElement));
      var direction = event.key === "ArrowLeft" || event.key === "ArrowUp" ? -1 : 1;
      var next = options[(current + direction + options.length) % options.length];
      event.preventDefault();
      chooseProfile(next);
      next.focus({ preventScroll: true });
    });
    modal.querySelector('[data-action="skip"]').addEventListener("click", function () { finish(true); });
    modal.querySelector('[data-action="back"]').addEventListener("click", function () { step--; renderStep(); });
    modal.querySelector('[data-action="next"]').addEventListener("click", function () { step++; renderStep(); });
    modal.querySelector('[data-action="finish"]').addEventListener("click", function () { finish(false); });
    ["pointerdown", "mousedown", "mouseup", "click", "wheel"].forEach(function (type) { modal.addEventListener(type, function (event) { event.stopPropagation(); }); });
    document.body.appendChild(modal);
    renderStep();
  }

  function open() {
    create();
    step = 0;
    var modal = document.getElementById("cobrinha-onboarding");
    modal.hidden = false;
    renderStep();
    var popup = document.getElementById("cobrinha-layout-popup");
    if (popup) popup.hidden = true;
    var selected = modal.querySelector('[data-profile].is-selected');
    if (selected) selected.focus({ preventScroll: true });
  }

  function attachLauncher() {
    var popup = document.getElementById("cobrinha-layout-popup");
    if (!popup || popup.querySelector(".cobrinha-open-onboarding")) return;
    var button = document.createElement("button");
    button.type = "button";
    button.className = "cobrinha-open-onboarding";
    button.textContent = "Refazer configuração inicial";
    button.addEventListener("click", open);
    var maintenanceActions = popup.querySelector("#cobrinha-layout-maintenance-actions");
    var reliabilityActions = maintenanceActions && maintenanceActions.querySelector(".cobrinha-runtime-actions");
    if (maintenanceActions) maintenanceActions.insertBefore(button, reliabilityActions || null);
    else popup.appendChild(button);
  }

  create();
  attachLauncher();
  var attempts = 0;
  var timer = setInterval(function () {
    attachLauncher();
    if (localStorage.getItem(KEY) !== "1" && menuVisible()) {
      clearInterval(timer);
      setTimeout(open, 450);
    } else if (++attempts > 240) clearInterval(timer);
  }, 250);
})();
