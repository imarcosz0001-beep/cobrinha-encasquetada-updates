(function () {
  "use strict";
  if (document.documentElement.dataset.cobrinhaSafeMode === "1") return;
  var script = document.createElement("script");
  script.src = chrome.runtime.getURL("command-center.js");
  script.onload = function () { script.remove(); };
  (document.head || document.documentElement).appendChild(script);
})();
