(function () {
  "use strict";
  if (document.documentElement.dataset.cobrinhaSafeMode === "1") return;

  var STATE_KEY = "cobrinhaInterfaceStudioV1";
  var PROFILE_KEY = "cobrinhaInterfaceProfile";
  var CUSTOM_PROFILE_KEY = "cobrinhaInterfaceCustomProfileV1";
  var FRIENDS_KEY = "cobrinhaFriendsV1";
  var SENSITIVE_KEY = /(?:auth|token|password|passwd|secret|cobrinhaCliente|cobrinhaSala|cobrinhaApelido|runtimeId|nyscrID)/i;
  var originalPosition = new WeakMap();
  var editorActive = false;
  var selectedId = "";
  var overlays = [];
  var applyTimer = 0;
  var dragActive = false;
  var undoStack = [];
  var redoStack = [];
  var historyLimit = 40;

  var elements = [
    { id: "technical", label: "Informações técnicas", selector: "#score-hud, #fps-hud, #ip-hud, #position-hud, #kills-hud, #timebot-hud" },
    { id: "rank", label: "Rank e tamanho", selector: "#player-stats-hud" },
    { id: "top10", label: "Top 10", selector: "#ttbox" },
    { id: "chat", label: "Mensagens e chat", selector: "#bchat" },
    { id: "shortcuts", label: "Atalhos", selector: "#eemenu" },
    { id: "room", label: "Equipe e sala", selector: "#lovable-team-panel" },
    { id: "minimap", label: "Minimapa", selector: "#mmap" },
    { id: "graph", label: "Ping/FPS e gráfico", selector: "#mgraph-box" }
  ];

  var profiles = {
    complete: {
      label: "Completo",
      boxMode: "standard",
      teamMode: "full",
      elements: {
        technical: [true, 100, 100], rank: [true, 100, 100], top10: [true, 100, 100],
        chat: [true, 100, 100], shortcuts: [true, 100, 100], room: [true, 100, 100],
        minimap: [true, 100, 100], graph: [true, 100, 100]
      }
    },
    clean: {
      label: "Leve",
      boxMode: "minimal",
      teamMode: "minimal",
      elements: {
        technical: [true, 72, 92], rank: [true, 100, 95], top10: [true, 92, 95],
        chat: [true, 82, 92], shortcuts: [true, 72, 88], room: [true, 82, 90],
        minimap: [true, 88, 92], graph: [true, 85, 90]
      }
    },
    competitive: {
      label: "Competitivo",
      boxMode: "minimal",
      teamMode: "minimal",
      elements: {
        technical: [true, 70, 88], rank: [true, 100, 100], top10: [true, 100, 100],
        chat: [true, 55, 85], shortcuts: [false, 65, 82], room: [true, 70, 82],
        minimap: [true, 100, 100], graph: [true, 85, 85]
      }
    }
  };

  function defaultElementState() {
    return { visible: true, opacity: 100, size: 100, positions: null, viewMode: "auto" };
  }

  function loadState() {
    var loaded = {};
    var hadSavedState = false;
    try {
      if (window.CobrinhaInterfaceState) {
        loaded = window.CobrinhaInterfaceState.getStudio();
        hadSavedState = Boolean(loaded && loaded.elements);
      } else {
        hadSavedState = localStorage.getItem(STATE_KEY) != null;
        loaded = JSON.parse(localStorage.getItem(STATE_KEY) || "{}");
      }
    } catch (error) {}
    if (!loaded || typeof loaded !== "object") loaded = {};
    if (!loaded.elements || typeof loaded.elements !== "object") loaded.elements = {};
    elements.forEach(function (item) {
      loaded.elements[item.id] = Object.assign(defaultElementState(), loaded.elements[item.id] || {});
    });
    if (!hadSavedState) {
      try {
        var technicalOpacity = localStorage.getItem("cobrinhaTechHudOpacity");
        var technicalSize = localStorage.getItem("cobrinhaTechHudSize");
        if (technicalOpacity != null) loaded.elements.technical.opacity = Math.round(Math.max(0, Math.min(1, Number(technicalOpacity))) * 100);
        if (technicalSize != null) loaded.elements.technical.size = Math.round(Math.max(8, Math.min(24, Number(technicalSize))) / 13 * 100);
        var oldPanelState = JSON.parse(localStorage.getItem("cobrinhaPanelStateV1") || "{}");
        [["shortcuts", "shortcuts"], ["chat", "chat"], ["room", "team"]].forEach(function (entry) {
          var oldValue = oldPanelState && oldPanelState[entry[1]] && oldPanelState[entry[1]].opacity;
          if (oldValue != null) loaded.elements[entry[0]].opacity = Math.round(Math.max(0, Math.min(1, Number(oldValue))) * 100);
        });
      } catch (error) {}
    }
    return loaded;
  }

  var state = loadState();

  function cloneState(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function recordHistory(label) {
    var snapshot = JSON.stringify(state);
    var last = undoStack.length && undoStack[undoStack.length - 1];
    if (last && last.snapshot === snapshot) return;
    undoStack.push({ label: label || "Alteração", snapshot: snapshot });
    if (undoStack.length > historyLimit) undoStack.shift();
    redoStack = [];
    updateHistoryButtons();
  }

  function restoreHistoryEntry(entry, destination) {
    if (!entry) return;
    destination.push({ label: entry.label, snapshot: JSON.stringify(state) });
    state = JSON.parse(entry.snapshot);
    elements.forEach(function (item) {
      state.elements[item.id] = Object.assign(defaultElementState(), state.elements[item.id] || {});
    });
    markCustom();
    saveState();
    applyAll();
    renderElementRows();
    renderViewRows();
    refreshEditorOverlays();
    updateHistoryButtons();
    setStudioStatus(entry.label + " restaurada.", "ok");
  }

  function undoInterfaceChange() {
    restoreHistoryEntry(undoStack.pop(), redoStack);
  }

  function redoInterfaceChange() {
    restoreHistoryEntry(redoStack.pop(), undoStack);
  }

  function updateHistoryButtons() {
    var undo = document.getElementById("cobrinha-editor-undo");
    var redo = document.getElementById("cobrinha-editor-redo");
    if (undo) {
      undo.disabled = !undoStack.length;
      undo.title = undoStack.length ? "Desfazer: " + undoStack[undoStack.length - 1].label : "Nada para desfazer";
    }
    if (redo) {
      redo.disabled = !redoStack.length;
      redo.title = redoStack.length ? "Refazer: " + redoStack[redoStack.length - 1].label : "Nada para refazer";
    }
  }

  function saveState() {
    try {
      if (window.CobrinhaInterfaceState) window.CobrinhaInterfaceState.setStudio(state);
      else localStorage.setItem(STATE_KEY, JSON.stringify(state));
    } catch (error) {}
  }

  function itemById(id) {
    return elements.find(function (item) { return item.id === id; });
  }

  function minimalBackgroundRgba() {
    var color = "#000000";
    var opacity = 0.15;
    try {
      var savedColor = localStorage.getItem("cobrinhaMinimalBackgroundColor");
      var savedOpacity = localStorage.getItem("cobrinhaMinimalBackgroundOpacity");
      if (/^#[0-9a-f]{6}$/i.test(savedColor || "")) color = savedColor;
      if (savedOpacity != null && Number.isFinite(Number(savedOpacity))) opacity = Math.max(0, Math.min(1, Number(savedOpacity)));
    } catch (error) {}
    var value = color.slice(1);
    return "rgba(" + parseInt(value.slice(0, 2), 16) + ", " + parseInt(value.slice(2, 4), 16) + ", " + parseInt(value.slice(4, 6), 16) + ", " + opacity + ")";
  }

  function nodesFor(item) {
    return item ? Array.prototype.slice.call(document.querySelectorAll(item.selector)) : [];
  }

  function capturePosition(node) {
    if (originalPosition.has(node)) return;
    var saved = {};
    ["position", "left", "top", "right", "bottom"].forEach(function (property) {
      saved[property] = { value: node.style.getPropertyValue(property), priority: node.style.getPropertyPriority(property) };
    });
    originalPosition.set(node, saved);
  }

  function restorePosition(node) {
    if (!originalPosition.has(node)) return;
    var saved = originalPosition.get(node);
    Object.keys(saved).forEach(function (property) {
      if (saved[property].value) node.style.setProperty(property, saved[property].value, saved[property].priority || "");
      else node.style.removeProperty(property);
    });
    originalPosition.delete(node);
  }

  function applyElement(item) {
    var config = state.elements[item.id] || defaultElementState();
    var minimumSize = item.id === "room" ? 100 : 50;
    var visualSize = Math.max(minimumSize, Math.min(200, Number(config.size) || 100));
    if (item.id === "room" && Number(config.size) < minimumSize) {
      config.size = minimumSize;
      saveState();
    }
    var viewMode = /^(show|hide)$/.test(config.viewMode || "") ? config.viewMode : "auto";
    nodesFor(item).forEach(function (node, index) {
      if (!config.visible || viewMode === "hide") {
        node.setAttribute("data-cobrinha-studio-hidden", "1");
      } else {
        node.removeAttribute("data-cobrinha-studio-hidden");
      }
      if (config.visible && viewMode === "show") node.setAttribute("data-cobrinha-studio-force-visible", "1");
      else node.removeAttribute("data-cobrinha-studio-force-visible");
      node.setAttribute("data-cobrinha-studio-managed", "1");
      node.style.setProperty("--cobrinha-studio-opacity", String(Math.max(0, Math.min(100, Number(config.opacity) || 0)) / 100));
      node.style.setProperty("--cobrinha-studio-zoom", String(visualSize / 100));
      node.style.setProperty("opacity", String(Math.max(0, Math.min(100, Number(config.opacity) || 0)) / 100), "important");
      node.style.setProperty("zoom", String(visualSize / 100));
      if (Array.isArray(config.positions) && config.positions[index]) {
        capturePosition(node);
        var position = config.positions[index];
        node.setAttribute("data-cobrinha-studio-positioned", "1");
        node.style.setProperty("--cobrinha-studio-left", Math.round(position.left) + "px");
        node.style.setProperty("--cobrinha-studio-top", Math.round(position.top) + "px");
        node.style.setProperty("position", "fixed", "important");
        node.style.setProperty("left", Math.round(position.left) + "px", "important");
        node.style.setProperty("top", Math.round(position.top) + "px", "important");
        node.style.setProperty("right", "auto", "important");
        node.style.setProperty("bottom", "auto", "important");
      } else {
        node.removeAttribute("data-cobrinha-studio-positioned");
        node.style.removeProperty("--cobrinha-studio-left");
        node.style.removeProperty("--cobrinha-studio-top");
        restorePosition(node);
      }
    });
    if (item.id === "technical") {
      var technicalSize = Math.max(8, Math.min(24, 13 * Number(config.size || 100) / 100));
      document.documentElement.style.setProperty("--cobrinha-tech-hud-opacity", String(Number(config.opacity || 0) / 100));
      document.documentElement.style.setProperty("--cobrinha-tech-hud-size", technicalSize + "px");
      try {
        localStorage.setItem("cobrinhaTechHudOpacity", String(Number(config.opacity || 0) / 100));
        localStorage.setItem("cobrinhaTechHudSize", String(technicalSize));
      } catch (error) {}
      var technicalOpacityNumber = document.getElementById("cobrinha-tech-opacity-number");
      var technicalOpacityRange = document.getElementById("cobrinha-tech-opacity-range");
      var technicalSizeNumber = document.getElementById("cobrinha-tech-size-number");
      var technicalSizeRange = document.getElementById("cobrinha-tech-size-range");
      if (technicalOpacityNumber) technicalOpacityNumber.value = String(config.opacity);
      if (technicalOpacityRange) technicalOpacityRange.value = String(config.opacity);
      if (technicalSizeNumber) technicalSizeNumber.value = String(Math.round(technicalSize));
      if (technicalSizeRange) technicalSizeRange.value = String(Math.round(technicalSize));
    }
    if (["shortcuts", "chat", "room"].indexOf(item.id) >= 0) {
      nodesFor(item).forEach(function (node) {
        node.style.setProperty("--cobrinha-panel-opacity", String(Number(config.opacity || 0) / 100));
        var slider = node.querySelector(":scope > .cobrinha-panel-opacity");
        if (slider) slider.value = String(Number(config.opacity || 0) / 100);
      });
    }
  }

  function applyAll() {
    var externalDragIds = { shortcuts: "shortcuts", chat: "chat", team: "room" };
    var externalDragId = externalDragIds[window.cobrinhaActivePanelDrag] || "";
    elements.forEach(function (item) {
      if ((!dragActive || item.id !== selectedId) && item.id !== externalDragId) applyElement(item);
    });
    syncCompactPerformance();
    syncContextualUi();
    var externalView = document.getElementById("cobrinha-layout-view");
    var layoutGear = document.getElementById("cobrinha-layout-gear");
    if (externalView && layoutGear && layoutGear.hidden) externalView.hidden = true;
    if (editorActive && !dragActive) refreshEditorOverlays();
  }

  function setProfile(name) {
    var profile = profiles[name];
    if (!profile) return;
    recordHistory("Perfil " + profile.label);
    Object.keys(profile.elements).forEach(function (id) {
      var values = profile.elements[id];
      var previousPositions = state.elements[id] && state.elements[id].positions;
      state.elements[id] = { visible: values[0], opacity: values[1], size: values[2], positions: previousPositions || null };
    });
    try {
      localStorage.setItem(PROFILE_KEY, name);
      localStorage.setItem("cobrinhaBoxVisualMode", profile.boxMode);
      localStorage.setItem("cobrinhaTeamPanelMode", profile.teamMode);
      if (name !== "complete") {
        localStorage.setItem("cobrinhaMinimalBackgroundEnabled", "1");
        if (localStorage.getItem("cobrinhaMinimalBackgroundOpacity") == null) localStorage.setItem("cobrinhaMinimalBackgroundOpacity", "0.15");
      }
    } catch (error) {}
    document.documentElement.classList.toggle("cobrinha-boxes-minimal", profile.boxMode === "minimal");
    if (name !== "complete") {
      document.documentElement.classList.add("cobrinha-minimal-background");
      document.documentElement.style.setProperty("--cobrinha-minimal-panel-bg", minimalBackgroundRgba());
    }
    var room = document.getElementById("lovable-team-panel");
    if (room) room.classList.toggle("cobrinha-team-minimal", profile.teamMode === "minimal");
    saveState();
    applyAll();
    renderElementRows();
    renderViewRows();
    setStudioStatus("Perfil " + profile.label + " aplicado.", "ok");
  }

  function markCustom() {
    try {
      localStorage.setItem(PROFILE_KEY, "custom");
      localStorage.setItem(CUSTOM_PROFILE_KEY, JSON.stringify({
        state: state,
        boxMode: localStorage.getItem("cobrinhaBoxVisualMode") || "standard",
        teamMode: localStorage.getItem("cobrinhaTeamPanelMode") || "full",
        minimalBackground: {
          enabled: localStorage.getItem("cobrinhaMinimalBackgroundEnabled") === "1",
          color: localStorage.getItem("cobrinhaMinimalBackgroundColor") || "#000000",
          opacity: localStorage.getItem("cobrinhaMinimalBackgroundOpacity") || "0.15"
        }
      }));
    } catch (error) {}
    var select = document.getElementById("cobrinha-studio-profile");
    if (select) select.value = "custom";
  }

  function restoreCustomProfile() {
    try {
      var custom = JSON.parse(localStorage.getItem(CUSTOM_PROFILE_KEY) || "null");
      if (!custom || !custom.state || !custom.state.elements) {
        setStudioStatus("Personalize algum elemento para criar este perfil.", "error");
        return;
      }
      recordHistory("Restauração do perfil Personalizado");
      state = custom.state;
      elements.forEach(function (item) {
        state.elements[item.id] = Object.assign(defaultElementState(), state.elements[item.id] || {});
      });
      saveState();
      localStorage.setItem(PROFILE_KEY, "custom");
      localStorage.setItem("cobrinhaBoxVisualMode", custom.boxMode || "standard");
      localStorage.setItem("cobrinhaTeamPanelMode", custom.teamMode || "full");
      if (custom.minimalBackground) {
        localStorage.setItem("cobrinhaMinimalBackgroundEnabled", custom.minimalBackground.enabled ? "1" : "0");
        localStorage.setItem("cobrinhaMinimalBackgroundColor", custom.minimalBackground.color || "#000000");
        localStorage.setItem("cobrinhaMinimalBackgroundOpacity", String(custom.minimalBackground.opacity == null ? "0.15" : custom.minimalBackground.opacity));
      }
      document.documentElement.classList.toggle("cobrinha-boxes-minimal", custom.boxMode === "minimal");
      document.documentElement.classList.toggle("cobrinha-minimal-background", Boolean(custom.minimalBackground && custom.minimalBackground.enabled));
      document.documentElement.style.setProperty("--cobrinha-minimal-panel-bg", minimalBackgroundRgba());
      var room = document.getElementById("lovable-team-panel");
      if (room) room.classList.toggle("cobrinha-team-minimal", custom.teamMode === "minimal");
      applyAll();
      renderElementRows();
      renderViewRows();
      setStudioStatus("Perfil Personalizado restaurado.", "ok");
    } catch (error) {
      setStudioStatus("Não foi possível restaurar o perfil Personalizado.", "error");
    }
  }

  function createNumberRange(min, max, value, onUpdate, onStart) {
    var wrap = document.createElement("div");
    wrap.className = "cobrinha-studio-number-range";
    var range = document.createElement("input");
    range.type = "range";
    range.min = String(min);
    range.max = String(max);
    range.step = "1";
    range.value = String(value);
    var number = document.createElement("input");
    number.type = "number";
    number.min = String(min);
    number.max = String(max);
    number.step = "1";
    number.value = String(value);
    function update(raw) {
      var next = Number(raw);
      if (!Number.isFinite(next)) return;
      next = Math.max(min, Math.min(max, next));
      range.value = String(next);
      number.value = String(next);
      onUpdate(next);
    }
    range.addEventListener("input", function () { update(range.value); });
    number.addEventListener("input", function () { if (number.value !== "") update(number.value); });
    number.addEventListener("change", function () { update(number.value === "" ? range.value : number.value); });
    if (onStart) {
      range.addEventListener("pointerdown", onStart);
      range.addEventListener("focus", onStart);
      number.addEventListener("focus", onStart);
    }
    wrap.appendChild(range);
    wrap.appendChild(number);
    return wrap;
  }

  function renderElementRows() {
    var body = document.getElementById("cobrinha-studio-elements");
    if (!body) return;
    body.textContent = "";
    elements.forEach(function (item) {
      var config = state.elements[item.id];
      var row = document.createElement("div");
      row.className = "cobrinha-studio-element-row";
      row.setAttribute("data-element", item.id);
      var heading = document.createElement("div");
      heading.className = "cobrinha-studio-element-heading";
      var visibleLabel = document.createElement("label");
      var visible = document.createElement("input");
      visible.type = "checkbox";
      visible.checked = config.visible !== false;
      var name = document.createElement("strong");
      name.textContent = item.label;
      visibleLabel.appendChild(visible);
      visibleLabel.appendChild(name);
      var availability = document.createElement("span");
      availability.textContent = nodesFor(item).length ? "disponível" : "fora desta tela";
      availability.className = nodesFor(item).length ? "is-ready" : "";
      heading.appendChild(visibleLabel);
      heading.appendChild(availability);
      var controls = document.createElement("div");
      controls.className = "cobrinha-studio-element-controls";
      var opacityLabel = document.createElement("label");
      opacityLabel.appendChild(document.createTextNode("Opacidade"));
      opacityLabel.appendChild(createNumberRange(0, 100, config.opacity, function (value) {
        config.opacity = value; markCustom(); saveState(); applyElement(item);
      }, function () { recordHistory("Opacidade de " + item.label); }));
      var sizeLabel = document.createElement("label");
      sizeLabel.appendChild(document.createTextNode("Tamanho"));
      sizeLabel.appendChild(createNumberRange(item.id === "room" ? 100 : 50, 200, Math.max(item.id === "room" ? 100 : 50, Number(config.size) || 100), function (value) {
        config.size = value; markCustom(); saveState(); applyElement(item); refreshEditorOverlays();
      }, function () { recordHistory("Tamanho de " + item.label); }));
      visible.addEventListener("change", function () {
        recordHistory("Visibilidade de " + item.label);
        config.visible = visible.checked;
        config.viewMode = visible.checked ? "auto" : "hide";
        markCustom(); saveState(); applyElement(item); renderElementRows(); renderViewRows();
      });
      controls.appendChild(opacityLabel);
      controls.appendChild(sizeLabel);
      row.appendChild(heading);
      row.appendChild(controls);
      body.appendChild(row);
    });
  }

  function nodeIsVisible(node) {
    if (!node) return false;
    var style = getComputedStyle(node);
    var rect = node.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0.01 && rect.width > 1 && rect.height > 1;
  }

  function setViewMode(item, mode, skipHistory) {
    var config = state.elements[item.id];
    if (!skipHistory) recordHistory("Exibição de " + item.label);
    config.viewMode = mode;
    config.visible = mode !== "hide";
    markCustom();
    saveState();
    applyElement(item);
  }

  function setAllViewModes(mode) {
    recordHistory("Exibição de todas as interfaces");
    elements.forEach(function (item) { setViewMode(item, mode, true); });
    renderViewRows();
    renderElementRows();
    setStudioStatus(mode === "show" ? "Todas as interfaces foram exibidas." : mode === "hide" ? "Todas as interfaces foram ocultadas." : "Exibição automática restaurada.", "ok");
  }

  function renderViewRows() {
    var body = document.getElementById("cobrinha-studio-view-list");
    if (!body) return;
    body.textContent = "";
    elements.forEach(function (item) {
      var config = state.elements[item.id];
      var mode = /^(show|hide)$/.test(config.viewMode || "") ? config.viewMode : "auto";
      var nodes = nodesFor(item);
      var actualVisible = nodes.some(nodeIsVisible);
      var row = document.createElement("div");
      row.className = "cobrinha-studio-view-row";
      var label = document.createElement("label");
      var checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = mode === "show" || (mode === "auto" && actualVisible);
      var name = document.createElement("strong");
      name.textContent = item.label;
      label.appendChild(checkbox);
      label.appendChild(name);
      var modeLabel = document.createElement("span");
      modeLabel.className = "cobrinha-studio-view-mode is-" + mode;
      modeLabel.textContent = mode === "show" ? "VISÍVEL" : mode === "hide" ? "OCULTA" : "AUTOMÁTICA";
      var automatic = document.createElement("button");
      automatic.type = "button";
      automatic.textContent = "Automático";
      automatic.title = "Respeitar automaticamente o menu e a partida";
      automatic.disabled = mode === "auto";
      checkbox.addEventListener("change", function () {
        setViewMode(item, checkbox.checked ? "show" : "hide");
        renderViewRows();
        renderElementRows();
      });
      automatic.addEventListener("click", function () {
        setViewMode(item, "auto");
        renderViewRows();
        renderElementRows();
      });
      row.appendChild(label);
      row.appendChild(modeLabel);
      row.appendChild(automatic);
      body.appendChild(row);
    });
  }

  function setStudioStatus(message, kind) {
    var status = document.getElementById("cobrinha-studio-status");
    if (!status) return;
    status.textContent = message || "";
    status.setAttribute("data-kind", kind || "ok");
  }

  function readFriends() {
    try {
      var list = JSON.parse(localStorage.getItem(FRIENDS_KEY) || "[]");
      return Array.isArray(list) ? list : [];
    } catch (error) { return []; }
  }

  function renderFriends() {
    var list = document.getElementById("cobrinha-studio-friends-list");
    if (!list) return;
    renderFriendPrivacy();
    list.textContent = "";
    var friends = readFriends();
    if (!friends.length) {
      var empty = document.createElement("span");
      empty.className = "cobrinha-studio-empty";
      empty.textContent = "Marque a estrela ao lado de alguém na sala para adicioná-lo.";
      list.appendChild(empty);
      return;
    }
    friends.forEach(function (friend) {
      var row = document.createElement("div");
      var identity = document.createElement("div");
      identity.className = "cobrinha-studio-friend-identity";
      var name = document.createElement("strong");
      name.textContent = "★ " + (friend.nickname || friend.name || "Amigo");
      var presence = document.createElement("span");
      var online = String(friend.status || "").toLowerCase() !== "offline" && friend.lastSeen && Date.now() - Date.parse(friend.lastSeen) < 15000;
      presence.className = online ? "is-online" : "";
      presence.textContent = online ? "on-line" + (friend.server ? " · " + friend.server : " · servidor privado") : "visto " + relativeTime(friend.lastSeen);
      identity.appendChild(name);
      identity.appendChild(presence);
      var buttons = document.createElement("div");
      buttons.className = "cobrinha-studio-friend-actions";
      if (friend.clientId) {
        var follow = document.createElement("button");
        follow.type = "button";
        var following = window.cobrinhaFriendPresence && window.cobrinhaFriendPresence.getFollow() === friend.clientId;
        follow.textContent = following ? "Parar" : "Seguir";
        follow.className = following ? "is-following" : "";
        follow.title = "Manter a seta direcionada para este amigo quando ele estiver no mesmo servidor";
        follow.addEventListener("click", function () {
          if (window.cobrinhaFriendPresence) window.cobrinhaFriendPresence.setFollow(following ? "" : friend.clientId);
          renderFriends();
        });
        buttons.appendChild(follow);
      }
      var remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "Remover";
      remove.addEventListener("click", function () {
        var updated = readFriends().filter(function (item) {
          return friend.clientId ? item.clientId !== friend.clientId : String(item.nickname || item.name).toLowerCase() !== String(friend.nickname || friend.name).toLowerCase();
        });
        localStorage.setItem(FRIENDS_KEY, JSON.stringify(updated));
        window.dispatchEvent(new CustomEvent("cobrinha-friends-changed"));
        renderFriends();
      });
      buttons.appendChild(remove);
      row.appendChild(identity);
      row.appendChild(buttons);
      list.appendChild(row);
    });
  }

  function relativeTime(value) {
    var timestamp = Date.parse(value || "");
    if (!Number.isFinite(timestamp)) return "nunca";
    var seconds = Math.max(0, Math.round((Date.now() - timestamp) / 1000));
    if (seconds < 60) return "há " + seconds + "s";
    if (seconds < 3600) return "há " + Math.floor(seconds / 60) + "min";
    if (seconds < 86400) return "há " + Math.floor(seconds / 3600) + "h";
    return "há " + Math.floor(seconds / 86400) + "d";
  }

  function renderFriendPrivacy() {
    var container = document.getElementById("cobrinha-studio-friend-privacy");
    if (!container) return;
    var api = window.cobrinhaFriendPresence;
    var privacy = api ? api.getPrivacy() : { sharePresence: true, shareServer: true, sharePosition: true, notifications: true };
    container.textContent = "";
    [["sharePresence", "Aparecer online para amigos"], ["shareServer", "Compartilhar servidor"], ["sharePosition", "Compartilhar posição para a seta"], ["notifications", "Avisar quando amigo entrar"]].forEach(function (entry) {
      var label = document.createElement("label");
      var checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = Boolean(privacy[entry[0]]);
      checkbox.addEventListener("change", function () {
        if (!api) return;
        var change = {};
        change[entry[0]] = checkbox.checked;
        api.setPrivacy(change);
        renderFriendPrivacy();
      });
      label.appendChild(checkbox);
      label.appendChild(document.createTextNode(entry[1]));
      container.appendChild(label);
    });
  }

  function readLocalStorage() {
    var storage = {};
    for (var index = 0; index < localStorage.length; index++) {
      var key = localStorage.key(index);
      if (!key || SENSITIVE_KEY.test(key)) continue;
      storage[key] = localStorage.getItem(key);
    }
    return storage;
  }

  function extensionStorage() {
    return new Promise(function (resolve) {
      if (!window.chrome || !chrome.storage || !chrome.storage.local) return resolve({});
      chrome.storage.local.get(null, function (entries) {
        resolve(chrome.runtime.lastError ? {} : entries || {});
      });
    });
  }

  function exportBackup() {
    setStudioStatus("Preparando backup...", "busy");
    extensionStorage().then(function (extensionEntries) {
      var helper = window.CobrinhaSettingsBackup;
      var payload = helper ? helper.create(readLocalStorage(), extensionEntries, chrome.runtime.getManifest().version) : {
        app: "Cobrinha Encasquetada", schema: 2, exportedAt: new Date().toISOString(),
        localStorage: readLocalStorage(), extensionStorage: extensionEntries
      };
      var blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      var url = URL.createObjectURL(blob);
      var anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "cobrinha-configuracoes-" + new Date().toISOString().slice(0, 10) + ".json";
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
      setStudioStatus("Backup completo salvo. Sessão, apelido e chaves privadas não foram incluídos.", "ok");
    }).catch(function () {
      setStudioStatus("Não foi possível criar o backup.", "error");
    });
  }

  function importBackup(file) {
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var payload = JSON.parse(String(reader.result || ""));
        var helper = window.CobrinhaSettingsBackup;
        var restored = helper ? helper.validate(payload) : payload;
        if (!restored || !restored.localStorage || typeof restored.localStorage !== "object") throw new Error("Arquivo incompatível.");
        Object.keys(restored.localStorage).forEach(function (key) {
          if (!SENSITIVE_KEY.test(key)) localStorage.setItem(key, String(restored.localStorage[key]));
        });
        var extensionEntries = restored.extensionStorage || {};
        var finish = function () {
          setStudioStatus("Configurações restauradas. Recarregando...", "ok");
          setTimeout(function () { location.reload(); }, 650);
        };
        if (window.chrome && chrome.storage && chrome.storage.local && Object.keys(extensionEntries).length) {
          chrome.storage.local.set(extensionEntries, function () {
            if (chrome.runtime.lastError) {
              setStudioStatus("Não foi possível restaurar o armazenamento interno.", "error");
              return;
            }
            finish();
          });
        } else finish();
      } catch (error) {
        setStudioStatus(error.message || "Não foi possível importar o arquivo.", "error");
      }
    };
    reader.onerror = function () { setStudioStatus("Não foi possível ler o arquivo.", "error"); };
    reader.readAsText(file);
  }

  function visibleNodesFor(item) {
    return nodesFor(item).filter(function (node) {
      var rect = node.getBoundingClientRect();
      var style = getComputedStyle(node);
      return style.display !== "none" && style.visibility !== "hidden" && rect.width > 2 && rect.height > 2;
    });
  }

  function groupRect(nodes) {
    if (!nodes.length) return null;
    var rects = nodes.map(function (node) { return node.getBoundingClientRect(); });
    var left = Math.min.apply(Math, rects.map(function (rect) { return rect.left; }));
    var top = Math.min.apply(Math, rects.map(function (rect) { return rect.top; }));
    var right = Math.max.apply(Math, rects.map(function (rect) { return rect.right; }));
    var bottom = Math.max.apply(Math, rects.map(function (rect) { return rect.bottom; }));
    return { left: left, top: top, right: right, bottom: bottom, width: right - left, height: bottom - top };
  }

  function snapValue(value, size, limit) {
    var candidates = [8, Math.round((limit - size) / 2), Math.max(8, limit - size - 8)];
    var closest = value;
    var distance = 11;
    candidates.forEach(function (candidate) {
      var nextDistance = Math.abs(value - candidate);
      if (nextDistance < distance) { closest = candidate; distance = nextDistance; }
    });
    return Math.round(closest / 4) * 4;
  }

  function moveNodes(item, nodes, dx, dy, baseRects, bounds) {
    var targetLeft = snapValue(bounds.left + dx, bounds.width, window.innerWidth);
    var targetTop = snapValue(bounds.top + dy, bounds.height, window.innerHeight);
    var adjustedX = targetLeft - bounds.left;
    var adjustedY = targetTop - bounds.top;
    var zoom = item ? Math.max(0.5, Number(state.elements[item.id].size || 100) / 100) : 1;
    nodes.forEach(function (node, index) {
      capturePosition(node);
      node.setAttribute("data-cobrinha-studio-positioned", "1");
      node.style.setProperty("--cobrinha-studio-left", Math.round((baseRects[index].left + adjustedX) / zoom) + "px");
      node.style.setProperty("--cobrinha-studio-top", Math.round((baseRects[index].top + adjustedY) / zoom) + "px");
      node.style.setProperty("position", "fixed", "important");
      node.style.setProperty("left", Math.round((baseRects[index].left + adjustedX) / zoom) + "px", "important");
      node.style.setProperty("top", Math.round((baseRects[index].top + adjustedY) / zoom) + "px", "important");
      node.style.setProperty("right", "auto", "important");
      node.style.setProperty("bottom", "auto", "important");
    });
  }

  function saveNodePositions(item, nodes) {
    state.elements[item.id].positions = nodes.map(function (node) {
      var rect = node.getBoundingClientRect();
      var zoom = Math.max(0.5, Number(state.elements[item.id].size || 100) / 100);
      return { left: rect.left / zoom, top: rect.top / zoom };
    });
    markCustom();
    saveState();
  }

  function resetElementLayout(item, options) {
    if (!item || !state.elements[item.id]) return;
    options = options || { position: true, size: true, appearance: false };
    recordHistory("Redefinição de " + item.label);
    var config = state.elements[item.id];
    if (options.position) config.positions = null;
    if (options.size) config.size = 100;
    if (options.appearance) {
      config.opacity = 100;
      config.visible = true;
      config.viewMode = "auto";
    }
    var nodes = nodesFor(item);
    if (options.position) {
      nodes.forEach(function (node) {
        node.removeAttribute("data-cobrinha-studio-positioned");
        node.style.removeProperty("--cobrinha-studio-left");
        node.style.removeProperty("--cobrinha-studio-top");
        restorePosition(node);
      });
      applyDefaultElementPlacement(item, nodes);
    }
    markCustom();
    saveState();
    applyElement(item);
    renderElementRows();
    refreshEditorOverlays();
    setStudioStatus(item.label + " foi redefinido conforme sua seleção.", "ok");
  }

  function applyDefaultElementPlacement(item, nodes) {
    if (typeof window.cobrinhaGetDefaultWindowLayout !== "function") return;
    var defaults = window.cobrinhaGetDefaultWindowLayout();
    if (!defaults) return;
    var panelNames = { shortcuts: "shortcuts", chat: "chat", room: "team" };
    var panelName = panelNames[item.id];
    var placement = panelName && defaults.panels && defaults.panels[panelName];
    if (!placement && item.id === "graph" && defaults.infobox) placement = defaults.infobox.mgraph;
    if (!placement && item.id === "minimap" && defaults.native) placement = defaults.native.minimap;
    if (!placement) return;
    nodes.forEach(function (node) {
      ["position", "left", "top", "right", "bottom", "width", "height"].forEach(function (property) {
        if (placement[property] !== undefined) node.style.setProperty(property, placement[property]);
      });
      if (panelName) {
        node.style.setProperty("right", "auto");
        node.style.setProperty("bottom", "auto");
      }
    });
    if (panelName) {
      window.dispatchEvent(new CustomEvent("cobrinha-apply-default-panel-layout", { detail: { name: panelName } }));
    }
    try {
      if (panelName) {
        var panelState = JSON.parse(localStorage.getItem("cobrinhaPanelStateV1") || "{}");
        if (!panelState || typeof panelState !== "object") panelState = {};
        if (!panelState[panelName]) panelState[panelName] = {};
        ["left", "top", "width", "height"].forEach(function (property) {
          panelState[panelName][property] = placement[property];
        });
        if (window.CobrinhaInterfaceState) window.CobrinhaInterfaceState.setPanels(panelState);
        else localStorage.setItem("cobrinhaPanelStateV1", JSON.stringify(panelState));
      }
      var infoKey = { shortcuts: "eemenu", chat: "bchat", graph: "mgraph" }[item.id];
      if (infoKey && defaults.infobox && defaults.infobox[infoKey]) {
        var infobox = JSON.parse(localStorage.getItem("infobox") || "{}");
        if (!infobox || typeof infobox !== "object") infobox = {};
        infobox[infoKey] = Object.assign({}, defaults.infobox[infoKey]);
        localStorage.setItem("infobox", JSON.stringify(infobox));
      }
      if (item.id === "minimap") {
        var savedInfobox = JSON.parse(localStorage.getItem("infobox") || "{}");
        if (savedInfobox && typeof savedInfobox === "object") {
          delete savedInfobox.mmap;
          localStorage.setItem("infobox", JSON.stringify(savedInfobox));
        }
      }
    } catch (error) {}
  }

  function confirmElementReset(item) {
    var old = document.getElementById("cobrinha-element-reset-confirm");
    if (old) old.remove();
    var backdrop = document.createElement("div");
    backdrop.id = "cobrinha-element-reset-confirm";
    backdrop.innerHTML = '<section role="alertdialog" aria-modal="true" aria-labelledby="cobrinha-reset-title"><strong id="cobrinha-reset-title">Redefinir ' + item.label + '?</strong><span>Escolha o que deve voltar ao padrão:</span><label><input type="checkbox" data-reset="position" checked> Posição</label><label><input type="checkbox" data-reset="size" checked> Tamanho</label><label><input type="checkbox" data-reset="appearance"> Aparência e visibilidade</label><div><button type="button" data-action="cancel">Cancelar</button><button type="button" data-action="confirm">Redefinir</button></div></section>';
    ["pointerdown", "mousedown", "mouseup", "click", "wheel"].forEach(function (type) {
      backdrop.addEventListener(type, function (event) { event.stopPropagation(); });
    });
    backdrop.querySelector('[data-action="cancel"]').addEventListener("click", function () { backdrop.remove(); });
    backdrop.querySelector('[data-action="confirm"]').addEventListener("click", function () {
      var options = {
        position: backdrop.querySelector('[data-reset="position"]').checked,
        size: backdrop.querySelector('[data-reset="size"]').checked,
        appearance: backdrop.querySelector('[data-reset="appearance"]').checked
      };
      if (!options.position && !options.size && !options.appearance) return;
      backdrop.remove();
      resetElementLayout(item, options);
    });
    document.body.appendChild(backdrop);
    backdrop.querySelector('[data-action="confirm"]').focus();
  }

  function beginDrag(event, item, overlay, resize) {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    selectedId = item.id;
    refreshEditorOverlays();
    var nodes = visibleNodesFor(item);
    nodes.forEach(capturePosition);
    var bounds = groupRect(nodes);
    if (!bounds) return;
    recordHistory((resize ? "Redimensionamento de " : "Movimento de ") + item.label);
    dragActive = true;
    var startX = event.clientX;
    var startY = event.clientY;
    var baseRects = nodes.map(function (node) {
      var rect = node.getBoundingClientRect();
      return { left: rect.left, top: rect.top };
    });
    var startSize = Number(state.elements[item.id].size) || 100;
    function move(moveEvent) {
      moveEvent.preventDefault();
      if (resize) {
        var minimumSize = item.id === "room" ? 100 : 50;
        var ratio = Math.max(minimumSize / 100, Math.min(2, (bounds.width + moveEvent.clientX - startX) / Math.max(20, bounds.width)));
        state.elements[item.id].size = Math.round(Math.max(minimumSize, Math.min(200, startSize * ratio)));
        applyElement(item);
      } else {
        moveNodes(item, nodes, moveEvent.clientX - startX, moveEvent.clientY - startY, baseRects, bounds);
      }
      refreshEditorOverlays();
    }
    var finished = false;
    function finish() {
      if (finished) return;
      finished = true;
      document.removeEventListener("pointermove", move, true);
      document.removeEventListener("pointerup", finish, true);
      document.removeEventListener("pointercancel", finish, true);
      dragActive = false;
      saveNodePositions(item, nodes);
      renderElementRows();
      refreshEditorOverlays();
    }
    document.addEventListener("pointermove", move, true);
    document.addEventListener("pointerup", finish, true);
    document.addEventListener("pointercancel", finish, true);
  }

  function createOverlay(item) {
    var nodes = visibleNodesFor(item);
    var rect = groupRect(nodes);
    if (!rect) return;
    var overlay = document.createElement("div");
    overlay.className = "cobrinha-editor-overlay" + (selectedId === item.id ? " is-selected" : "");
    overlay.setAttribute("data-element", item.id);
    overlay.style.left = Math.round(rect.left) + "px";
    overlay.style.top = Math.round(rect.top) + "px";
    overlay.style.width = Math.round(rect.width) + "px";
    overlay.style.height = Math.round(rect.height) + "px";
    var label = document.createElement("span");
    label.textContent = item.label;
    var resize = document.createElement("button");
    resize.type = "button";
    resize.className = "cobrinha-editor-resize";
    resize.title = "Arraste para redimensionar";
    var reset = document.createElement("button");
    reset.type = "button";
    reset.className = "cobrinha-editor-reset";
    reset.textContent = "↺";
    reset.title = "Redefinir somente " + item.label;
    reset.setAttribute("aria-label", reset.title);
    overlay.appendChild(label);
    overlay.appendChild(reset);
    overlay.appendChild(resize);
    overlay.addEventListener("pointerdown", function (event) {
      if (event.target === resize || event.target === reset) return;
      beginDrag(event, item, overlay, false);
    });
    reset.addEventListener("pointerdown", function (event) { event.preventDefault(); event.stopPropagation(); });
    reset.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      selectedId = item.id;
      refreshEditorOverlays();
      confirmElementReset(item);
    });
    resize.addEventListener("pointerdown", function (event) { beginDrag(event, item, overlay, true); });
    document.body.appendChild(overlay);
    overlays.push(overlay);
  }

  function refreshEditorOverlays() {
    overlays.forEach(function (overlay) { overlay.remove(); });
    overlays = [];
    if (!editorActive) return;
    elements.forEach(createOverlay);
  }

  function alignSelected(kind) {
    var item = itemById(selectedId);
    var nodes = visibleNodesFor(item);
    var bounds = groupRect(nodes);
    if (!item || !bounds) return;
    recordHistory("Alinhamento de " + item.label);
    var left = bounds.left;
    var top = bounds.top;
    if (kind === "left") left = 8;
    if (kind === "right") left = window.innerWidth - bounds.width - 8;
    if (kind === "hcenter") left = (window.innerWidth - bounds.width) / 2;
    if (kind === "top") top = 8;
    if (kind === "bottom") top = window.innerHeight - bounds.height - 8;
    if (kind === "vcenter") top = (window.innerHeight - bounds.height) / 2;
    var baseRects = nodes.map(function (node) { var rect = node.getBoundingClientRect(); return { left: rect.left, top: rect.top }; });
    moveNodes(item, nodes, left - bounds.left, top - bounds.top, baseRects, bounds);
    saveNodePositions(item, nodes);
    refreshEditorOverlays();
  }

  function toggleEditor(force) {
    editorActive = typeof force === "boolean" ? force : !editorActive;
    document.documentElement.classList.toggle("cobrinha-interface-editing", editorActive);
    var toolbar = document.getElementById("cobrinha-editor-toolbar");
    if (toolbar) toolbar.hidden = !editorActive;
    var studio = document.getElementById("cobrinha-interface-studio");
    if (studio) studio.hidden = editorActive;
    refreshEditorOverlays();
  }

  function restoreStudioLayout() {
    recordHistory("Restauração de todas as posições");
    elements.forEach(function (item) {
      state.elements[item.id].positions = null;
      state.elements[item.id].size = 100;
      nodesFor(item).forEach(function (node) {
        node.removeAttribute("data-cobrinha-studio-positioned");
        node.style.removeProperty("--cobrinha-studio-left");
        node.style.removeProperty("--cobrinha-studio-top");
        restorePosition(node);
      });
    });
    markCustom();
    saveState();
    applyAll();
    renderElementRows();
    setStudioStatus("Posições e tamanhos restaurados.", "ok");
  }

  function adaptLayoutToViewport() {
    var utils = window.CobrinhaLayoutUtils;
    if (!utils) return;
    var screen = utils.viewport(window.innerWidth, window.innerHeight, window.devicePixelRatio || 1);
    document.documentElement.setAttribute("data-cobrinha-viewport", utils.viewportClass(screen.width, screen.height));
    var changed = false;
    elements.forEach(function (item) {
      var config = state.elements[item.id];
      if (!config || !Array.isArray(config.positions)) return;
      var zoom = Math.max(0.5, Number(config.size || 100) / 100);
      nodesFor(item).forEach(function (node, index) {
        if (!config.positions[index]) return;
        var rect = node.getBoundingClientRect();
        var desired = { left: config.positions[index].left * zoom, top: config.positions[index].top * zoom };
        var next = utils.clampPosition(desired, { width: rect.width, height: rect.height }, screen, 8);
        var stored = { left: next.left / zoom, top: next.top / zoom };
        if (Math.abs(stored.left - config.positions[index].left) > 0.5 || Math.abs(stored.top - config.positions[index].top) > 0.5) {
          config.positions[index] = stored;
          changed = true;
        }
      });
    });
    if (changed) saveState();
    applyAll();
  }

  function createEditorToolbar() {
    var toolbar = document.createElement("div");
    toolbar.id = "cobrinha-editor-toolbar";
    toolbar.hidden = true;
    ["pointerdown", "mousedown", "mouseup", "click", "wheel"].forEach(function (type) {
      toolbar.addEventListener(type, function (event) { event.stopPropagation(); });
    });
    var title = document.createElement("strong");
    title.textContent = "Editando interface";
    toolbar.appendChild(title);
    var undo = document.createElement("button");
    undo.id = "cobrinha-editor-undo";
    undo.type = "button";
    undo.textContent = "↶";
    undo.addEventListener("click", undoInterfaceChange);
    var redo = document.createElement("button");
    redo.id = "cobrinha-editor-redo";
    redo.type = "button";
    redo.textContent = "↷";
    redo.addEventListener("click", redoInterfaceChange);
    toolbar.appendChild(undo);
    toolbar.appendChild(redo);
    [["left", "←"], ["hcenter", "↔"], ["right", "→"], ["top", "↑"], ["vcenter", "↕"], ["bottom", "↓"]].forEach(function (entry) {
      var button = document.createElement("button");
      button.type = "button";
      button.textContent = entry[1];
      button.title = "Alinhar " + entry[0];
      button.addEventListener("click", function () { alignSelected(entry[0]); });
      toolbar.appendChild(button);
    });
    var finish = document.createElement("button");
    finish.type = "button";
    finish.className = "is-finish";
    finish.textContent = "Concluir";
    finish.addEventListener("click", function () { toggleEditor(false); openStudio(); });
    toolbar.appendChild(finish);
    document.body.appendChild(toolbar);
    updateHistoryButtons();
  }

  function syncCompactPerformance() {
    var graph = document.getElementById("mgraph-box");
    if (!graph) return;
    var compact = document.getElementById("cobrinha-compact-performance");
    if (!compact) {
      compact = document.createElement("div");
      compact.id = "cobrinha-compact-performance";
      compact.setAttribute("aria-label", "Ping e FPS");
      compact.innerHTML = '<span class="cobrinha-compact-performance-label"><span>PING</span>/<span>FPS</span></span><strong><span id="cobrinha-compact-ping">0</span>/<span id="cobrinha-compact-fps">0</span></strong>';
      graph.appendChild(compact);
    }
    var pingSource = document.getElementById("id_ms");
    var fpsSource = document.getElementById("id_fps");
    var ping = pingSource ? String(pingSource.textContent || "").match(/\d+/) : null;
    var fps = fpsSource ? String(fpsSource.textContent || "").match(/\d+/) : null;
    var pingOutput = document.getElementById("cobrinha-compact-ping");
    var fpsOutput = document.getElementById("cobrinha-compact-fps");
    if (pingOutput) pingOutput.textContent = ping ? ping[0] : "0";
    if (fpsOutput) fpsOutput.textContent = fps ? fps[0] : "0";
  }

  function syncContextualUi() {
    var emojiEnabled = false;
    try { emojiEnabled = localStorage.getItem("eemji") === "true" || localStorage.getItem("eemji") === "1"; } catch (error) {}
    document.querySelectorAll(".emojiPickerIcon").forEach(function (icon) {
      icon.style.setProperty("display", emojiEnabled ? "" : "none", "important");
      icon.title = emojiEnabled ? "Escolher emoji" : "Ative os emojis nas configurações do chat";
    });
    var input = document.getElementById("ichat");
    if (input) input.style.setProperty("padding-left", emojiEnabled ? "28px" : "7px", "important");
  }

  function createStudio() {
    if (document.getElementById("cobrinha-interface-studio")) return;
    var modal = document.createElement("section");
    modal.id = "cobrinha-interface-studio";
    modal.hidden = true;
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-label", "Estúdio da Interface");
    ["pointerdown", "mousedown", "mouseup", "click", "wheel"].forEach(function (type) {
      modal.addEventListener(type, function (event) { event.stopPropagation(); });
    });
    var header = document.createElement("header");
    var heading = document.createElement("div");
    var title = document.createElement("strong");
    title.textContent = "Estúdio da Interface";
    var subtitle = document.createElement("span");
    subtitle.textContent = "Perfis, elementos, amigos e backup";
    heading.appendChild(title);
    heading.appendChild(subtitle);
    var close = document.createElement("button");
    close.type = "button";
    close.textContent = "×";
    close.title = "Fechar";
    close.addEventListener("click", closeStudio);
    header.appendChild(heading);
    header.appendChild(close);

    var profileBar = document.createElement("div");
    profileBar.className = "cobrinha-studio-profile-bar";
    var profileLabel = document.createElement("label");
    profileLabel.textContent = "Perfil";
    var profileSelect = document.createElement("select");
    profileSelect.id = "cobrinha-studio-profile";
    Object.keys(profiles).forEach(function (name) {
      var option = document.createElement("option");
      option.value = name;
      option.textContent = profiles[name].label;
      profileSelect.appendChild(option);
    });
    var custom = document.createElement("option");
    custom.value = "custom";
    custom.textContent = "Personalizado";
    profileSelect.appendChild(custom);
    profileSelect.value = localStorage.getItem(PROFILE_KEY) || "custom";
    profileSelect.addEventListener("change", function () {
      if (profileSelect.value === "custom") restoreCustomProfile();
      else setProfile(profileSelect.value);
    });
    profileLabel.appendChild(profileSelect);
    var edit = document.createElement("button");
    edit.type = "button";
    edit.textContent = "Editar visualmente";
    edit.addEventListener("click", function () { toggleEditor(true); });
    profileBar.appendChild(profileLabel);
    profileBar.appendChild(edit);

    var tabs = document.createElement("nav");
    var tabNames = [["elements", "Elementos"], ["friends", "Amigos"], ["backup", "Backup"]];
    tabNames.forEach(function (entry, index) {
      var button = document.createElement("button");
      button.type = "button";
      button.textContent = entry[1];
      button.className = index === 0 ? "is-active" : "";
      button.setAttribute("data-tab", entry[0]);
      button.addEventListener("click", function () {
        tabs.querySelectorAll("button").forEach(function (item) { item.classList.toggle("is-active", item === button); });
        modal.querySelectorAll(".cobrinha-studio-page").forEach(function (page) { page.hidden = page.getAttribute("data-page") !== entry[0]; });
        if (entry[0] === "friends") renderFriends();
      });
      tabs.appendChild(button);
    });

    var elementsPage = document.createElement("div");
    elementsPage.className = "cobrinha-studio-page";
    elementsPage.setAttribute("data-page", "elements");
    var elementActions = document.createElement("div");
    elementActions.className = "cobrinha-studio-element-actions";
    var restoreLayout = document.createElement("button");
    restoreLayout.type = "button";
    restoreLayout.textContent = "Restaurar posições e tamanhos";
    restoreLayout.addEventListener("click", restoreStudioLayout);
    elementActions.appendChild(restoreLayout);
    var elementsBody = document.createElement("div");
    elementsBody.id = "cobrinha-studio-elements";
    elementsPage.appendChild(elementActions);
    elementsPage.appendChild(elementsBody);

    var friendsPage = document.createElement("div");
    friendsPage.className = "cobrinha-studio-page";
    friendsPage.setAttribute("data-page", "friends");
    friendsPage.hidden = true;
    var friendsHelp = document.createElement("p");
    friendsHelp.textContent = "Amigos salvos recebem destaque, aviso de entrada e uma seta direcional durante a partida.";
    var friendsList = document.createElement("div");
    friendsList.id = "cobrinha-studio-friends-list";
    var friendPrivacy = document.createElement("div");
    friendPrivacy.id = "cobrinha-studio-friend-privacy";
    friendsPage.appendChild(friendsHelp);
    friendsPage.appendChild(friendPrivacy);
    friendsPage.appendChild(friendsList);

    var backupPage = document.createElement("div");
    backupPage.className = "cobrinha-studio-page cobrinha-studio-backup";
    backupPage.setAttribute("data-page", "backup");
    backupPage.hidden = true;
    var backupText = document.createElement("p");
    backupText.textContent = "Salva layout, atalhos, visibilidade, cores, amigos e preferências em um arquivo JSON. Sala atual, apelido e chaves privadas não são exportados.";
    var exportButton = document.createElement("button");
    exportButton.type = "button";
    exportButton.textContent = "Exportar configurações";
    exportButton.addEventListener("click", exportBackup);
    var importButton = document.createElement("button");
    importButton.type = "button";
    importButton.textContent = "Importar configurações";
    var fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = "application/json,.json";
    fileInput.hidden = true;
    importButton.addEventListener("click", function () { fileInput.click(); });
    fileInput.addEventListener("change", function () { importBackup(fileInput.files && fileInput.files[0]); });
    backupPage.appendChild(backupText);
    backupPage.appendChild(exportButton);
    backupPage.appendChild(importButton);
    backupPage.appendChild(fileInput);

    var status = document.createElement("footer");
    status.id = "cobrinha-studio-status";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    status.textContent = "As alterações são salvas automaticamente.";
    modal.appendChild(header);
    modal.appendChild(profileBar);
    modal.appendChild(tabs);
    modal.appendChild(elementsPage);
    modal.appendChild(friendsPage);
    modal.appendChild(backupPage);
    modal.appendChild(status);
    document.body.appendChild(modal);
    createEditorToolbar();
    renderElementRows();
    renderViewRows();
    renderFriends();
  }

  function openStudio() {
    createStudio();
    var modal = document.getElementById("cobrinha-interface-studio");
    if (modal) {
      modal.hidden = false;
      renderElementRows();
      renderViewRows();
      renderFriends();
    }
    var popup = document.getElementById("cobrinha-layout-popup");
    if (popup) popup.hidden = true;
    var externalView = document.getElementById("cobrinha-layout-view");
    if (externalView) externalView.hidden = true;
  }

  function closeStudio() {
    var modal = document.getElementById("cobrinha-interface-studio");
    if (modal) modal.hidden = true;
  }

  function attachLauncher() {
    var popup = document.getElementById("cobrinha-layout-popup");
    if (!popup || popup.querySelector(".cobrinha-open-studio")) return;
    var studioButton = document.createElement("button");
    studioButton.type = "button";
    studioButton.className = "cobrinha-open-studio";
    studioButton.textContent = "Editar posições e tamanhos";
    studioButton.addEventListener("click", openStudio);
    var viewButton = document.createElement("button");
    viewButton.type = "button";
    viewButton.className = "cobrinha-open-view";
    viewButton.textContent = "Escolher itens visíveis";
    var viewPanel = document.createElement("section");
    viewPanel.id = "cobrinha-layout-view";
    viewPanel.hidden = true;
    viewPanel.setAttribute("role", "dialog");
    viewPanel.setAttribute("aria-modal", "true");
    viewPanel.setAttribute("aria-label", "Interfaces visíveis");
    var viewHeader = document.createElement("header");
    var viewTitle = document.createElement("strong");
    viewTitle.textContent = "Interfaces visíveis";
    var viewClose = document.createElement("button");
    viewClose.type = "button";
    viewClose.textContent = "×";
    viewClose.title = "Fechar";
    viewHeader.appendChild(viewTitle);
    viewHeader.appendChild(viewClose);
    var viewHelp = document.createElement("p");
    viewHelp.textContent = "Mostre ou oculte itens sem usar atalhos. O modo Automático respeita o menu e a partida.";
    var viewActions = document.createElement("div");
    viewActions.className = "cobrinha-studio-view-actions";
    [["Todas", "show"], ["Nenhuma", "hide"], ["Automático", "auto"]].forEach(function (entry) {
      var action = document.createElement("button");
      action.type = "button";
      action.textContent = entry[0];
      action.addEventListener("click", function () { setAllViewModes(entry[1]); });
      viewActions.appendChild(action);
    });
    var viewList = document.createElement("div");
    viewList.id = "cobrinha-studio-view-list";
    viewPanel.appendChild(viewHeader);
    viewPanel.appendChild(viewHelp);
    viewPanel.appendChild(viewActions);
    viewPanel.appendChild(viewList);
    viewButton.addEventListener("click", function () {
      popup.hidden = true;
      viewPanel.hidden = false;
      renderViewRows();
    });
    viewClose.addEventListener("click", function () { viewPanel.hidden = true; });
    ["pointerdown", "mousedown", "mouseup", "click", "wheel"].forEach(function (type) {
      viewPanel.addEventListener(type, function (event) { event.stopPropagation(); });
    });
    var actionContainer = popup.querySelector("#cobrinha-layout-interface-actions") || popup;
    var reset = actionContainer.querySelector(".cobrinha-layout-reset");
    actionContainer.insertBefore(studioButton, reset || null);
    actionContainer.insertBefore(viewButton, reset || null);
    document.body.appendChild(viewPanel);
    renderViewRows();
  }

  window.cobrinhaApplyInterfaceProfile = setProfile;
  window.cobrinhaOpenInterfaceEditor = function () {
    createStudio();
    toggleEditor(true);
  };

  window.addEventListener("cobrinha-friends-changed", renderFriends);
  window.addEventListener("cobrinha-friend-presence-updated", renderFriends);
  window.addEventListener("cobrinha-friend-privacy-changed", renderFriends);
  window.addEventListener("cobrinha-interface-preference-changed", function () { markCustom(); });
  window.addEventListener("cobrinha-panel-opacity-changed", function (event) {
    var names = { shortcuts: "shortcuts", chat: "chat", team: "room" };
    var id = event.detail && names[event.detail.name];
    if (!id || !state.elements[id]) return;
    state.elements[id].opacity = Math.round(Math.max(0, Math.min(1, Number(event.detail.opacity))) * 100);
    markCustom();
    saveState();
    applyElement(itemById(id));
    renderElementRows();
  });
  window.addEventListener("cobrinha-panel-position-changed", function (event) {
    var names = { shortcuts: "shortcuts", chat: "chat", team: "room" };
    var id = event.detail && names[event.detail.name];
    var item = itemById(id);
    if (!item || !state.elements[id]) return;
    var zoom = Math.max(0.5, Number(state.elements[id].size || 100) / 100);
    state.elements[id].positions = nodesFor(item).map(function (node) {
      var rect = node.getBoundingClientRect();
      return { left: rect.left / zoom, top: rect.top / zoom };
    });
    markCustom();
    saveState();
    renderElementRows();
  });
  window.addEventListener("cobrinha-tech-hud-changed", function (event) {
    if (!event.detail) return;
    var opacity = Number(event.detail.opacity);
    var size = Number(event.detail.size);
    if (Number.isFinite(opacity)) state.elements.technical.opacity = Math.max(0, Math.min(100, opacity));
    if (Number.isFinite(size)) state.elements.technical.size = Math.round(Math.max(50, Math.min(200, size / 13 * 100)));
    markCustom();
    saveState();
    applyElement(itemById("technical"));
    renderElementRows();
  });
  var responsiveTimer = 0;
  function scheduleResponsiveLayout() {
    clearTimeout(responsiveTimer);
    responsiveTimer = setTimeout(adaptLayoutToViewport, 100);
  }
  window.addEventListener("resize", scheduleResponsiveLayout);
  document.addEventListener("fullscreenchange", scheduleResponsiveLayout);
  if (window.visualViewport) window.visualViewport.addEventListener("resize", scheduleResponsiveLayout);
  document.addEventListener("keydown", function (event) {
    var insideStudio = event.target && event.target.closest && event.target.closest("#cobrinha-interface-studio");
    if (editorActive && (event.ctrlKey || event.metaKey) && !event.altKey) {
      if (String(event.key).toLowerCase() === "z") {
        event.preventDefault();
        event.stopImmediatePropagation();
        if (event.shiftKey) redoInterfaceChange();
        else undoInterfaceChange();
        return;
      }
      if (String(event.key).toLowerCase() === "y") {
        event.preventDefault();
        event.stopImmediatePropagation();
        redoInterfaceChange();
        return;
      }
    }
    if (insideStudio) {
      if (event.key === "Escape") closeStudio();
      event.stopImmediatePropagation();
      return;
    }
    if (event.key === "Escape") {
      var externalView = document.getElementById("cobrinha-layout-view");
      if (externalView && !externalView.hidden) {
        externalView.hidden = true;
        return;
      }
      if (editorActive) toggleEditor(false);
      else closeStudio();
    }
  }, true);

  new MutationObserver(function () {
    if (editorActive || dragActive) return;
    clearTimeout(applyTimer);
    applyTimer = setTimeout(function () { attachLauncher(); applyAll(); }, 30);
  }).observe(document.documentElement, { childList: true, subtree: true });

  attachLauncher();
  adaptLayoutToViewport();
  applyAll();
  window.cobrinhaInterfaceStudioReady = true;
  if (window.CobrinhaScheduler) {
    window.CobrinhaScheduler.every("interface-studio", function () { attachLauncher(); applyAll(); }, 800);
  } else setInterval(function () { attachLauncher(); applyAll(); }, 800);
})();
