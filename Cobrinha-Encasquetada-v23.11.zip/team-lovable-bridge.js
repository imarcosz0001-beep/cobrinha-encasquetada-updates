(function () {
  "use strict";
  if (window.cobrinhaFriendPresence) return;

  var FRIENDS_KEY = "cobrinhaFriendsV1";
  var BLOCKED_KEY = "cobrinhaBlockedFriendsV1";
  var INVITE_KEY = "cobrinhaFriendInviteV2";
  var FOLLOW_KEY = "cobrinhaFriendFollowV1";
  var pending = {};

  function readList(key) {
    try {
      var value = JSON.parse(localStorage.getItem(key) || "[]");
      return Array.isArray(value) ? value : [];
    } catch (error) { return []; }
  }

  function writeList(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new CustomEvent("cobrinha-friends-changed"));
  }

  function call(action, args) {
    return new Promise(function (resolve, reject) {
      var id = "friend-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
      pending[id] = { resolve: resolve, reject: reject };
      window.dispatchEvent(new CustomEvent("cobrinha-friend-bridge-request", {
        detail: JSON.stringify({ id: id, action: action, args: args || [] })
      }));
      setTimeout(function () {
        if (!pending[id]) return;
        delete pending[id];
        reject(new Error("O serviço de amigos demorou para responder."));
      }, 10000);
    });
  }

  window.addEventListener("cobrinha-friend-bridge-response", function (event) {
    var response;
    try { response = JSON.parse(String(event.detail || "{}")); } catch (error) { return; }
    var request = response && pending[response.id];
    if (!request) return;
    delete pending[response.id];
    if (response.ok) request.resolve(response.result);
    else request.reject(new Error(response.error || "Não foi possível concluir a ação."));
  });

  window.cobrinhaFriendPresence = {
    listFriends: function () { return readList(FRIENDS_KEY); },
    listBlocked: function () { return readList(BLOCKED_KEY); },
    currentInvite: function () {
      try { return JSON.parse(localStorage.getItem(INVITE_KEY) || "null"); }
      catch (error) { return null; }
    },
    ownInvite: function () { return call("ownInvite"); },
    revokeInvite: function () { return call("revokeInvite"); },
    addByInvite: function (code, label) { return call("addByInvite", [code, label]); },
    joinServer: function (server) { return call("joinServer", [server]); },
    removeFriend: function (key) {
      writeList(FRIENDS_KEY, readList(FRIENDS_KEY).filter(function (friend) { return String(friend && (friend.identityKey || friend.clientId) || "") !== String(key); }));
    },
    blockFriend: function (key, nickname) {
      var blocked = readList(BLOCKED_KEY);
      if (!blocked.some(function (item) { return String(item.key) === String(key); })) blocked.push({ key: String(key), nickname: String(nickname || "Jogador"), blockedAt: Date.now() });
      writeList(BLOCKED_KEY, blocked);
      this.removeFriend(key);
    },
    unblockFriend: function (key) {
      writeList(BLOCKED_KEY, readList(BLOCKED_KEY).filter(function (item) { return String(item.key) !== String(key); }));
    },
    getFollow: function () { return localStorage.getItem(FOLLOW_KEY) || ""; },
    setFollow: function (key) {
      if (key) localStorage.setItem(FOLLOW_KEY, String(key));
      else localStorage.removeItem(FOLLOW_KEY);
      window.dispatchEvent(new CustomEvent("cobrinha-friend-presence-updated"));
    }
  };
  window.dispatchEvent(new CustomEvent("cobrinha-friend-service-ready"));
})();
