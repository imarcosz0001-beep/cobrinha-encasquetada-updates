(function () {
  "use strict";
  if (document.documentElement.dataset.cobrinhaSafeMode === "1") return;

  var STATE_KEY = "cobrinhaPanelStateV1";
  var GAP_KEY = "cobrinhaPanelGapV1";
  var TEAM_MODE_KEY = "cobrinhaTeamPanelMode";
  var TEAM_COMPACT_LAYOUT_KEY = "cobrinhaTeamCompactLayoutV1";
  var BOX_MODE_KEY = "cobrinhaBoxVisualMode";
  var MINIMAL_BG_ENABLED_KEY = "cobrinhaMinimalBackgroundEnabled";
  var MINIMAL_BG_COLOR_KEY = "cobrinhaMinimalBackgroundColor";
  var MINIMAL_BG_OPACITY_KEY = "cobrinhaMinimalBackgroundOpacity";
  var TECH_HUD_OPACITY_KEY = "cobrinhaTechHudOpacity";
  var TECH_HUD_SIZE_KEY = "cobrinhaTechHudSize";
  var state = loadState();
  var resizeObservers = {};
  var saveTimer = 0;

  function loadState() {
    if (window.CobrinhaInterfaceState) return window.CobrinhaInterfaceState.getPanels();
    try {
      var saved = JSON.parse(localStorage.getItem(STATE_KEY) || "{}");
      return saved && typeof saved === "object" ? saved : {};
    } catch (error) {
      return {};
    }
  }

  function persistStateNow() {
    try {
      if (window.CobrinhaInterfaceState) window.CobrinhaInterfaceState.setPanels(state);
      else localStorage.setItem(STATE_KEY, JSON.stringify(state));
    } catch (error) {}
  }

  function saveStateSoon() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(persistStateNow, 120);
  }

  function panelState(name) {
    if (!state[name]) state[name] = {};
    return state[name];
  }

  function updateButton(button, collapsed) {
    button.textContent = collapsed ? "+" : "−";
    button.title = collapsed ? "Expandir painel" : "Minimizar painel";
    button.setAttribute("aria-label", button.title);
  }

  function togglePanel(panel, name, button) {
    var saved = panelState(name);
    var collapsing = !panel.classList.contains("cobrinha-panel-collapsed");
    if (collapsing) {
      saved.width = Math.round(panel.getBoundingClientRect().width) + "px";
      saved.height = Math.round(panel.getBoundingClientRect().height) + "px";
    }
    saved.collapsed = collapsing;
    panel.classList.toggle("cobrinha-panel-collapsed", collapsing);
    if (!collapsing) {
      if (saved.width) panel.style.width = saved.width;
      if (saved.height) panel.style.height = saved.height;
    }
    updateButton(button, collapsing);
    saveStateSoon();
  }

  function observeSize(panel, name) {
    if (typeof ResizeObserver !== "function") return;
    if (resizeObservers[name] && resizeObservers[name].panel === panel) return;
    if (resizeObservers[name]) resizeObservers[name].observer.disconnect();
    var observer = new ResizeObserver(function () {
      if (panel.classList.contains("cobrinha-panel-collapsed")) return;
      if (name === "team" && panel.classList.contains("cobrinha-team-minimal")) return;
      var rect = panel.getBoundingClientRect();
      if (rect.width < 1 || rect.height < 1) return;
      var saved = panelState(name);
      saved.width = Math.round(rect.width) + "px";
      saved.height = Math.round(rect.height) + "px";
      saveStateSoon();
    });
    resizeObservers[name] = { panel: panel, observer: observer };
    observer.observe(panel);
  }

  function applySavedPanelState(panel, name) {
    if (panel.dataset.cobrinhaPanelState === "1") return;
    panel.dataset.cobrinhaPanelState = "1";
    var saved = panelState(name);
    if (saved.width) panel.style.width = saved.width;
    if (saved.height && !saved.collapsed) panel.style.height = saved.height;
    if (saved.left != null && saved.top != null) {
      panel.style.left = saved.left;
      panel.style.top = saved.top;
      panel.style.right = "auto";
      panel.style.bottom = "auto";
    }
    panel.style.setProperty("--cobrinha-panel-opacity", String(saved.opacity == null ? 1 : saved.opacity));
    panel.classList.toggle("cobrinha-panel-collapsed", saved.collapsed === true);
    observeSize(panel, name);
  }

  function makeToggle(panel, name) {
    var button = panel.querySelector(":scope > .cobrinha-panel-toggle");
    if (!button) {
      button = document.createElement("button");
      button.type = "button";
      button.className = "cobrinha-panel-toggle";
      button.addEventListener("mousedown", function (event) {
        event.preventDefault();
        event.stopPropagation();
      });
      button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        togglePanel(panel, name, button);
      });
      panel.appendChild(button);
    }
    updateButton(button, panel.classList.contains("cobrinha-panel-collapsed"));
  }

  function makeOpacityControl(panel, name) {
    var input = panel.querySelector(":scope > .cobrinha-panel-opacity");
    var saved = panelState(name);
    if (!input) {
      input = document.createElement("input");
      input.type = "range";
      input.className = "cobrinha-panel-opacity";
      input.min = "0.3";
      input.max = "1";
      input.step = "0.05";
      input.title = "Opacidade do painel";
      input.setAttribute("aria-label", input.title);
      input.addEventListener("pointerdown", function (event) { event.stopPropagation(); });
      input.addEventListener("mousedown", function (event) { event.stopPropagation(); });
      input.addEventListener("click", function (event) { event.stopPropagation(); });
      input.addEventListener("input", function (event) {
        event.stopPropagation();
        var opacity = Math.max(0.3, Math.min(1, Number(input.value) || 1));
        panel.style.setProperty("--cobrinha-panel-opacity", String(opacity));
        panelState(name).opacity = opacity;
        saveStateSoon();
        window.dispatchEvent(new CustomEvent("cobrinha-panel-opacity-changed", { detail: { name: name, opacity: opacity } }));
      });
      panel.appendChild(input);
    }
    input.value = String(saved.opacity == null ? 1 : saved.opacity);
  }

  function savePanelPosition(panel, name) {
    var saved = panelState(name);
    saved.left = panel.style.left;
    saved.top = panel.style.top;
    saveStateSoon();
    var rect = panel.getBoundingClientRect();
    window.dispatchEvent(new CustomEvent("cobrinha-panel-position-changed", {
      detail: { name: name, left: rect.left, top: rect.top }
    }));
    if (name === "shortcuts" || name === "chat") {
      try {
        var info = JSON.parse(localStorage.getItem("infobox") || "{}");
        if (!info || typeof info !== "object") info = {};
        var key = name === "shortcuts" ? "eemenu" : "bchat";
        if (!info[key]) info[key] = {};
        info[key].left = panel.style.left;
        info[key].top = panel.style.top;
        info[key].right = "";
        info[key].bottom = "";
        localStorage.setItem("infobox", JSON.stringify(info));
      } catch (error) {}
    }
  }

  function enableDrag(panel, name, handle) {
    if (!handle || handle.dataset.cobrinhaDrag === "1") return;
    handle.dataset.cobrinhaDrag = "1";
    handle.addEventListener("pointerdown", function (event) {
      if (event.button !== 0 || event.target.closest && event.target.closest("button, input")) return;
      event.preventDefault();
      event.stopPropagation();
      var rect = panel.getBoundingClientRect();
      var offsetX = event.clientX - rect.left;
      var offsetY = event.clientY - rect.top;
      var scaleX = panel.offsetWidth > 0 ? rect.width / panel.offsetWidth : 1;
      var scaleY = panel.offsetHeight > 0 ? rect.height / panel.offsetHeight : scaleX;
      if (!Number.isFinite(scaleX) || scaleX <= 0) scaleX = 1;
      if (!Number.isFinite(scaleY) || scaleY <= 0) scaleY = scaleX;
      var initialLeft = Math.round(rect.left / scaleX);
      var initialTop = Math.round(rect.top / scaleY);
      panel.setAttribute("data-cobrinha-studio-positioned", "1");
      panel.style.setProperty("--cobrinha-studio-left", initialLeft + "px");
      panel.style.setProperty("--cobrinha-studio-top", initialTop + "px");
      panel.style.setProperty("left", initialLeft + "px", "important");
      panel.style.setProperty("top", initialTop + "px", "important");
      panel.style.setProperty("right", "auto", "important");
      panel.style.setProperty("bottom", "auto", "important");
      panel.classList.add("cobrinha-panel-dragging");
      window.cobrinhaActivePanelDrag = name;

      function move(moveEvent) {
        moveEvent.preventDefault();
        moveEvent.stopPropagation();
        var viewportWidth = Math.max(window.innerWidth || 0, document.documentElement.clientWidth || 0);
        var viewportHeight = Math.max(window.innerHeight || 0, document.documentElement.clientHeight || 0);
        var maxLeft = Math.max(0, viewportWidth - rect.width);
        var maxTop = Math.max(0, viewportHeight - rect.height);
        var visualLeft = Math.max(0, Math.min(maxLeft, moveEvent.clientX - offsetX));
        var visualTop = Math.max(0, Math.min(maxTop, moveEvent.clientY - offsetY));
        var layoutLeft = Math.round(visualLeft / scaleX);
        var layoutTop = Math.round(visualTop / scaleY);
        panel.style.setProperty("--cobrinha-studio-left", layoutLeft + "px");
        panel.style.setProperty("--cobrinha-studio-top", layoutTop + "px");
        panel.style.setProperty("left", layoutLeft + "px", "important");
        panel.style.setProperty("top", layoutTop + "px", "important");
      }

      function finish(finishEvent) {
        if (finishEvent) finishEvent.stopPropagation();
        document.removeEventListener("pointermove", move, true);
        document.removeEventListener("pointerup", finish, true);
        document.removeEventListener("pointercancel", finish, true);
        panel.classList.remove("cobrinha-panel-dragging");
        savePanelPosition(panel, name);
        if (window.cobrinhaActivePanelDrag === name) window.cobrinhaActivePanelDrag = "";
      }

      document.addEventListener("pointermove", move, true);
      document.addEventListener("pointerup", finish, true);
      document.addEventListener("pointercancel", finish, true);
    });
  }

  function makeDragHandle(panel, name) {
    var handle = panel.querySelector(":scope > .cobrinha-panel-drag-handle");
    if (!handle) {
      handle = document.createElement("div");
      handle.className = "cobrinha-panel-drag-handle";
      handle.title = "Arraste para mover o painel";
      panel.appendChild(handle);
    }
    enableDrag(panel, name, handle);
  }

  function prepareShortcutPanel() {
    var panel = document.getElementById("eemenu");
    if (!panel) return false;
    separateShortcutRows(panel);
    applySavedPanelState(panel, "shortcuts");
    makeToggle(panel, "shortcuts");
    makeOpacityControl(panel, "shortcuts");
    makeDragHandle(panel, "shortcuts");
    return true;
  }

  function separateShortcutRows(panel) {
    Array.prototype.forEach.call(panel.querySelectorAll(".eem"), function (key, index) {
      if (index === 0) return;
      var before = key.previousSibling;
      if (!before || before.nodeType !== 3) return;
      var text = before.nodeValue || "";
      var bracket = text.lastIndexOf("[");
      if (bracket < 0) return;
      var previous = before.previousSibling;
      if (text === "[" && previous && previous.nodeName === "BR") return;
      before.nodeValue = text.slice(0, bracket).replace(/[ \t]+$/, "");
      var line = document.createElement("br");
      line.className = "cobrinha-shortcut-line";
      key.parentNode.insertBefore(line, key);
      key.parentNode.insertBefore(document.createTextNode("["), key);
    });
  }

  function prepareChatPanel() {
    var panel = document.getElementById("bchat");
    if (!panel) return false;
    applySavedPanelState(panel, "chat");
    var bar = panel.querySelector(":scope > .cobrinha-chat-bar");
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "cobrinha-chat-bar";
      bar.textContent = "Mensagens e informações";
      panel.insertBefore(bar, panel.firstChild);
    }
    makeChatExitButton(panel);
    makeToggle(panel, "chat");
    makeOpacityControl(panel, "chat");
    enableDrag(panel, "chat", bar);
    return true;
  }

  function releaseChatFocus() {
    var input = document.getElementById("ichat");
    if (!input) return;
    try {
      if (window.jQuery && jQuery.data(input, "emojiPicker")) jQuery(input).emojiPicker("hide");
    } catch (error) {}
    try { input.blur(); } catch (error) {}
    setTimeout(function () {
      try { input.blur(); } catch (error) {}
      try { window.focus(); } catch (error) {}
    }, 0);
  }

  function makeChatExitButton(panel) {
    var button = panel.querySelector(":scope > .cobrinha-chat-exit");
    if (button) return;
    button = document.createElement("button");
    button.type = "button";
    button.className = "cobrinha-chat-exit";
    button.textContent = "Sair";
    button.title = "Sair do chat e devolver as teclas ao jogo";
    button.setAttribute("aria-label", button.title);
    button.addEventListener("pointerdown", function (event) {
      event.preventDefault();
      event.stopPropagation();
    });
    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      releaseChatFocus();
    });
    panel.appendChild(button);
  }

  function prepareTeamPanel() {
    var panel = document.getElementById("lovable-team-panel");
    if (!panel) return false;
    try {
      if (localStorage.getItem(TEAM_COMPACT_LAYOUT_KEY) !== "1") {
        delete panelState("team").width;
        delete panelState("team").height;
        localStorage.setItem(TEAM_COMPACT_LAYOUT_KEY, "1");
        saveStateSoon();
      }
    } catch (error) {}
    applySavedPanelState(panel, "team");
    applyTeamPanelMode(panel);
    makeToggle(panel, "team");
    makeOpacityControl(panel, "team");
    enableDrag(panel, "team", panel.querySelector(":scope > .lovable-team-title"));
    return true;
  }

  function currentTeamPanelMode() {
    try { return localStorage.getItem(TEAM_MODE_KEY) === "minimal" ? "minimal" : "full"; }
    catch (error) { return "full"; }
  }

  function currentBoxVisualMode() {
    try { return localStorage.getItem(BOX_MODE_KEY) === "minimal" ? "minimal" : "standard"; }
    catch (error) { return "standard"; }
  }

  function applyBoxVisualMode() {
    document.documentElement.classList.toggle("cobrinha-boxes-minimal", currentBoxVisualMode() === "minimal");
  }

  function minimalBackgroundSettings() {
    var enabled = false;
    var color = "#000000";
    var opacity = 0.15;
    try {
      enabled = localStorage.getItem(MINIMAL_BG_ENABLED_KEY) === "1";
      var savedColor = localStorage.getItem(MINIMAL_BG_COLOR_KEY);
      var savedOpacityValue = localStorage.getItem(MINIMAL_BG_OPACITY_KEY);
      var savedOpacity = Number(savedOpacityValue);
      if (/^#[0-9a-f]{6}$/i.test(savedColor || "")) color = savedColor;
      if (savedOpacityValue != null && Number.isFinite(savedOpacity)) opacity = Math.max(0, Math.min(1, savedOpacity));
    } catch (error) {}
    return { enabled: enabled, color: color, opacity: opacity };
  }

  function backgroundRgba(color, opacity) {
    var value = String(color || "#000000").replace("#", "");
    if (!/^[0-9a-f]{6}$/i.test(value)) value = "000000";
    return "rgba(" + parseInt(value.slice(0, 2), 16) + ", " + parseInt(value.slice(2, 4), 16) + ", " + parseInt(value.slice(4, 6), 16) + ", " + opacity + ")";
  }

  function applyMinimalBackground() {
    var settings = minimalBackgroundSettings();
    document.documentElement.classList.toggle("cobrinha-minimal-background", settings.enabled);
    document.documentElement.style.setProperty("--cobrinha-minimal-panel-bg", backgroundRgba(settings.color, settings.opacity));
  }

  function technicalHudSettings() {
    var opacity = 1;
    var size = 13;
    try {
      var savedOpacity = localStorage.getItem(TECH_HUD_OPACITY_KEY);
      var savedSize = localStorage.getItem(TECH_HUD_SIZE_KEY);
      if (savedOpacity != null && Number.isFinite(Number(savedOpacity))) opacity = Math.max(0, Math.min(1, Number(savedOpacity)));
      if (savedSize != null && Number.isFinite(Number(savedSize))) size = Math.max(8, Math.min(24, Number(savedSize)));
    } catch (error) {}
    return { opacity: opacity, size: size };
  }

  function applyTechnicalHud() {
    var settings = technicalHudSettings();
    document.documentElement.style.setProperty("--cobrinha-tech-hud-opacity", String(settings.opacity));
    document.documentElement.style.setProperty("--cobrinha-tech-hud-size", settings.size + "px");
  }

  function applyTeamPanelMode(panel) {
    panel = panel || document.getElementById("lovable-team-panel");
    if (!panel) return;
    panel.classList.toggle("cobrinha-team-minimal", currentTeamPanelMode() === "minimal");
  }

  function applyPanelGap() {
    try { if (localStorage.getItem(GAP_KEY) === "1") return true; } catch (error) {}
    var shortcuts = document.getElementById("eemenu");
    var chat = document.getElementById("bchat");
    if (!shortcuts || !chat) return false;

    var shortcutTop = parseFloat(shortcuts.style.top) || 4;
    var shortcutHeight = shortcuts.offsetHeight || parseFloat(shortcuts.style.height) || 215;
    var chatTop = parseFloat(chat.style.top) || 220;
    var requiredChatTop = shortcutTop + shortcutHeight + 12;
    if (chatTop < requiredChatTop) {
      chatTop = requiredChatTop;
      chat.style.top = Math.round(chatTop) + "px";
    }

    var details = document.getElementById("divtl");
    if (details) {
      var chatHeight = chat.offsetHeight || parseFloat(chat.style.height) || 230;
      var detailsTop = parseFloat(details.style.top) || 450;
      var requiredDetailsTop = chatTop + chatHeight + 12;
      if (detailsTop < requiredDetailsTop) details.style.top = Math.round(requiredDetailsTop) + "px";
    }

    try {
      var info = JSON.parse(localStorage.getItem("infobox") || "{}");
      if (!info || typeof info !== "object") info = {};
      if (!info.bchat) info.bchat = {};
      info.bchat.top = chat.style.top;
      if (details) {
        if (!info.divtl) info.divtl = {};
        info.divtl.top = details.style.top;
      }
      localStorage.setItem("infobox", JSON.stringify(info));
      localStorage.setItem(GAP_KEY, "1");
    } catch (error) {}
    return true;
  }

  function prepareAll() {
    var shortcutsReady = prepareShortcutPanel();
    var chatReady = prepareChatPanel();
    prepareTeamPanel();
    if (shortcutsReady && chatReady) applyPanelGap();
    return shortcutsReady && chatReady;
  }

  function defaultWindowLayout() {
    if (window.CobrinhaLayoutUtils && typeof window.CobrinhaLayoutUtils.defaultWindowLayout === "function") {
      return window.CobrinhaLayoutUtils.defaultWindowLayout(window.innerWidth, window.innerHeight);
    }
    var viewportWidth = Math.max(640, window.innerWidth || document.documentElement.clientWidth || 1280);
    var viewportHeight = Math.max(600, window.innerHeight || document.documentElement.clientHeight || 720);
    var shortcutsTop = Math.round(Math.max(84, Math.min(132, viewportHeight * 0.146)));
    var shortcutsHeight = Math.round(Math.max(170, Math.min(238, viewportHeight * 0.263)));
    var groupGap = Math.round(Math.max(34, Math.min(70, viewportHeight * 0.0775)));
    var chatTop = shortcutsTop + shortcutsHeight + groupGap;
    var chatHeight = Math.round(Math.max(190, Math.min(254, viewportHeight * 0.281)));
    var teamWidth = 195;
    var teamTop = Math.round(Math.max(150, Math.min(230, viewportHeight * 0.255)));
    return {
      panels: {
        shortcuts: { left: "0px", top: shortcutsTop + "px", width: "300px", height: shortcutsHeight + "px", opacity: 1, collapsed: false },
        chat: { left: "0px", top: chatTop + "px", width: "300px", height: chatHeight + "px", opacity: 1, collapsed: false },
        team: { left: Math.max(0, viewportWidth - teamWidth - 4) + "px", top: teamTop + "px", width: teamWidth + "px", opacity: 1, collapsed: false }
      },
      infobox: {
        eemenu: { left: "0px", top: shortcutsTop + "px", right: "", bottom: "", width: "300px", height: shortcutsHeight + "px" },
        bchat: { left: "0px", top: chatTop + "px", right: "", bottom: "", width: "300px", height: chatHeight + "px" },
        mgraph: { left: "0px", right: "", top: "", bottom: "40px", width: "545px", height: "110px" }
      },
      native: {
        minimap: { position: "fixed", left: "auto", top: "auto", right: "16px", bottom: "16px", width: "104px", height: "104px" }
      }
    };
  }

  window.cobrinhaGetDefaultWindowLayout = defaultWindowLayout;

  window.addEventListener("cobrinha-apply-default-panel-layout", function (event) {
    var name = event.detail && event.detail.name;
    var defaults = defaultWindowLayout();
    var placement = defaults.panels && defaults.panels[name];
    if (!placement) return;
    var saved = panelState(name);
    ["left", "top", "width", "height"].forEach(function (property) {
      saved[property] = placement[property];
    });
    clearTimeout(saveTimer);
    persistStateNow();
  });

  function resetWindowLayout() {
    clearTimeout(saveTimer);
    var defaults = defaultWindowLayout();
    state = defaults.panels;
    Object.keys(resizeObservers).forEach(function (name) {
      resizeObservers[name].observer.disconnect();
    });
    resizeObservers = {};
    try {
      if (window.CobrinhaInterfaceState) {
        window.CobrinhaInterfaceState.setPanels(state);
        window.CobrinhaInterfaceState.setStudio({});
      } else localStorage.setItem(STATE_KEY, JSON.stringify(state));
      localStorage.setItem(GAP_KEY, "1");
      localStorage.setItem("cobrinhaGraphVisible", "1");
      localStorage.removeItem("cobrinhaInterfaceStudioV1");
      localStorage.removeItem("cobrinhaInterfaceProfile");
      localStorage.removeItem("cobrinhaInterfaceCustomProfileV1");
      localStorage.setItem("infobox", JSON.stringify(defaults.infobox));
    } catch (error) {}
    location.reload();
  }

  function createLayoutResetControl() {
    if (!document.body || document.getElementById("cobrinha-layout-gear")) return;

    var gear = document.createElement("button");
    gear.id = "cobrinha-layout-gear";
    gear.type = "button";
    gear.textContent = "⚙";
    gear.title = "Ajustar janelas";
    gear.setAttribute("aria-label", gear.title);
    gear.setAttribute("aria-controls", "cobrinha-layout-popup");
    gear.setAttribute("aria-expanded", "false");

    var popup = document.createElement("section");
    popup.id = "cobrinha-layout-popup";
    popup.hidden = true;
    popup.tabIndex = -1;
    popup.setAttribute("role", "dialog");
    popup.setAttribute("aria-label", "Configurações da interface");

    var title = document.createElement("strong");
    title.className = "cobrinha-layout-title";
    title.textContent = "Configurações";
    var description = document.createElement("p");
    description.className = "cobrinha-layout-description";
    description.textContent = "Personalize a interface sem sair do jogo.";

    function createSection(label) {
      var section = document.createElement("div");
      section.className = "cobrinha-layout-section";
      var heading = document.createElement("strong");
      heading.className = "cobrinha-layout-section-title";
      heading.textContent = label;
      section.appendChild(heading);
      return section;
    }

    var appearanceSection = createSection("Aparência");

    var boxMode = document.createElement("label");
    boxMode.className = "cobrinha-layout-team-mode";
    var boxModeText = document.createElement("span");
    boxModeText.textContent = "Visual geral";
    var boxModeSelect = document.createElement("select");
    var standardBoxOption = document.createElement("option");
    standardBoxOption.value = "standard";
    standardBoxOption.textContent = "Padrão";
    var minimalBoxOption = document.createElement("option");
    minimalBoxOption.value = "minimal";
    minimalBoxOption.textContent = "Minimalista";
    boxModeSelect.appendChild(standardBoxOption);
    boxModeSelect.appendChild(minimalBoxOption);
    boxModeSelect.value = currentBoxVisualMode();
    boxMode.appendChild(boxModeText);
    boxMode.appendChild(boxModeSelect);

    var teamMode = document.createElement("label");
    teamMode.className = "cobrinha-layout-team-mode";
    var teamModeText = document.createElement("span");
    teamModeText.textContent = "Detalhes da sala";
    var teamModeSelect = document.createElement("select");
    var fullOption = document.createElement("option");
    fullOption.value = "full";
    fullOption.textContent = "Completos";
    var minimalOption = document.createElement("option");
    minimalOption.value = "minimal";
    minimalOption.textContent = "Compactos";
    teamModeSelect.appendChild(fullOption);
    teamModeSelect.appendChild(minimalOption);
    teamModeSelect.value = currentTeamPanelMode();
    teamMode.appendChild(teamModeText);
    teamMode.appendChild(teamModeSelect);

    var minimalBackground = document.createElement("div");
    minimalBackground.className = "cobrinha-layout-background";
    var backgroundToggleLabel = document.createElement("label");
    backgroundToggleLabel.className = "cobrinha-layout-background-toggle";
    var backgroundToggle = document.createElement("input");
    backgroundToggle.type = "checkbox";
    var backgroundToggleText = document.createElement("span");
    backgroundToggleText.textContent = "Fundo dos painéis minimalistas";
    backgroundToggleLabel.appendChild(backgroundToggle);
    backgroundToggleLabel.appendChild(backgroundToggleText);
    var backgroundControls = document.createElement("div");
    backgroundControls.className = "cobrinha-layout-background-controls";
    var colorLabel = document.createElement("label");
    colorLabel.textContent = "Cor";
    var colorInput = document.createElement("input");
    colorInput.type = "color";
    colorLabel.appendChild(colorInput);
    var opacityLabel = document.createElement("label");
    opacityLabel.className = "cobrinha-layout-background-opacity";
    var opacityText = document.createElement("span");
    opacityText.textContent = "Opacidade";
    var opacityNumber = document.createElement("input");
    opacityNumber.type = "number";
    opacityNumber.min = "0";
    opacityNumber.max = "100";
    opacityNumber.step = "1";
    opacityNumber.inputMode = "numeric";
    opacityNumber.setAttribute("aria-label", "Opacidade do fundo em porcentagem");
    var opacityInput = document.createElement("input");
    opacityInput.type = "range";
    opacityInput.min = "0";
    opacityInput.max = "100";
    opacityInput.step = "1";
    opacityLabel.appendChild(opacityText);
    opacityLabel.appendChild(opacityNumber);
    opacityLabel.appendChild(opacityInput);
    backgroundControls.appendChild(colorLabel);
    backgroundControls.appendChild(opacityLabel);
    minimalBackground.appendChild(backgroundToggleLabel);
    minimalBackground.appendChild(backgroundControls);

    var savedBackground = minimalBackgroundSettings();
    backgroundToggle.checked = savedBackground.enabled;
    colorInput.value = savedBackground.color;
    opacityInput.value = String(Math.round(savedBackground.opacity * 100));
    opacityNumber.value = opacityInput.value;
    backgroundControls.classList.toggle("is-disabled", !savedBackground.enabled);

    var technicalHud = document.createElement("div");
    technicalHud.className = "cobrinha-layout-tech";
    var technicalTitle = document.createElement("strong");
    technicalTitle.textContent = "Texto de desempenho";
    technicalHud.appendChild(technicalTitle);
    var savedTechnical = technicalHudSettings();

    function createTechnicalControl(labelText, min, max, value, suffix, idPrefix) {
      var label = document.createElement("label");
      var text = document.createElement("span");
      text.textContent = labelText;
      var number = document.createElement("input");
      number.type = "number";
      number.min = String(min);
      number.max = String(max);
      number.step = "1";
      number.value = String(value);
      number.title = suffix;
      number.id = idPrefix + "-number";
      var range = document.createElement("input");
      range.type = "range";
      range.min = String(min);
      range.max = String(max);
      range.step = "1";
      range.value = String(value);
      range.id = idPrefix + "-range";
      label.appendChild(text);
      label.appendChild(number);
      label.appendChild(range);
      technicalHud.appendChild(label);
      return { number: number, range: range };
    }

    var technicalOpacity = createTechnicalControl("Opacidade (%)", 0, 100, Math.round(savedTechnical.opacity * 100), "%", "cobrinha-tech-opacity");
    var technicalSize = createTechnicalControl("Tamanho (px)", 8, 24, savedTechnical.size, "px", "cobrinha-tech-size");

    var updateChannel = document.createElement("label");
    updateChannel.className = "cobrinha-layout-team-mode";
    var updateChannelText = document.createElement("span");
    updateChannelText.textContent = "Canal de atualizações";
    var updateChannelSelect = document.createElement("select");
    [["stable", "Estável"], ["beta", "Beta — testar antes"]].forEach(function (entry) {
      var option = document.createElement("option");
      option.value = entry[0];
      option.textContent = entry[1];
      updateChannelSelect.appendChild(option);
    });
    updateChannelSelect.value = localStorage.getItem("cobrinhaUpdateChannelV1") === "beta" ? "beta" : "stable";
    updateChannel.appendChild(updateChannelText);
    updateChannel.appendChild(updateChannelSelect);

    var reliabilityActions = document.createElement("div");
    reliabilityActions.className = "cobrinha-runtime-actions";
    var diagnosticButton = document.createElement("button");
    diagnosticButton.type = "button";
    diagnosticButton.className = "cobrinha-runtime-action";
    diagnosticButton.textContent = "Copiar diagnóstico";
    var sendDiagnosticButton = document.createElement("button");
    sendDiagnosticButton.type = "button";
    sendDiagnosticButton.className = "cobrinha-runtime-action";
    sendDiagnosticButton.textContent = "Enviar diagnóstico";
    var safeModeButton = document.createElement("button");
    safeModeButton.type = "button";
    safeModeButton.className = "cobrinha-runtime-action";
    safeModeButton.textContent = "Reiniciar em modo seguro";
    reliabilityActions.appendChild(diagnosticButton);
    reliabilityActions.appendChild(sendDiagnosticButton);
    reliabilityActions.appendChild(safeModeButton);

    var identityActions = document.createElement("div");
    identityActions.className = "cobrinha-runtime-actions cobrinha-identity-actions";
    var copyFriendInviteButton = document.createElement("button");
    copyFriendInviteButton.type = "button";
    copyFriendInviteButton.className = "cobrinha-runtime-action";
    copyFriendInviteButton.textContent = "Copiar meu convite de amigo";
    var addFriendInviteButton = document.createElement("button");
    addFriendInviteButton.type = "button";
    addFriendInviteButton.className = "cobrinha-runtime-action";
    addFriendInviteButton.textContent = "Adicionar amigo por convite";
    var manageFriendsButton = document.createElement("button");
    manageFriendsButton.type = "button";
    manageFriendsButton.className = "cobrinha-runtime-action";
    manageFriendsButton.textContent = "Central de amigos";
    var revokeInviteButton = document.createElement("button");
    revokeInviteButton.type = "button";
    revokeInviteButton.className = "cobrinha-runtime-action";
    revokeInviteButton.textContent = "Revogar convite atual";
    var exportIdentityButton = document.createElement("button");
    exportIdentityButton.type = "button";
    exportIdentityButton.className = "cobrinha-runtime-action";
    exportIdentityButton.textContent = "Exportar identidade";
    var importIdentityButton = document.createElement("button");
    importIdentityButton.type = "button";
    importIdentityButton.className = "cobrinha-runtime-action";
    importIdentityButton.textContent = "Importar identidade";
    var identityFileInput = document.createElement("input");
    identityFileInput.type = "file";
    identityFileInput.accept = ".json,application/json";
    identityFileInput.hidden = true;
    identityActions.appendChild(copyFriendInviteButton);
    identityActions.appendChild(addFriendInviteButton);
    identityActions.appendChild(manageFriendsButton);
    identityActions.appendChild(revokeInviteButton);
    identityActions.appendChild(exportIdentityButton);
    identityActions.appendChild(importIdentityButton);
    identityActions.appendChild(identityFileInput);

    var reset = document.createElement("button");
    reset.type = "button";
    reset.className = "cobrinha-layout-reset";
    reset.textContent = "Redefinir janelas";

    var confirmation = document.createElement("div");
    confirmation.className = "cobrinha-layout-confirmation";
    confirmation.hidden = true;
    var question = document.createElement("span");
    question.textContent = "Confirmar redefinição?";
    var actions = document.createElement("div");
    var cancel = document.createElement("button");
    cancel.type = "button";
    cancel.textContent = "Cancelar";
    var confirm = document.createElement("button");
    confirm.type = "button";
    confirm.className = "is-confirm";
    confirm.textContent = "Confirmar";
    actions.appendChild(cancel);
    actions.appendChild(confirm);
    confirmation.appendChild(question);
    confirmation.appendChild(actions);

    popup.appendChild(title);
    popup.appendChild(description);
    appearanceSection.appendChild(boxMode);
    appearanceSection.appendChild(teamMode);
    appearanceSection.appendChild(minimalBackground);
    appearanceSection.appendChild(technicalHud);
    popup.appendChild(appearanceSection);

    var interfaceSection = createSection("Organização");
    var interfaceActions = document.createElement("div");
    interfaceActions.id = "cobrinha-layout-interface-actions";
    interfaceActions.className = "cobrinha-layout-button-stack";
    interfaceActions.appendChild(reset);
    interfaceSection.appendChild(interfaceActions);
    interfaceSection.appendChild(confirmation);
    popup.appendChild(interfaceSection);

    var updatesSection = createSection("Atualizações");
    updatesSection.appendChild(updateChannel);
    popup.appendChild(updatesSection);

    var maintenance = document.createElement("details");
    maintenance.className = "cobrinha-layout-maintenance";
    var maintenanceSummary = document.createElement("summary");
    maintenanceSummary.textContent = "Ajuda e recuperação";
    var maintenanceHelp = document.createElement("p");
    maintenanceHelp.textContent = "Use estas opções somente para suporte ou para recomeçar.";
    var maintenanceActions = document.createElement("div");
    maintenanceActions.id = "cobrinha-layout-maintenance-actions";
    maintenanceActions.appendChild(identityActions);
    maintenanceActions.appendChild(reliabilityActions);
    maintenance.appendChild(maintenanceSummary);
    maintenance.appendChild(maintenanceHelp);
    maintenance.appendChild(maintenanceActions);
    popup.appendChild(maintenance);
    var friendDialog = document.createElement("dialog");
    friendDialog.id = "cobrinha-friend-center";
    friendDialog.className = "cobrinha-friend-center";
    var friendDialogHeader = document.createElement("header");
    var friendDialogTitle = document.createElement("strong");
    friendDialogTitle.textContent = "Central de amigos";
    var friendDialogClose = document.createElement("button");
    friendDialogClose.type = "button";
    friendDialogClose.textContent = "×";
    friendDialogClose.setAttribute("aria-label", "Fechar central de amigos");
    friendDialogHeader.appendChild(friendDialogTitle);
    friendDialogHeader.appendChild(friendDialogClose);
    var friendInvitePreview = document.createElement("section");
    friendInvitePreview.className = "cobrinha-friend-invite-preview";
    var friendList = document.createElement("section");
    friendList.className = "cobrinha-friend-list";
    friendDialog.appendChild(friendDialogHeader);
    friendDialog.appendChild(friendInvitePreview);
    friendDialog.appendChild(friendList);
    document.body.appendChild(friendDialog);
    document.body.appendChild(popup);
    document.body.appendChild(gear);

    function setPopupOpen(open) {
      popup.hidden = !open;
      gear.setAttribute("aria-expanded", open ? "true" : "false");
      if (open) popup.focus({ preventScroll: true });
      else {
        confirmation.hidden = true;
        reset.hidden = false;
      }
    }

    gear.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      boxModeSelect.value = currentBoxVisualMode();
      teamModeSelect.value = currentTeamPanelMode();
      updateChannelSelect.value = localStorage.getItem("cobrinhaUpdateChannelV1") === "beta" ? "beta" : "stable";
      savedBackground = minimalBackgroundSettings();
      backgroundToggle.checked = savedBackground.enabled;
      colorInput.value = savedBackground.color;
      opacityInput.value = String(Math.round(savedBackground.opacity * 100));
      opacityNumber.value = opacityInput.value;
      backgroundControls.classList.toggle("is-disabled", !savedBackground.enabled);
      setPopupOpen(popup.hidden);
      confirmation.hidden = true;
      reset.hidden = false;
    });
    popup.addEventListener("click", function (event) { event.stopPropagation(); });
    boxModeSelect.addEventListener("change", function () {
      try { localStorage.setItem(BOX_MODE_KEY, boxModeSelect.value === "minimal" ? "minimal" : "standard"); } catch (error) {}
      applyBoxVisualMode();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    });
    teamModeSelect.addEventListener("change", function () {
      try { localStorage.setItem(TEAM_MODE_KEY, teamModeSelect.value === "minimal" ? "minimal" : "full"); } catch (error) {}
      applyTeamPanelMode();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    });
    updateChannelSelect.addEventListener("change", function () {
      localStorage.setItem("cobrinhaUpdateChannelV1", updateChannelSelect.value === "beta" ? "beta" : "stable");
      window.dispatchEvent(new CustomEvent("cobrinha-update-channel-changed"));
    });
    diagnosticButton.addEventListener("click", function () {
      if (!window.CobrinhaDiagnostics) return;
      window.CobrinhaDiagnostics.copy().then(function () {
        diagnosticButton.textContent = "Diagnóstico copiado ✓";
        setTimeout(function () { diagnosticButton.textContent = "Copiar diagnóstico"; }, 1800);
      });
    });
    sendDiagnosticButton.addEventListener("click", function () {
      if (!window.CobrinhaDiagnostics || typeof window.CobrinhaDiagnostics.send !== "function") return;
      var approved = window.confirm(
        "Enviar um diagnóstico técnico para a Cobrinha Encasquetada?\n\n" +
        "Ele inclui versão, estado dos módulos, tamanho da tela e erros recentes. " +
        "Não inclui apelido, sala, mensagens, chave do dispositivo ou endereço do servidor."
      );
      if (!approved) return;
      sendDiagnosticButton.disabled = true;
      sendDiagnosticButton.textContent = "Enviando…";
      window.CobrinhaDiagnostics.send().then(function () {
        sendDiagnosticButton.textContent = "Diagnóstico enviado ✓";
      }).catch(function () {
        sendDiagnosticButton.textContent = "Falha ao enviar — tentar novamente";
      }).finally(function () {
        sendDiagnosticButton.disabled = false;
        setTimeout(function () { sendDiagnosticButton.textContent = "Enviar diagnóstico"; }, 3000);
      });
    });

    function showInvitePreview(invite) {
      friendInvitePreview.textContent = "";
      if (!invite || !invite.code) return;
      var heading = document.createElement("strong");
      heading.textContent = "Convite válido por 24 horas e para um único uso";
      var qr = document.createElement("div");
      qr.className = "cobrinha-friend-qr";
      if (typeof window.qrcode === "function") {
        try {
          var generator = window.qrcode(0, "L");
          generator.addData(invite.code);
          generator.make();
          qr.innerHTML = generator.createSvgTag({ cellSize: 5, margin: 2, scalable: true });
        } catch (error) { qr.textContent = "QR indisponível"; }
      }
      var code = document.createElement("code");
      code.textContent = invite.code;
      friendInvitePreview.appendChild(heading);
      friendInvitePreview.appendChild(qr);
      friendInvitePreview.appendChild(code);
    }

    function friendAction(label, callback, danger) {
      var button = document.createElement("button");
      button.type = "button";
      button.textContent = label;
      if (danger) button.className = "is-danger";
      button.addEventListener("click", callback);
      return button;
    }

    function renderFriendCenter() {
      var api = window.cobrinhaFriendPresence;
      friendList.textContent = "";
      if (!api) return;
      showInvitePreview(typeof api.currentInvite === "function" ? api.currentInvite() : null);
      var friends = typeof api.listFriends === "function" ? api.listFriends() : [];
      var blocked = typeof api.listBlocked === "function" ? api.listBlocked() : [];
      var sectionTitle = document.createElement("strong");
      sectionTitle.textContent = "Amigos verificados (" + friends.length + ")";
      friendList.appendChild(sectionTitle);
      if (!friends.length) {
        var empty = document.createElement("p");
        empty.textContent = "Nenhum amigo adicionado ainda.";
        friendList.appendChild(empty);
      }
      friends.forEach(function (friend) {
        var key = String(friend.identityKey || friend.clientId || "");
        var row = document.createElement("div");
        row.className = "cobrinha-friend-row";
        var info = document.createElement("div");
        var name = document.createElement("strong");
        name.textContent = "✓ " + String(friend.nickname || "Amigo");
        var status = document.createElement("small");
        status.textContent = String(friend.status || "offline") + " · " + key.slice(-8);
        info.appendChild(name);
        info.appendChild(status);
        var actions = document.createElement("div");
        actions.appendChild(friendAction("Seguir", function () { api.setFollow(key); renderFriendCenter(); }));
        actions.appendChild(friendAction("Remover", function () { api.removeFriend(key); renderFriendCenter(); }, true));
        actions.appendChild(friendAction("Bloquear", function () { api.blockFriend(key, friend.nickname); renderFriendCenter(); }, true));
        row.appendChild(info);
        row.appendChild(actions);
        friendList.appendChild(row);
      });
      if (blocked.length) {
        var blockedTitle = document.createElement("strong");
        blockedTitle.textContent = "Bloqueados (" + blocked.length + ")";
        friendList.appendChild(blockedTitle);
        blocked.forEach(function (item) {
          var row = document.createElement("div");
          row.className = "cobrinha-friend-row is-blocked";
          var label = document.createElement("span");
          label.textContent = String(item.nickname || "Jogador") + " · " + String(item.key || "").slice(-8);
          row.appendChild(label);
          row.appendChild(friendAction("Desbloquear", function () { api.unblockFriend(item.key); renderFriendCenter(); }));
          friendList.appendChild(row);
        });
      }
    }

    friendDialogClose.addEventListener("click", function () { friendDialog.close(); });
    friendDialog.addEventListener("click", function (event) {
      if (event.target === friendDialog) friendDialog.close();
    });
    manageFriendsButton.addEventListener("click", function () {
      renderFriendCenter();
      friendDialog.showModal();
    });
    copyFriendInviteButton.addEventListener("click", function () {
      var api = window.cobrinhaFriendPresence;
      if (!api || typeof api.ownInvite !== "function") return;
      copyFriendInviteButton.disabled = true;
      copyFriendInviteButton.textContent = "Criando convite…";
      api.ownInvite().then(function (invite) {
        showInvitePreview(invite);
        if (!friendDialog.open) friendDialog.showModal();
        return navigator.clipboard.writeText(invite.code).then(function () {
          copyFriendInviteButton.textContent = "Convite copiado ✓";
          setTimeout(function () { copyFriendInviteButton.textContent = "Copiar meu convite de amigo"; }, 2200);
        });
      }).catch(function (error) {
        window.alert(error && error.message ? error.message : "Não foi possível copiar o convite.");
      }).finally(function () { copyFriendInviteButton.disabled = false; });
    });
    revokeInviteButton.addEventListener("click", function () {
      var api = window.cobrinhaFriendPresence;
      if (!api || typeof api.revokeInvite !== "function") return;
      if (!window.confirm("Revogar o convite atual? Ele deixará de funcionar imediatamente.")) return;
      api.revokeInvite().then(function () {
        showInvitePreview(null);
        revokeInviteButton.textContent = "Convite revogado ✓";
        setTimeout(function () { revokeInviteButton.textContent = "Revogar convite atual"; }, 2200);
      }).catch(function (error) { window.alert(error && error.message ? error.message : "Não foi possível revogar."); });
    });
    addFriendInviteButton.addEventListener("click", function () {
      var api = window.cobrinhaFriendPresence;
      if (!api || typeof api.addByInvite !== "function") return;
      var code = window.prompt("Cole o convite criptográfico enviado pelo seu amigo:");
      if (!code) return;
      var label = window.prompt("Como você quer identificar esse amigo?", "Amigo verificado");
      addFriendInviteButton.disabled = true;
      api.addByInvite(code, label || "").then(function () {
        addFriendInviteButton.textContent = "Amigo verificado adicionado ✓";
        setTimeout(function () { addFriendInviteButton.textContent = "Adicionar amigo por convite"; }, 2500);
        renderFriendCenter();
      }).catch(function (error) {
        window.alert(error && error.message ? error.message : "Convite inválido.");
      }).finally(function () { addFriendInviteButton.disabled = false; });
    });
    exportIdentityButton.addEventListener("click", function () {
      var identityApi = window.CobrinhaDeviceIdentity;
      if (!identityApi || typeof identityApi.exportIdentity !== "function") return;
      var password = window.prompt("Crie uma senha para proteger o arquivo de identidade (mínimo 10 caracteres):");
      if (!password) return;
      var confirmationPassword = window.prompt("Digite novamente a senha do arquivo:");
      if (password !== confirmationPassword) { window.alert("As senhas não coincidem."); return; }
      identityApi.exportIdentity(password).then(function (payload) {
        var blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
        var link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "cobrinha-identidade-" + String(payload.identityHint || "dispositivo").slice(-8) + ".json";
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(function () { URL.revokeObjectURL(link.href); }, 1000);
        exportIdentityButton.textContent = "Identidade exportada ✓";
        setTimeout(function () { exportIdentityButton.textContent = "Exportar identidade"; }, 2200);
      }).catch(function (error) {
        window.alert(error && error.message ? error.message : "Não foi possível exportar a identidade.");
      });
    });
    importIdentityButton.addEventListener("click", function () { identityFileInput.click(); });
    identityFileInput.addEventListener("change", function () {
      var file = identityFileInput.files && identityFileInput.files[0];
      identityFileInput.value = "";
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () {
        var payload;
        try { payload = JSON.parse(String(reader.result || "")); }
        catch (error) { window.alert("O arquivo selecionado não contém uma identidade válida."); return; }
        if (!window.confirm("Substituir a identidade deste dispositivo?\n\nO mod será recarregado e seus amigos voltarão a reconhecer a identidade importada.")) return;
        var password = window.prompt("Digite a senha usada para proteger este arquivo:");
        if (!password) return;
        var identityApi = window.CobrinhaDeviceIdentity;
        if (!identityApi || typeof identityApi.restoreIdentity !== "function") return;
        identityApi.restoreIdentity(payload, password).then(function () { location.reload(); }).catch(function (error) {
          window.alert(error && error.message ? error.message : "Não foi possível importar a identidade.");
        });
      };
      reader.readAsText(file);
    });
    safeModeButton.addEventListener("click", function () {
      if (window.CobrinhaRuntime) window.CobrinhaRuntime.enterSafeMode();
    });
    backgroundToggle.addEventListener("change", function () {
      try { localStorage.setItem(MINIMAL_BG_ENABLED_KEY, backgroundToggle.checked ? "1" : "0"); } catch (error) {}
      backgroundControls.classList.toggle("is-disabled", !backgroundToggle.checked);
      applyMinimalBackground();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    });
    colorInput.addEventListener("input", function () {
      try { localStorage.setItem(MINIMAL_BG_COLOR_KEY, colorInput.value); } catch (error) {}
      applyMinimalBackground();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    });
    function updateBackgroundOpacity(value) {
      var percentage = Number(value);
      if (!Number.isFinite(percentage)) return;
      percentage = Math.max(0, Math.min(100, percentage));
      opacityInput.value = String(percentage);
      opacityNumber.value = String(percentage);
      try { localStorage.setItem(MINIMAL_BG_OPACITY_KEY, String(percentage / 100)); } catch (error) {}
      applyMinimalBackground();
      window.dispatchEvent(new CustomEvent("cobrinha-interface-preference-changed"));
    }
    opacityInput.addEventListener("input", function () {
      updateBackgroundOpacity(opacityInput.value);
    });
    opacityNumber.addEventListener("input", function () {
      if (opacityNumber.value !== "") updateBackgroundOpacity(opacityNumber.value);
    });
    opacityNumber.addEventListener("change", function () {
      updateBackgroundOpacity(opacityNumber.value === "" ? opacityInput.value : opacityNumber.value);
    });
    function bindTechnicalControl(control, min, max, storageKey, convert) {
      function update(value) {
        var number = Number(value);
        if (!Number.isFinite(number)) return;
        number = Math.max(min, Math.min(max, number));
        control.range.value = String(number);
        control.number.value = String(number);
        try { localStorage.setItem(storageKey, String(convert(number))); } catch (error) {}
        applyTechnicalHud();
        window.dispatchEvent(new CustomEvent("cobrinha-tech-hud-changed", { detail: { opacity: technicalOpacity.number.value, size: technicalSize.number.value } }));
      }
      control.range.addEventListener("input", function () { update(control.range.value); });
      control.number.addEventListener("input", function () {
        if (control.number.value !== "") update(control.number.value);
      });
      control.number.addEventListener("change", function () {
        update(control.number.value === "" ? control.range.value : control.number.value);
      });
    }
    bindTechnicalControl(technicalOpacity, 0, 100, TECH_HUD_OPACITY_KEY, function (value) { return value / 100; });
    bindTechnicalControl(technicalSize, 8, 24, TECH_HUD_SIZE_KEY, function (value) { return value; });
    reset.addEventListener("click", function () {
      reset.hidden = true;
      confirmation.hidden = false;
    });
    cancel.addEventListener("click", function () {
      confirmation.hidden = true;
      reset.hidden = false;
    });
    confirm.addEventListener("click", resetWindowLayout);
    document.addEventListener("keydown", function (event) {
      if (event.key !== "Escape" || popup.hidden) return;
      event.preventDefault();
      setPopupOpen(false);
      gear.focus({ preventScroll: true });
    });
    document.addEventListener("click", function () {
      setPopupOpen(false);
    });
  }

  function updateLayoutResetVisibility() {
    createLayoutResetControl();
    var gear = document.getElementById("cobrinha-layout-gear");
    var popup = document.getElementById("cobrinha-layout-popup");
    var login = document.getElementById("login");
    if (!gear) return;
    var visible = false;
    if (login) {
      var style = getComputedStyle(login);
      var rect = login.getBoundingClientRect();
      visible = style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0.05 && rect.width > 0 && rect.height > 0;
    }
    gear.hidden = !visible;
    if (!visible && popup) popup.hidden = true;
  }

  new MutationObserver(function (changes) {
    var relevant = changes.some(function (change) {
      return change.target && (change.target.id === "eemenu" || change.target.id === "bchat" || change.target.id === "lovable-team-panel") ||
        Array.prototype.some.call(change.addedNodes || [], function (node) {
          return node.nodeType === 1 && (node.id === "eemenu" || node.id === "bchat" || node.id === "lovable-team-panel" || node.querySelector && node.querySelector("#eemenu, #bchat, #lovable-team-panel"));
        });
    });
    if (relevant) setTimeout(prepareAll, 0);
  }).observe(document.documentElement, { childList: true, subtree: true });

  document.addEventListener("keydown", function (event) {
    var input = document.getElementById("ichat");
    if (input && document.activeElement === input && event.key === "Escape") {
      event.preventDefault();
      event.stopImmediatePropagation();
      releaseChatFocus();
    }
  }, true);

  document.addEventListener("pointerdown", function (event) {
    var input = document.getElementById("ichat");
    var chat = document.getElementById("bchat");
    if (input && chat && document.activeElement === input && !chat.contains(event.target)) releaseChatFocus();
  }, true);

  var attempts = 0;
  var timer = setInterval(function () {
    if (prepareAll() || ++attempts > 240) clearInterval(timer);
  }, 50);

  applyBoxVisualMode();
  applyMinimalBackground();
  applyTechnicalHud();
  updateLayoutResetVisibility();
  window.cobrinhaPanelControlsReady = true;
  if (window.CobrinhaScheduler) window.CobrinhaScheduler.every("layout-gear", updateLayoutResetVisibility, 300);
  else setInterval(updateLayoutResetVisibility, 300);
})();
