(function () {
  "use strict";
  if (window.CobrinhaDeviceIdentity) return;

  var STORAGE_KEY = "cobrinhaIdentitySecretJwkV1";
  var PUBLIC_KEY = "cobrinhaIdentityPublicJwkV1";
  var encoder = new TextEncoder();
  var current = null;

  function base64Url(bytes) {
    var binary = "";
    Array.prototype.forEach.call(new Uint8Array(bytes), function (value) { binary += String.fromCharCode(value); });
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }

  function stable(value) {
    if (Array.isArray(value)) return "[" + value.map(stable).join(",") + "]";
    if (value && typeof value === "object") {
      return "{" + Object.keys(value).filter(function (key) { return typeof value[key] !== "undefined"; }).sort().map(function (key) {
        return JSON.stringify(key) + ":" + stable(value[key]);
      }).join(",") + "}";
    }
    return JSON.stringify(value);
  }

  function publicShape(jwk) {
    return { kty: "EC", crv: "P-256", x: String(jwk.x || ""), y: String(jwk.y || "") };
  }

  function deriveClientId(publicJwk) {
    return crypto.subtle.digest("SHA-256", encoder.encode(stable(publicShape(publicJwk)))).then(function (digest) {
      return "ce1-" + base64Url(digest);
    });
  }

  function importIdentity(privateJwk, publicJwk) {
    return Promise.all([
      crypto.subtle.importKey("jwk", privateJwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]),
      crypto.subtle.importKey("jwk", publicJwk, { name: "ECDSA", namedCurve: "P-256" }, true, ["verify"]),
      deriveClientId(publicJwk)
    ]).then(function (values) {
      return { privateKey: values[0], publicKey: values[1], publicJwk: publicShape(publicJwk), clientId: values[2] };
    });
  }

  function generateIdentity() {
    return crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]).then(function (pair) {
      return Promise.all([crypto.subtle.exportKey("jwk", pair.privateKey), crypto.subtle.exportKey("jwk", pair.publicKey)]);
    }).then(function (keys) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(keys[0]));
      localStorage.setItem(PUBLIC_KEY, JSON.stringify(publicShape(keys[1])));
      return importIdentity(keys[0], keys[1]);
    });
  }

  function loadIdentity() {
    try {
      var privateJwk = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      var publicJwk = JSON.parse(localStorage.getItem(PUBLIC_KEY) || "null");
      if (privateJwk && publicJwk) return importIdentity(privateJwk, publicJwk).catch(generateIdentity);
    } catch (ignore) {}
    return generateIdentity();
  }

  function nonce() {
    if (crypto.randomUUID) return crypto.randomUUID();
    var bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return base64Url(bytes);
  }

  var ready = loadIdentity().then(function (identity) {
    current = identity;
    localStorage.setItem("cobrinhaCliente", identity.clientId);
    return { clientId: identity.clientId, publicJwk: identity.publicJwk };
  });

  function sign(payload) {
    return ready.then(function () {
      var secured = Object.assign({}, payload, {
        client_id: current.clientId,
        identity_timestamp: Date.now(),
        identity_nonce: nonce(),
        identity_public_key: current.publicJwk
      });
      var serialized = stable(secured);
      return crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, current.privateKey, encoder.encode(serialized)).then(function (signature) {
        secured.identity_signature = base64Url(signature);
        return secured;
      });
    });
  }

  window.CobrinhaDeviceIdentity = { ready: ready, sign: sign, stable: stable };
})();
