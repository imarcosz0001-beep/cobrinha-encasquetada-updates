(function () {
  "use strict";
  if (document.documentElement.dataset.cobrinhaSafeMode === "1") return;

  function inject(file, done) {
    var script = document.createElement("script");
    script.src = chrome.runtime.getURL(file);
    script.onload = function () { script.remove(); if (done) done(); };
    (document.head || document.documentElement).appendChild(script);
  }
  inject("device-identity.js", function () { inject("team-lovable.js"); });
})();
