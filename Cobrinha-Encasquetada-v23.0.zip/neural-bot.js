(function () {
  "use strict";

  var scriptUrl = document.currentScript && document.currentScript.src;
  var modelUrl = scriptUrl ? new URL("bot-model.json", scriptUrl).href : "";
  var model = null;
  var patched = false;
  var announced = false;
  var lastDecisionAt = 0;
  var lastDecision = { steer: 0, boost: false };
  var hidden = null;
  var TAU = Math.PI * 2;
  var SECTORS = 24;
  var RANGE = 1500;

  function clamp(value, min, max) {
    return value < min ? min : value > max ? max : value;
  }

  function angleDiff(from, to) {
    var value = (to - from) % TAU;
    if (value > Math.PI) value -= TAU;
    if (value < -Math.PI) value += TAU;
    return value;
  }

  function sectorFor(relativeAngle) {
    var normalized = (relativeAngle + Math.PI) / TAU;
    normalized -= Math.floor(normalized);
    return Math.min(SECTORS - 1, Math.floor(normalized * SECTORS));
  }

  function putMax(array, index, value) {
    if (value > array[index]) array[index] = value;
  }

  function observeGame() {
    var input = new Float32Array(99);
    var sx = snake.xx + (snake.fx || 0);
    var sy = snake.yy + (snake.fy || 0);
    var heading = typeof snake.N === "number" ? snake.N : snake.ang;
    var i;

    if (typeof vf === "number" && typeof Fn !== "undefined" && typeof Zn !== "undefined") {
      for (i = 0; i < vf; i++) {
        if (typeof o7 !== "undefined" && o7[i]) continue;
        var fdx = Fn[i] - sx;
        var fdy = Zn[i] - sy;
        var fd2 = fdx * fdx + fdy * fdy;
        if (fd2 > RANGE * RANGE || fd2 < 1) continue;
        var fdist = Math.sqrt(fd2);
        var fsector = sectorFor(angleDiff(heading, Math.atan2(fdy, fdx)));
        var foodValue = typeof Vn !== "undefined" && Vn[i] ? Vn[i] : 1;
        putMax(input, fsector, (1 - fdist / RANGE) * clamp(foodValue / 8, 0.15, 1));
      }
    }

    var enemies = typeof ef !== "undefined" ? ef : [];
    for (i = 0; i < enemies.length; i++) {
      var enemy = enemies[i];
      if (!enemy || enemy === snake || enemy.H || enemy.iA === 0) continue;
      var ex = enemy.xx + (enemy.fx || 0);
      var ey = enemy.yy + (enemy.fy || 0);
      var hdx = ex - sx;
      var hdy = ey - sy;
      var hd2 = hdx * hdx + hdy * hdy;
      if (hd2 <= RANGE * RANGE && hd2 > 1) {
        var hdist = Math.sqrt(hd2);
        var hsector = sectorFor(angleDiff(heading, Math.atan2(hdy, hdx)));
        var headDanger = 1 - hdist / RANGE;
        var headAt = SECTORS * 2 + hsector;
        if (headDanger > input[headAt]) {
          input[headAt] = headDanger;
          var enemyHeading = typeof enemy.N === "number" ? enemy.N : enemy.ang;
          input[SECTORS * 3 + hsector] = Math.cos(angleDiff(enemyHeading, Math.atan2(-hdy, -hdx)));
        }
      }

      var points = enemy.S || [];
      for (var p = 0; p < points.length; p++) {
        var point = points[p];
        if (!point || point.dying) continue;
        var px = point.xx + (point.fx || 0);
        var py = point.yy + (point.fy || 0);
        var bdx = px - sx;
        var bdy = py - sy;
        var bd2 = bdx * bdx + bdy * bdy;
        if (bd2 > RANGE * RANGE || bd2 < 1) continue;
        var bdist = Math.sqrt(bd2);
        var bsector = sectorFor(angleDiff(heading, Math.atan2(bdy, bdx)));
        putMax(input, SECTORS + bsector, 1 - bdist / RANGE);
      }
    }

    var center = typeof af === "number" && af > 0 ? af : 16384;
    var radius = center * 0.98;
    var relX = sx - center;
    var relY = sy - center;
    var radiusSquared = radius * radius;
    for (i = 0; i < SECTORS; i++) {
      var relative = (i + 0.5) / SECTORS * TAU - Math.PI;
      var ray = heading + relative;
      var dx = Math.cos(ray);
      var dy = Math.sin(ray);
      var dot = relX * dx + relY * dy;
      var wallDistance = -dot + Math.sqrt(Math.max(0, dot * dot + radiusSquared - relX * relX - relY * relY));
      putMax(input, SECTORS + i, 1 - clamp(wallDistance / RANGE, 0, 1));
    }

    input[96] = clamp((tf.snakeLength || 0) / 1000, 0, 1);
    input[97] = clamp((snake.O || 0) / 20, 0, 1);
    input[98] = clamp(Math.sqrt(relX * relX + relY * relY) / radius, 0, 1);
    return input;
  }

  function infer(input) {
    var weights = model.weights;
    var architecture = model.architecture;
    var inputs = architecture.inputs;
    var hiddenCount = architecture.hidden;
    if (!hidden || hidden.length !== hiddenCount) hidden = new Float32Array(hiddenCount);

    for (var h = 0; h < hiddenCount; h++) {
      var sum = weights.b1[h];
      var offset = h * inputs;
      for (var i = 0; i < inputs; i++) sum += weights.w1[offset + i] * input[i];
      hidden[h] = sum > 0 ? sum : 0;
    }

    if (model.version >= 2 && Array.isArray(architecture.steering)) {
      var outputCount = architecture.outputs;
      var steeringCount = architecture.steering.length;
      var logits = new Float32Array(outputCount);
      var best = 0;
      for (var o = 0; o < outputCount; o++) {
        var value = weights.b2[o];
        var outputOffset = o * hiddenCount;
        for (h = 0; h < hiddenCount; h++) value += weights.w2[outputOffset + h] * hidden[h];
        logits[o] = value;
        if (o < steeringCount && value > logits[best]) best = o;
      }
      return {
        steer: architecture.steering[best],
        boostScore: 1 / (1 + Math.exp(-clamp(logits[steeringCount], -20, 20)))
      };
    }

    var steer = weights.b2[0];
    var boost = weights.b2[1];
    for (h = 0; h < hiddenCount; h++) {
      steer += weights.w2[h] * hidden[h];
      boost += weights.w2[hiddenCount + h] * hidden[h];
    }
    return {
      steer: Math.tanh(steer) * (model.steeringRadians || 1.1),
      boostScore: 1 / (1 + Math.exp(-clamp(boost, -20, 20)))
    };
  }

  function maximumDanger(input) {
    var danger = 0;
    for (var i = SECTORS; i < SECTORS * 3; i++) if (input[i] > danger) danger = input[i];
    return danger;
  }

  function patchBot() {
    if (patched || typeof tf === "undefined" || !tf || typeof tf.go !== "function") return;
    var originalGo = tf.go;
    tf.go = function () {
      if (!model || typeof M8 === "undefined" || !M8 || typeof snake === "undefined" || !snake || snake.H) {
        return originalGo.apply(tf, arguments);
      }
      try {
        tf.every();
        if (tf.actionTimeout) {
          clearTimeout(tf.actionTimeout);
          tf.actionTimeout = void 0;
        }

        // O escudo tradicional continua soberano. A rede só assume quando
        // não há colisão imediata ou corredor fechado detectado pelo TT.
        if (tf.Ee() || tf.Zf()) return;

        var now = performance.now();
        if (now - lastDecisionAt >= 80) {
          var input = observeGame();
          var output = infer(input);
          lastDecision = {
            steer: output.steer,
            boost: output.boostScore > 0.92 && maximumDanger(input) < 0.12 && input[98] < 0.78 && tf.snakeLength > 140
          };
          lastDecisionAt = now;
        }

        M2(lastDecision.boost ? 1 : 0);
        var heading = typeof snake.N === "number" ? snake.N : snake.ang;
        tf.ne(heading + clamp(lastDecision.steer, -1.1, 1.1));

        if (!announced) {
          announced = true;
          if (typeof R === "function" && typeof y !== "undefined") R(y, "IA treinada ativa + proteção TT");
          console.info("[COBRINHA][IA] Modelo treinado ativo com escudo anticolisão do TT.");
        }
      } catch (error) {
        console.error("[COBRINHA][IA] Falha na inferência; retornando ao bot tradicional.", error);
        return originalGo.apply(tf, arguments);
      }
    };
    patched = true;
  }

  if (modelUrl) {
    fetch(modelUrl, { cache: "no-store" })
      .then(function (response) {
        if (!response.ok) throw new Error("HTTP " + response.status);
        return response.json();
      })
      .then(function (loaded) {
        if (!loaded || !loaded.weights || !loaded.architecture || loaded.architecture.inputs !== 99) {
          throw new Error("modelo incompatível");
        }
        model = loaded;
        RANGE = loaded.range || RANGE;
        patchBot();
      })
      .catch(function (error) {
        console.error("[COBRINHA][IA] Não foi possível carregar o modelo treinado.", error);
      });
  }

  var timer = setInterval(function () {
    patchBot();
    if (patched && model) clearInterval(timer);
  }, 250);
  setTimeout(function () { clearInterval(timer); }, 30000);
})();
