(function () {
  "use strict";

  var descriptions = {
    bot: "Bot automático — liga ou desliga o piloto automático (pressione duas vezes)",
    sos: "SOS — pede ajuda aos jogadores da equipe (pressione duas vezes)",
    foodhelp: "Ajuda de comida — envia o pedido de comida (pressione duas vezes)",
    hideowndot: "Ponto da equipe — mostra ou oculta seu ponto (pressione duas vezes)",
    smartbot: "Bot inteligente — alterna a tomada automática de decisões (pressione duas vezes)",
    deathpoint: "Ponto de morte — mantém ou remove a marca da última morte (pressione duas vezes)",
    timehud: "Tempo e taxas — mostra ou oculta o painel de desempenho (pressione duas vezes)",
    scronkill: "Captura automática — tira foto em abates e mortes (pressione duas vezes)",
    tinydots: "Pontos pequenos — alterna os pontos pequenos da equipe (pressione duas vezes)",
    playerslist: "Lista de jogadores — mostra ou oculta a lista (pressione duas vezes)",
    hidemenu: "Menu lateral — alterna entre os atalhos e as informações (pressione duas vezes)",
    downloadbar: "Barra de downloads — mostra ou oculta a barra (pressione duas vezes)",
    hidechat: "Chat — mostra ou oculta a caixa de conversa (pressione duas vezes)",
    hidedtl: "Detalhes da equipe — mostra ou oculta o painel (pressione duas vezes)",
    hidevv: "Painéis — mostra ou oculta todas as caixas de informação (pressione duas vezes)",
    clearchat2: "Limpar chat — atalho alternativo para apagar as mensagens (pressione duas vezes)",
    quickchat: "Mensagens rápidas — exibe as frases configuradas em Q1–Q6 (pressione duas vezes)",
    nicksplus: "Apelidos avançados — liga ou desliga Snake Nicks+ (pressione duas vezes)",
    autonoprey: "Ignorar presas — alterna o modo automático sem presas (pressione duas vezes)",
    smallfood: "Textura da comida — percorre os estilos disponíveis (pressione duas vezes)",
    minimap: "Tamanho do mapa — alterna o tamanho do minimapa (pressione duas vezes)",
    smalltags: "Tags pequenas — reduz ou restaura as tags das cobras (pressione duas vezes)",
    graphicslevel: "Gráficos — percorre os níveis de qualidade (pressione duas vezes)",
    opensettings: "Configurações — abre o painel de configurações (pressione duas vezes)",
    asy: "Assistência — mantém a ajuda de direção ativa enquanto a tecla estiver pressionada",
    asytoggle: "Travar assistência — liga ou desliga a assistência contínua (pressione duas vezes)",
    openrtl: "Painel em tempo real — função legada removida",
    gameover0: "Renascer — inicia outra partida rapidamente (pressione duas vezes)",
    gameover9: "Sair — encerra a partida atual (pressione duas vezes)",
    autorespawn: "Renascimento automático — liga ou desliga o retorno automático (pressione duas vezes)",
    zoomout: "Escala da tela − — diminui a escala em 0,05 (pressione duas vezes)",
    zoomin: "Escala da tela + — aumenta a escala em 0,05 (pressione duas vezes)",
    rvneg: "Girar à esquerda — força o movimento circular para a esquerda",
    rvpos: "Girar à direita — força o movimento circular para a direita",
    tms: "Marcação de alvo — ativa o sistema de marcação (pressione duas vezes)",
    chat: "Escrever no chat — coloca o cursor no campo de mensagem",
    clearchat: "Limpar mensagens — apaga o conteúdo visível do chat",
    screenshot: "Capturar tela — salva uma imagem da partida",
    zoommode: "Restaurar zoom — volta o zoom ao valor configurado",
    nextskin_zin: "Aproximar — aproxima a câmera ou avança o visual no seletor",
    prevskin_zout: "Afastar — afasta a câmera ou volta o visual no seletor",
    peek: "Espiar visual/apelido — mostra informações enquanto a tecla estiver pressionada",
    enableselect: "Selecionar chat — permite selecionar textos enquanto a tecla estiver pressionada",
    minimalmode: "Modo minimalista — oculta ou restaura os painéis e indicadores da tela (pressione duas vezes)",
    commandcenter: "Central de comandos — abre os comandos em uma janela visual (pressione duas vezes)"
  };

  var minimalShortcut = { id: "minimalmode", key: "6", label: descriptions.minimalmode };
  var commandCenterShortcut = { id: "commandcenter", key: ",", label: descriptions.commandcenter };
  var fixedShortcuts = [
    { id: "fixed_targetselect", fixedKey: "YY", label: "Seleção numerada de alvo — aguarda um número de 1 a 6 para escolher o alvo" },
    { id: "fixed_graph", fixedKey: "F8", label: "Gráfico de PING e FPS — mostra ou oculta o gráfico" },
    { id: "fixed_shortcuteditor", fixedKey: "F9", label: "Editor de atalhos — abre ou fecha a tela para alterar as teclas" },
    { id: "fixed_shortcutoverview", fixedKey: "F10", label: "Lista de atalhos — abre ou fecha esta visão geral" },
    { id: "fixed_fullscreen", fixedKey: "F11", label: "Tela cheia — entra ou sai da tela cheia do navegador" },
    { id: "fixed_closepopup", fixedKey: "Esc", label: "Fechar janela — fecha a janela ou o painel aberto" },
    { id: "fixed_boost", fixedKey: "Shift / Espaço / ↑", label: "Acelerar — mantém o impulso enquanto uma dessas teclas estiver pressionada" },
    { id: "fixed_left", fixedKey: "←", label: "Virar à esquerda — mantém o comando de direção para a esquerda" },
    { id: "fixed_right", fixedKey: "→", label: "Virar à direita — mantém o comando de direção para a direita" }
  ];
  var MINIMAL_STATE_KEY = "cobrinhaMinimalMode";
  var GRAPH_STATE_KEY = "cobrinhaGraphVisible";
  var lastMinimalPress = 0;

  function translateTextNodes(root) {
    var replacements = {
      "Remap Keyboard Shortcuts": "Atalhos da Cobrinha Encasquetada",
      "Reset defaults": "Restaurar padrões",
      "Close": "Fechar",
      "Click \"Set\" then press a key. \"Clear\" disables the shortcut.": "Clique em “Alterar” e pressione a nova tecla. “Desativar” remove o atalho.",
      "Reserved keys:": "Teclas reservadas:"
    };
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    var node;
    while ((node = walker.nextNode())) {
      var trimmed = node.nodeValue.trim();
      if (replacements[trimmed]) node.nodeValue = node.nodeValue.replace(trimmed, replacements[trimmed]);
    }
  }

  function polishPanel() {
    var panel = document.getElementById("my_remapbox");
    if (!panel || panel.dataset.cobrinhaPronto === "1") return;
    panel.dataset.cobrinhaPronto = "1";
    translateTextNodes(panel);

    var title = panel.querySelector("b");
    if (title) {
      title.textContent = "Atalhos da Cobrinha Encasquetada";
      var hint = document.createElement("span");
      hint.className = "cobrinha-f9-hint";
      hint.textContent = "F9 abre e fecha";
      title.insertAdjacentElement("afterend", hint);
    }
    panel.querySelectorAll("[data-km-set]").forEach(function (button) { button.textContent = "Alterar"; });
    panel.querySelectorAll("[data-km-clr]").forEach(function (button) { button.textContent = "Desativar"; });
    panel.querySelectorAll("[data-km-def]").forEach(function (button) { button.textContent = "Padrão"; });
    var close = document.getElementById("my_km_close");
    var reset = document.getElementById("my_km_reset");
    if (close) close.textContent = "Fechar";
    if (reset) reset.textContent = "Restaurar padrões";
  }

  function prepareShortcuts() {
    if (!Array.isArray(window.ya) || typeof window.b8 !== "function") return false;
    var shortcutMapChanged = false;
    [minimalShortcut, commandCenterShortcut].forEach(function (customShortcut) {
      if (!window.ya.some(function (shortcut) { return shortcut.id === customShortcut.id; })) {
        window.ya.push(customShortcut);
      }
      if (window.G8 && typeof window.G8 === "object") window.G8[customShortcut.id] = customShortcut.key;
      if (window.N8 && typeof window.N8 === "object") window.N8[customShortcut.key] = customShortcut.id;
      if (!window.L8 || typeof window.L8 !== "object" || customShortcut.id in window.L8) return;
      var savedKey = customShortcut.key;
      try {
        var savedMap = JSON.parse(localStorage.getItem("my_keymap") || "null");
        if (savedMap && customShortcut.id in savedMap) savedKey = savedMap[customShortcut.id];
      } catch (error) {}
      window.L8[customShortcut.id] = savedKey;
      shortcutMapChanged = true;
    });
    if (shortcutMapChanged && typeof window.u7 === "function") window.u7();
    window.ya.forEach(function (shortcut) {
      if (descriptions[shortcut.id]) shortcut.label = descriptions[shortcut.id];
    });
    if (window.wv && typeof window.wv === "object") {
      window.wv.f9 = true;
      window.wv.f10 = true;
    }
    return true;
  }

  function currentKey(shortcut) {
    if (shortcut.fixedKey) return String(shortcut.fixedKey).toLowerCase();
    var value = window.L8 && window.L8[shortcut.id];
    return value == null ? "" : String(value).toLowerCase();
  }

  function compareShortcuts(left, right) {
    function sortable(shortcut) {
      var key = currentKey(shortcut);
      if (!key) return [5, 0, ""];
      if (/^\d$/.test(key)) return [0, Number(key), key];
      if (/^(\d)\1$/.test(key)) return [0, Number(key.charAt(0)), key];
      if (/^[a-z]$/.test(key)) return [1, 0, key];
      if (/^([a-z])\1$/.test(key)) return [1, 0, key.charAt(0)];
      if (/^f\d+$/.test(key)) return [2, Number(key.slice(1)), key];
      if (/^[a-z]+$/.test(key)) return [3, 0, key];
      return [4, 0, key];
    }
    var a = sortable(left);
    var b = sortable(right);
    return a[0] - b[0] || a[1] - b[1] || a[2].localeCompare(b[2], "pt-BR", { numeric: true });
  }

  function displayShortcutKey(shortcut, description) {
    if (shortcut.fixedKey) return shortcut.fixedKey;
    var value = window.L8 && window.L8[shortcut.id];
    var formatted = typeof window.T8 === "function" ? window.T8(value) : String(value || "—").toUpperCase();
    if (!/pressione duas vezes/i.test(description) || formatted === "—") return formatted;
    return formatted.length === 1 ? formatted + formatted : formatted + " ×2";
  }

  function showMinimalToast(active) {
    var old = document.getElementById("cobrinha-minimal-toast");
    if (old) old.remove();
    var toast = document.createElement("div");
    toast.id = "cobrinha-minimal-toast";
    toast.textContent = active ? "Modo minimalista ativado — pressione o atalho novamente para restaurar" : "Modo minimalista desativado";
    document.body.appendChild(toast);
    setTimeout(function () { if (toast.parentNode) toast.remove(); }, 1800);
  }

  function toggleMinimalMode() {
    var active = document.documentElement.classList.toggle("cobrinha-minimal-mode");
    try { localStorage.setItem(MINIMAL_STATE_KEY, active ? "1" : "0"); } catch (error) {}
    showMinimalToast(active);
  }

  function restoreMinimalMode() {
    var active = false;
    try { active = localStorage.getItem(MINIMAL_STATE_KEY) === "1"; } catch (error) {}
    document.documentElement.classList.toggle("cobrinha-minimal-mode", active);
  }

  function saveGraphVisibility() {
    var graph = document.getElementById("mgraph-box");
    if (!graph) return;
    var visible = graph.style.display !== "none";
    try { localStorage.setItem(GRAPH_STATE_KEY, visible ? "1" : "0"); } catch (error) {}
  }

  function restoreGraphVisibility() {
    var saved = null;
    try { saved = localStorage.getItem(GRAPH_STATE_KEY); } catch (error) {}
    if (saved !== "0" && saved !== "1") return false;
    var graph = document.getElementById("mgraph-box");
    if (!graph) return false;
    graph.style.display = saved === "1" ? "block" : "none";
    return true;
  }

  function togglePanel() {
    closeOverview();
    var open = document.getElementById("my_remapbox");
    if (open) {
      var close = document.getElementById("my_km_close");
      if (close) close.click();
      return;
    }
    if (!prepareShortcuts()) return;
    window.b8();
    polishPanel();
  }

  function closeOverview() {
    var overview = document.getElementById("cobrinha-shortcuts-overview");
    var backdrop = document.getElementById("cobrinha-shortcuts-backdrop");
    if (overview) overview.remove();
    if (backdrop) backdrop.remove();
  }

  function toggleOverview() {
    if (document.getElementById("cobrinha-shortcuts-overview")) {
      closeOverview();
      return;
    }
    if (!prepareShortcuts()) return;
    var editorClose = document.getElementById("my_km_close");
    if (editorClose) editorClose.click();

    var backdrop = document.createElement("div");
    backdrop.id = "cobrinha-shortcuts-backdrop";
    backdrop.addEventListener("click", closeOverview);

    var panel = document.createElement("section");
    panel.id = "cobrinha-shortcuts-overview";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "Lista de atalhos");

    var header = document.createElement("header");
    var heading = document.createElement("div");
    var title = document.createElement("strong");
    title.textContent = "Todos os atalhos";
    var subtitle = document.createElement("span");
    subtitle.textContent = "F10 fecha  •  F9 permite editar";
    heading.appendChild(title);
    heading.appendChild(subtitle);
    var close = document.createElement("button");
    close.type = "button";
    close.textContent = "×";
    close.title = "Fechar";
    close.addEventListener("click", closeOverview);
    header.appendChild(heading);
    header.appendChild(close);

    var grid = document.createElement("div");
    grid.className = "cobrinha-shortcuts-grid";
    window.ya.concat(fixedShortcuts).sort(compareShortcuts).forEach(function (shortcut) {
      var description = descriptions[shortcut.id] || shortcut.label || shortcut.id;
      var separator = description.indexOf(" — ");
      var name = separator >= 0 ? description.slice(0, separator) : description;
      var detail = separator >= 0 ? description.slice(separator + 3) : "";
      detail = detail.replace(/\s*\(pressione duas vezes\)$/i, " — 2×");
      detail = detail.replace(/\s*enquanto a tecla estiver pressionada$/i, " — segure");

      var item = document.createElement("div");
      item.className = "cobrinha-shortcut-item";
      var key = document.createElement("kbd");
      key.textContent = displayShortcutKey(shortcut, description);
      var text = document.createElement("div");
      var itemTitle = document.createElement("b");
      itemTitle.textContent = name;
      var itemDetail = document.createElement("small");
      itemDetail.textContent = detail;
      text.appendChild(itemTitle);
      if (detail) text.appendChild(itemDetail);
      item.appendChild(key);
      item.appendChild(text);
      grid.appendChild(item);
    });

    panel.appendChild(header);
    panel.appendChild(grid);
    document.body.appendChild(backdrop);
    document.body.appendChild(panel);
  }

  document.addEventListener("keydown", function (event) {
    var target = event.target;
    var typing = target && (/^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName) || target.isContentEditable);
    var key = String(event.key || "").toLowerCase();
    if (typing) return;
    if (key === "f8") setTimeout(saveGraphVisibility, 0);
    if (!event.repeat && prepareShortcuts() && key && key === currentKey(minimalShortcut)) {
      var now = Date.now();
      if (now - lastMinimalPress <= 450) {
        lastMinimalPress = 0;
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        toggleMinimalMode();
        return;
      }
      lastMinimalPress = now;
    }
    if (key === "escape" && document.getElementById("cobrinha-shortcuts-overview")) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      closeOverview();
      return;
    }
    if (key !== "f9" && key !== "f10") return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    if (!event.repeat) {
      if (key === "f9") togglePanel();
      else toggleOverview();
    }
  }, true);

  new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      mutation.addedNodes.forEach(function (node) {
        if (node.nodeType === 1 && (node.id === "my_remapbox" || node.querySelector && node.querySelector("#my_remapbox"))) {
          setTimeout(polishPanel, 0);
        }
      });
    });
  }).observe(document.documentElement, { childList: true, subtree: true });

  var attempts = 0;
  var timer = setInterval(function () {
    if (prepareShortcuts() || ++attempts > 200) clearInterval(timer);
  }, 50);

  restoreMinimalMode();
  var graphAttempts = 0;
  var graphTimer = setInterval(function () {
    if (restoreGraphVisibility() || ++graphAttempts > 200) clearInterval(graphTimer);
  }, 50);
})();
