(function () {
  "use strict";
  var script = document.createElement("script");
  script.src = chrome.runtime.getURL("neural-bot.js");
  script.onload = function () { script.remove(); };
  (document.head || document.documentElement).appendChild(script);
})();
