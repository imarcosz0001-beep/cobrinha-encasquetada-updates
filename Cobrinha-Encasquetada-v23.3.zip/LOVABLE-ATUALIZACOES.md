# Atualizações da Cobrinha Encasquetada

O Lovable não participa mais da distribuição de atualizações. A rota `team-api` rejeita tanto
`get_addon_update` quanto `publish_addon_update`, e a tabela histórica `addon_updates` não permite
acesso anônimo.

O addon consulta somente o manifesto versionado:

`imarcosz0001-beep/cobrinha-encasquetada-updates/addon-update.json`

O `download_url` precisa apontar para um ZIP do mesmo repositório em uma URL imutável com o SHA do
commit. URLs de outros domínios, branches mutáveis e pacotes sem SHA-256 são bloqueados pelo service
worker.

## Segurança

Somente quem possui permissão de escrita no repositório oficial consegue alterar o manifesto e os
pacotes. Não existe formulário público de publicação.

Em Chrome/Brave no Windows, um addon instalado manualmente não pode substituir a si próprio silenciosamente. O botão baixa o ZIP automaticamente; o usuário ainda precisa substituir a pasta e recarregar a extensão. Atualização totalmente automática exige distribuição pela Chrome Web Store.

Antes de liberar o download, o service worker busca o pacote pela URL imutável e confere o SHA-256. O manifesto também pode informar a versão anterior para permitir retorno manual verificado.
