(function () {
  "use strict";

  var API_URL = "https://cobrinhaencasquetada.lovable.app/api/public/team-api";
  var currentTag = null;
  var currentPassword = "";
  var busy = false;
  var lastCommandCenterPress = 0;
  var tagCache = { public_version: null, custom_version: null, tags: {} };

  // Bloqueia por completo os endpoints de tags do servidor anterior. As chamadas
  // da API própria seguem normalmente pelo fetch original.
  var originalFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    var url = typeof input === "string" ? input : (input && input.url) || "";
    if (/^https:\/\/ntl-slither\.com\/tags\/authorizetags\.php/i.test(url)) {
      var used = [];
      try { used = JSON.parse(init && init.body || "[]"); } catch (ignore) {}
      return Promise.resolve(new Response(JSON.stringify(used.map(function () { return 0; })), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      }));
    }
    if (/^https:\/\/ntl-slither\.com\/tags\/(?:fstags|cstags)/i.test(url)) {
      return Promise.resolve(new Response(JSON.stringify({ v: 0, d: [] }), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      }));
    }
    return originalFetch(input, init);
  };

  // Remove uma eventual sessão criada por versões anteriores da integração.
  // A tag e a senha ficam somente em memória enquanto a página estiver aberta.
  try { sessionStorage.removeItem("cobrinhaTagSessao"); } catch (ignore) {}

  function cacheRequest(action, data) {
    return new Promise(function (resolve, reject) {
      var id = "tag-cache-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
      var timeout = setTimeout(function () {
        window.removeEventListener("message", receive);
        reject(new Error("A área de cache da extensão não respondeu."));
      }, 3000);
      function receive(event) {
        if (event.source !== window) return;
        var response = event.data && event.data.cobrinhaTagCacheResponse;
        if (!response || response.id !== id) return;
        clearTimeout(timeout);
        window.removeEventListener("message", receive);
        if (response.ok) resolve(response.data);
        else reject(new Error(response.error || "Não foi possível acessar o cache."));
      }
      window.addEventListener("message", receive);
      window.postMessage({ cobrinhaTagCacheRequest: { id: id, action: action, data: data } }, "*");
    });
  }

  var cacheLoadPromise = cacheRequest("get").then(function (saved) {
    if (saved && typeof saved === "object" && saved.tags && typeof saved.tags === "object") {
      tagCache = {
        public_version: numberOr(saved.public_version, null),
        custom_version: numberOr(saved.custom_version, null),
        tags: saved.tags
      };
    }
    return tagCache;
  }).catch(function () { return tagCache; });

  function persistCache() {
    return cacheRequest("set", tagCache).catch(function () {
      // Falha de cache não deve impedir o uso normal pelo servidor.
    });
  }

  function putCachedTag(raw) {
    var tag = normalizeTag(raw);
    if (tag.tag_id && tag.image_data) tagCache.tags[tag.tag_id] = tag;
    return persistCache().then(function () { return tag; });
  }

  function errorText(data, fallback) {
    if (!data) return fallback;
    if (typeof data.error === "string") return data.error;
    if (typeof data.message === "string") return data.message;
    if (data.error && typeof data.error.message === "string") return data.error.message;
    if (Array.isArray(data.issues)) {
      return data.issues.map(function (issue) { return issue.message; }).join("; ");
    }
    return fallback;
  }

  function post(payload) {
    var controller = new AbortController();
    var timeout = setTimeout(function () { controller.abort(); }, 12000);
    return fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (data) {
        if (!response.ok || data.ok === false) {
          throw new Error(errorText(data, "A API de tags recusou a solicitação (HTTP " + response.status + ")."));
        }
        return data;
      });
    }).finally(function () {
      clearTimeout(timeout);
    });
  }

  function say(message) {
    var text = "# " + String(message || "");
    try {
      document.dispatchEvent(new CustomEvent("cobrinha:command-message", {
        detail: { text: String(message || ""), error: /^Erro:/i.test(String(message || "")) }
      }));
    } catch (ignore) {}
    try {
      if (typeof window.R === "function" && window.y) {
        window.R(window.y, text);
        return;
      }
    } catch (ignore) {}
    console.log("[Cobrinha Encasquetada]", text);
  }

  function normalizeImage(value) {
    var image = String(value || "").trim();
    if (/^data:image\//i.test(image) || /^blob:/i.test(image) || /^https?:/i.test(image)) return image;
    return "data:image/webp;base64," + image;
  }

  function numberOr(value, fallback) {
    var number = Number(value);
    return Number.isFinite(number) ? number : fallback;
  }

  function normalizeTag(raw) {
    var tag = raw && raw.tag ? raw.tag : raw;
    if (!tag || typeof tag !== "object") throw new Error("A API não retornou os dados da tag.");
    return {
      tag_id: String(tag.tag_id || tag.id || ""),
      name: String(tag.name || tag.tag_id || "Tag personalizada"),
      width: numberOr(tag.width, 240),
      height: numberOr(tag.height, 240),
      color_1: String(tag.color_1 || "#000000"),
      color_2: String(tag.color_2 || "#FFFFFF"),
      offset_x: numberOr(tag.offset_x, -20),
      offset_y: numberOr(tag.offset_y, -120),
      image_data: String(tag.image_data || tag.src || ""),
      version: numberOr(tag.version, 1),
      is_active: Boolean(tag.is_active)
    };
  }

  function applyTag(raw) {
    var tag = normalizeTag(raw);
    if (!tag.image_data) return Promise.reject(new Error("A tag não possui imagem."));
    if (!window.Of || !window.xf || !window.Cf) {
      return Promise.reject(new Error("O jogo ainda está carregando. Tente novamente em alguns segundos."));
    }

    return new Promise(function (resolve, reject) {
      var slot = 667;
      var image = new Image();
      image.onload = function () {
        try {
          var canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(tag.width));
          canvas.height = Math.max(1, Math.round(tag.height));
          var context = canvas.getContext("2d");
          context.shadowColor = "#000000";
          context.shadowBlur = 20;
          context.drawImage(image, 21, 21);

          window.Of[slot] = {
            c1: tag.color_1,
            c2: tag.color_2,
            bx: tag.offset_x,
            by: tag.offset_y,
            w: canvas.width,
            h: canvas.height
          };
          window.Cf[slot] = image;
          if (window.da) {
            window.da.id = tag.tag_id;
            window.da.w = canvas.width;
            window.da.h = canvas.height;
            window.da.c1 = tag.color_1;
            window.da.c2 = tag.color_2;
            window.da.bx = tag.offset_x;
            window.da.by = tag.offset_y;
            window.da.src = image.src;
          }

          var bitmapPromise = typeof createImageBitmap === "function"
            ? createImageBitmap(canvas)
            : Promise.resolve(canvas);
          bitmapPromise.then(function (bitmap) {
            window.xf[slot] = bitmap;
            try {
              if (window.snake) {
                window.snake.P = slot;
                if (typeof window.Ie === "function") window.Ie(window.snake, true);
              }
              window.B9 = true;
            } catch (ignore) {}
            currentTag = tag;
            resolve(tag);
          }).catch(reject);
        } catch (error) {
          reject(error);
        }
      };
      image.onerror = function () { reject(new Error("Não foi possível abrir a imagem dessa tag.")); };
      image.src = normalizeImage(tag.image_data);
    });
  }

  function getTag(id, forceServer) {
    id = String(id || "");
    return cacheLoadPromise.then(function () {
      if (!forceServer && tagCache.tags[id]) return normalizeTag(tagCache.tags[id]);
      return post({ action: "get_tag", tag_id: id }).then(normalizeTag).then(putCachedTag)
        .catch(function (error) {
          if (tagCache.tags[id]) return normalizeTag(tagCache.tags[id]);
          throw error;
        });
    });
  }

  function syncTagCache(force) {
    var serverVersions;
    return cacheLoadPromise.then(function () {
      return post({ action: "get_tag_versions" });
    }).then(function (versions) {
      serverVersions = versions;
      var changed = force ||
        Number(tagCache.public_version) !== Number(versions.public_version) ||
        Number(tagCache.custom_version) !== Number(versions.custom_version);
      if (!changed) {
        return { offline: false, updated: false, count: Object.keys(tagCache.tags).length };
      }
      return post({ action: "list_tags" }).then(function (list) {
        var listed = Array.isArray(list.tags) ? list.tags : [];
        return Promise.all(listed.map(function (item) {
          if (item && item.image_data) return normalizeTag(item);
          var id = item && (item.tag_id || item.id);
          return id ? post({ action: "get_tag", tag_id: String(id) }).then(normalizeTag) : null;
        }));
      }).then(function (tags) {
        var fresh = {};
        tags.forEach(function (tag) {
          if (tag && tag.tag_id && tag.image_data) fresh[tag.tag_id] = tag;
        });
        tagCache = {
          public_version: numberOr(serverVersions.public_version, 1),
          custom_version: numberOr(serverVersions.custom_version, 1),
          tags: fresh
        };
        return persistCache().then(function () {
          return { offline: false, updated: true, count: Object.keys(fresh).length };
        });
      });
    }).catch(function (error) {
      var count = Object.keys(tagCache.tags).length;
      if (count) return { offline: true, updated: false, count: count, error: error };
      throw error;
    });
  }

  function loadTag(args) {
    if (!args[0]) throw new Error("Use: !loadtag ID [SENHA]");
    var id = args[0];
    if (args[1]) currentPassword = args[1];
    say("Sincronizando a tag " + id + " com o servidor Cobrinha Encasquetada...");
    var syncResult;
    return syncTagCache(false).then(function (result) {
      syncResult = result;
      return getTag(id, false);
    }).then(applyTag).then(function (tag) {
      say((syncResult && syncResult.offline ? "Servidor indisponível: cópia local usada. " : "") +
        "Tag “" + tag.name + "” carregada. Use !newtag para ajustar posição e cores.");
    });
  }

  function activateTag(args) {
    if (!args[0] || !args[1]) throw new Error("Use: !tag ID SENHA");
    var id = args[0];
    currentPassword = args[1];
    return post({ action: "activate_tag", tag_id: id, password: currentPassword })
      .then(function () { return getTag(id, true); })
      .then(applyTag)
      .then(function (tag) { say("Tag “" + tag.name + "” ativada e carregada."); });
  }

  function resetPassword(args) {
    if (!args[0] || !args[1] || !args[2]) {
      throw new Error("Use: !rst ID SENHA_ATUAL NOVA_SENHA");
    }
    return post({
      action: "reset_tag_password",
      tag_id: args[0],
      current_password: args[1],
      new_password: args[2]
    }).then(function () {
      if (currentTag && currentTag.tag_id === args[0]) currentPassword = args[2];
      say("Senha da tag alterada com sucesso.");
    });
  }

  function updateCurrentTag(args) {
    if (!currentTag) throw new Error("Carregue uma tag primeiro com !loadtag ID SENHA.");
    if (args.length < 4) throw new Error("Use: !newtag COR1 COR2 X Y");
    var updated = Object.assign({}, currentTag, {
      color_1: args[0],
      color_2: args[1],
      offset_x: numberOr(args[2], currentTag.offset_x),
      offset_y: numberOr(args[3], currentTag.offset_y)
    });

    if (!currentPassword) {
      currentTag = updated;
      return applyTag(updated).then(function () {
        say("Ajuste aplicado apenas nesta sessão. Carregue com a senha para salvá-lo no Lovable.");
      });
    }

    return post({
      action: "update_tag",
      tag_id: updated.tag_id,
      password: currentPassword,
      width: updated.width,
      height: updated.height,
      color_1: updated.color_1,
      color_2: updated.color_2,
      offset_x: updated.offset_x,
      offset_y: updated.offset_y,
      image_data: updated.image_data
    }).then(function () { return getTag(updated.tag_id, true); })
      .then(applyTag)
      .then(function () { say("Tag ajustada e salva no servidor Cobrinha Encasquetada."); });
  }

  function refreshTags(clearFirst) {
    // A sincronização forçada monta uma cópia nova e só substitui a anterior
    // depois de receber todas as tags. Se o servidor cair, o cache permanece.
    return syncTagCache(true).then(function (result) {
      if (result.offline) {
        say("Servidor indisponível; mantidas " + result.count + " tag(s) do cache.");
      } else {
        say("Cache sincronizado com o Lovable: " + result.count + " tag(s), versões " +
          tagCache.public_version + "/" + tagCache.custom_version + ".");
      }
    });
  }

  function chooseImage() {
    return new Promise(function (resolve, reject) {
      var input = document.createElement("input");
      input.type = "file";
      input.accept = "image/png,image/jpeg,image/webp";
      input.style.display = "none";
      input.onchange = function () {
        var file = input.files && input.files[0];
        input.remove();
        if (!file) return reject(new Error("Nenhuma imagem foi selecionada."));
        var reader = new FileReader();
        reader.onerror = function () { reject(new Error("Não foi possível ler a imagem.")); };
        reader.onload = function () {
          var image = new Image();
          image.onerror = function () { reject(new Error("O arquivo escolhido não é uma imagem válida.")); };
          image.onload = function () {
            // O formato antigo reserva 21 px de margem em cada lado (canvas 240 px).
            var max = 198;
            var scale = Math.min(1, max / image.naturalWidth, max / image.naturalHeight);
            var width = Math.max(1, Math.round(image.naturalWidth * scale));
            var height = Math.max(1, Math.round(image.naturalHeight * scale));
            var canvas = document.createElement("canvas");
            canvas.width = width;
            canvas.height = height;
            canvas.getContext("2d").drawImage(image, 0, 0, width, height);
            resolve({
              image_data: canvas.toDataURL("image/webp", 0.9),
              width: width + 42,
              height: height + 42
            });
          };
          image.src = reader.result;
        };
        reader.readAsDataURL(file);
      };
      document.body.appendChild(input);
      input.click();
    });
  }

  function createTag(args) {
    if (!args[0] || !args[1]) throw new Error("Use: !criartag ID SENHA [NOME]");
    var id = args[0];
    var password = args[1];
    var name = args.slice(2).join(" ") || id;
    say("Escolha a imagem da nova tag...");
    return chooseImage().then(function (image) {
      var payload = {
        action: "create_tag",
        tag_id: id,
        name: name,
        width: image.width,
        height: image.height,
        color_1: "#000000",
        color_2: "#FFFFFF",
        offset_x: -20,
        offset_y: -120,
        image_data: image.image_data,
        password: password
      };
      return post(payload).then(function () { return getTag(id, true); });
    }).then(function (tag) {
      currentPassword = password;
      return applyTag(tag);
    }).then(function (tag) {
      say("Tag “" + tag.name + "” criada e carregada. Use !tag " + id + " SENHA para publicá-la.");
    });
  }

  function showHelp() {
    [
      "comandos disponíveis:",
      "!ts — mostra ou oculta o IP do servidor (não salva)",
      "!sbcx — libera as teclas C e X (salva no navegador)",
      "!timedemo — cria 10 cobras para teste de desempenho",
      "!timedemo1 — cria 10 mil comidas para teste de desempenho",
      "!ellipse — ajusta o círculo central do mapa",
      "!protocol — alterna entre os protocolos v12 e v13",
      "!history / !clearhistory — mostra ou limpa o histórico de comandos",
      "!forceupdate — atualiza a lista de tags pelo Lovable",
      "!forcecleanupdate — limpa o cache e baixa novamente pelo Lovable",
      "!loadtag ID [SENHA] — baixa e testa uma tag",
      "!newtag COR1 COR2 X Y — ajusta e salva a tag carregada",
      "!tag ID SENHA — ativa e carrega uma tag",
      "!rst ID SENHA_ATUAL NOVA_SENHA — troca a senha da tag",
      "!criartag ID SENHA [NOME] — escolhe uma imagem e cria uma tag",
      "!comandos — abre a central visual de comandos"
    ].forEach(say);
  }

  var aliases = {
    "!carregartag": "!loadtag",
    "!ativartag": "!tag",
    "!trocarsenha": "!rst",
    "!atualizartags": "!forceupdate",
    "!limpartags": "!forcecleanupdate",
    "!createtag": "!criartag",
    "!commands": "!comandos"
  };
  var handled = {
    "!help": true,
    "!loadtag": true,
    "!newtag": true,
    "!tag": true,
    "!rst": true,
    "!forceupdate": true,
    "!forcecleanupdate": true,
    "!criartag": true,
    "!comandos": true
  };

  function toggleCommandCenter() {
    document.dispatchEvent(new CustomEvent("cobrinha:toggle-command-center"));
  }

  document.addEventListener("keydown", function (event) {
    var target = event.target;
    var isTyping = target && (
      /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName) ||
      target.isContentEditable
    );
    if (isTyping) return;

    var pressed = String(event.key || "").toLowerCase();
    var commandCenterKey = String(window.L8 && window.L8.commandcenter || ",").toLowerCase();
    if (!event.repeat && commandCenterKey && pressed === commandCenterKey) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      var now = Date.now();
      if (now - lastCommandCenterPress <= 450) {
        lastCommandCenterPress = 0;
        toggleCommandCenter();
      } else {
        lastCommandCenterPress = now;
      }
      return;
    }

    // A vírgula pertencia ao painel em tempo real removido. Se o usuário mudar
    // o atalho da central, ela continua bloqueada para não reabrir o painel antigo.
    if (event.key === ",") {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      return;
    }

    // Segurar a tecla não deve simular dezenas de atalhos `..`.
    if (event.key === "." && event.repeat) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    }
  }, true);

  function runCommand(command, args) {
    if (command === "!help") return showHelp();
    if (command === "!comandos") return toggleCommandCenter();
    if (busy) throw new Error("Aguarde a operação de tag atual terminar.");
    busy = true;
    var operation;
    try {
      if (command === "!loadtag") operation = loadTag(args);
      else if (command === "!newtag") operation = updateCurrentTag(args);
      else if (command === "!tag") operation = activateTag(args);
      else if (command === "!rst") operation = resetPassword(args);
      else if (command === "!forceupdate") operation = refreshTags(false);
      else if (command === "!forcecleanupdate") operation = refreshTags(true);
      else if (command === "!criartag") operation = createTag(args);
      else operation = Promise.resolve();
    } catch (error) {
      busy = false;
      throw error;
    }
    return Promise.resolve(operation).catch(function (error) {
      var message = error && error.name === "AbortError"
        ? "O servidor Lovable demorou demais para responder."
        : (error && error.message) || "Falha desconhecida na operação de tag.";
      say("Erro: " + message);
    }).finally(function () {
      busy = false;
    });
  }

  function executeCommandText(value) {
    var input = String(value || "").replace(/\s+/g, " ").trim();
    if (!input) return Promise.reject(new Error("Digite ou escolha um comando."));
    if (input.charAt(0) !== "!") input = "!" + input;
    var parts = input.split(" ");
    var command = parts.shift().toLowerCase();
    command = aliases[command] || command;
    if (handled[command]) {
      try { return Promise.resolve(runCommand(command, parts)); }
      catch (error) { return Promise.reject(error); }
    }

    var field = document.getElementById("ichat");
    if (!field) return Promise.reject(new Error("O jogo ainda está carregando. Tente novamente em alguns segundos."));
    field.value = [command].concat(parts).join(" ");
    field.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true
    }));
    return Promise.resolve();
  }

  window.CobrinhaCommands = {
    execute: executeCommandText,
    toggle: toggleCommandCenter,
    currentTag: function () {
      return currentTag ? {
        id: currentTag.tag_id,
        name: currentTag.name,
        color1: currentTag.color_1,
        color2: currentTag.color_2,
        x: currentTag.offset_x,
        y: currentTag.offset_y
      } : null;
    }
  };

  document.addEventListener("keydown", function (event) {
    var field = event.target;
    if (!field || field.id !== "ichat") return;
    if (!(event.key === "Enter" || event.code === "NumpadEnter" || event.keyCode === 13)) return;
    var input = String(field.value || "").trim();
    if (!input || input.charAt(0) !== "!") return;
    var parts = input.split(/\s+/);
    var command = parts.shift().toLowerCase();
    command = aliases[command] || command;
    if (!handled[command]) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    field.value = "";
    try {
      var result = runCommand(command, parts);
      if (result && typeof result.catch === "function") result.catch(function (error) { say("Erro: " + error.message); });
    } catch (error) {
      say("Erro: " + error.message);
    }
  }, true);
})();
