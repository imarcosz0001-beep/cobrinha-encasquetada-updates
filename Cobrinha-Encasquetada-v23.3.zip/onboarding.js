(function () {
  "use strict";
  var KEY = "cobrinhaOnboardingV1";
  var step = 0;
  var selectedProfile = "clean";

  function menuVisible() {
    var login = document.getElementById("login");
    if (!login) return false;
    var style = getComputedStyle(login);
    var rect = login.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
  }

  function pages(modal) { return Array.prototype.slice.call(modal.querySelectorAll(".cobrinha-onboarding-page")); }

  function renderStep() {
    var modal = document.getElementById("cobrinha-onboarding");
    if (!modal) return;
    var all = pages(modal);
    step = Math.max(0, Math.min(all.length - 1, step));
    all.forEach(function (page, index) { page.hidden = index !== step; });
    modal.querySelector(".cobrinha-onboarding-progress").textContent = (step + 1) + " / " + all.length;
    modal.querySelector('[data-action="back"]').disabled = step === 0;
    modal.querySelector('[data-action="next"]').hidden = step === all.length - 1;
    modal.querySelector('[data-action="finish"]').hidden = step !== all.length - 1;
  }

  function chooseProfile(button) {
    selectedProfile = button.getAttribute("data-profile");
    button.parentNode.querySelectorAll("button").forEach(function (item) { item.classList.toggle("is-selected", item === button); });
  }

  function finish(skip) {
    var modal = document.getElementById("cobrinha-onboarding");
    if (!skip && window.cobrinhaApplyInterfaceProfile) window.cobrinhaApplyInterfaceProfile(selectedProfile);
    if (!skip && window.cobrinhaFriendPresence) {
      window.cobrinhaFriendPresence.setPrivacy({
        sharePresence: modal.querySelector('[name="presence"]').checked,
        shareServer: modal.querySelector('[name="server"]').checked,
        sharePosition: modal.querySelector('[name="position"]').checked,
        notifications: modal.querySelector('[name="notifications"]').checked
      });
    }
    localStorage.setItem(KEY, "1");
    var openEditor = !skip && modal.querySelector('[name="open-editor"]').checked;
    modal.hidden = true;
    if (openEditor && window.cobrinhaOpenInterfaceEditor) window.cobrinhaOpenInterfaceEditor();
  }

  function create() {
    if (!document.body || document.getElementById("cobrinha-onboarding")) return;
    var modal = document.createElement("section");
    modal.id = "cobrinha-onboarding";
    modal.hidden = true;
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.innerHTML = '<header><div><strong>Configuração inicial</strong><span class="cobrinha-onboarding-progress"></span></div><button type="button" data-action="skip" title="Fechar">×</button></header>' +
      '<div class="cobrinha-onboarding-page"><h2>Como você prefere jogar?</h2><p>Você poderá mudar tudo depois na engrenagem.</p><div class="cobrinha-onboarding-profiles"><button type="button" data-profile="complete">Completo<small>Todas as informações</small></button><button type="button" data-profile="clean" class="is-selected">Clean<small>Leve e organizado</small></button><button type="button" data-profile="competitive">Competitivo<small>Só o essencial</small></button></div></div>' +
      '<div class="cobrinha-onboarding-page" hidden><h2>Amigos e privacidade</h2><p>Nada é compartilhado sem sua escolha.</p><label><input type="checkbox" name="presence"> Aparecer online para amigos</label><label><input type="checkbox" name="server"> Compartilhar servidor</label><label><input type="checkbox" name="position"> Compartilhar posição para a seta</label><label><input type="checkbox" name="notifications" checked> Avisar quando um amigo entrar</label></div>' +
      '<div class="cobrinha-onboarding-page" hidden><h2>Atalhos e posicionamento</h2><p>Clique no campo e pressione uma tecla para testar se o navegador a reconhece.</p><button type="button" class="cobrinha-onboarding-keytest">Pressione uma tecla</button><span class="cobrinha-onboarding-keyresult">Nenhuma tecla testada.</span><label><input type="checkbox" name="open-editor" checked> Abrir o editor visual ao concluir</label></div>' +
      '<footer><button type="button" data-action="back">Voltar</button><button type="button" data-action="next">Avançar</button><button type="button" data-action="finish">Concluir</button></footer>';
    modal.querySelectorAll("[data-profile]").forEach(function (button) { button.addEventListener("click", function () { chooseProfile(button); }); });
    modal.querySelector('[data-action="skip"]').addEventListener("click", function () { finish(true); });
    modal.querySelector('[data-action="back"]').addEventListener("click", function () { step--; renderStep(); });
    modal.querySelector('[data-action="next"]').addEventListener("click", function () { step++; renderStep(); });
    modal.querySelector('[data-action="finish"]').addEventListener("click", function () { finish(false); });
    var keyTest = modal.querySelector(".cobrinha-onboarding-keytest");
    keyTest.addEventListener("click", function () { keyTest.focus(); keyTest.textContent = "Aguardando…"; });
    keyTest.addEventListener("keydown", function (event) {
      event.preventDefault();
      event.stopImmediatePropagation();
      var label = [event.ctrlKey ? "Ctrl" : "", event.altKey ? "Alt" : "", event.shiftKey ? "Shift" : "", event.key].filter(Boolean).join(" + ");
      modal.querySelector(".cobrinha-onboarding-keyresult").textContent = "Reconhecido: " + label;
      keyTest.textContent = "Testar outra tecla";
    }, true);
    ["pointerdown", "mousedown", "mouseup", "click", "wheel"].forEach(function (type) { modal.addEventListener(type, function (event) { event.stopPropagation(); }); });
    document.body.appendChild(modal);
    renderStep();
  }

  function open() {
    create();
    step = 0;
    var modal = document.getElementById("cobrinha-onboarding");
    modal.hidden = false;
    renderStep();
    var popup = document.getElementById("cobrinha-layout-popup");
    if (popup) popup.hidden = true;
  }

  function attachLauncher() {
    var popup = document.getElementById("cobrinha-layout-popup");
    if (!popup || popup.querySelector(".cobrinha-open-onboarding")) return;
    var button = document.createElement("button");
    button.type = "button";
    button.className = "cobrinha-open-onboarding";
    button.textContent = "Configuração inicial";
    button.addEventListener("click", open);
    var reset = popup.querySelector(".cobrinha-layout-reset");
    popup.insertBefore(button, reset || null);
  }

  create();
  attachLauncher();
  var attempts = 0;
  var timer = setInterval(function () {
    attachLauncher();
    if (localStorage.getItem(KEY) !== "1" && menuVisible()) {
      clearInterval(timer);
      setTimeout(open, 450);
    } else if (++attempts > 240) clearInterval(timer);
  }, 250);
})();

