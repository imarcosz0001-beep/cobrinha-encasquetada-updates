(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.CobrinhaLayoutUtils = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";

  function viewport(width, height, scale) {
    width = Math.max(320, Number(width) || 1280);
    height = Math.max(320, Number(height) || 720);
    scale = Math.max(0.5, Math.min(3, Number(scale) || 1));
    return { width: width, height: height, scale: scale };
  }

  function clampPosition(position, box, screen, margin) {
    margin = Math.max(0, Number(margin) || 8);
    var width = Math.max(1, Number(box && box.width) || 1);
    var height = Math.max(1, Number(box && box.height) || 1);
    var maxLeft = Math.max(margin, screen.width - width - margin);
    var maxTop = Math.max(margin, screen.height - height - margin);
    return {
      left: Math.round(Math.max(margin, Math.min(maxLeft, Number(position && position.left) || 0))),
      top: Math.round(Math.max(margin, Math.min(maxTop, Number(position && position.top) || 0)))
    };
  }

  function defaultWindowLayout(width, height) {
    var screen = viewport(width, height, 1);
    var viewportWidth = Math.max(640, screen.width);
    var viewportHeight = Math.max(600, screen.height);
    var shortcutsTop = Math.round(Math.max(84, Math.min(132, viewportHeight * 0.146)));
    var shortcutsHeight = Math.round(Math.max(170, Math.min(238, viewportHeight * 0.263)));
    var groupGap = Math.round(Math.max(34, Math.min(70, viewportHeight * 0.0775)));
    var chatTop = shortcutsTop + shortcutsHeight + groupGap;
    var chatHeight = Math.round(Math.max(190, Math.min(254, viewportHeight * 0.281)));
    var teamWidth = 195;
    var teamTop = Math.round(Math.max(150, Math.min(230, viewportHeight * 0.255)));
    return {
      panels: {
        shortcuts: { left: "0px", top: shortcutsTop + "px", width: "300px", height: shortcutsHeight + "px", opacity: 1, collapsed: false },
        chat: { left: "0px", top: chatTop + "px", width: "300px", height: chatHeight + "px", opacity: 1, collapsed: false },
        team: { left: Math.max(0, viewportWidth - teamWidth - 4) + "px", top: teamTop + "px", width: teamWidth + "px", opacity: 1, collapsed: false }
      },
      infobox: {
        eemenu: { left: "0px", top: shortcutsTop + "px", right: "", bottom: "", width: "300px", height: shortcutsHeight + "px" },
        bchat: { left: "0px", top: chatTop + "px", right: "", bottom: "", width: "300px", height: chatHeight + "px" },
        mgraph: { left: "0px", right: "", top: "", bottom: "40px", width: "545px", height: "110px" }
      },
      native: {
        minimap: { position: "fixed", left: "auto", top: "auto", right: "16px", bottom: "16px", width: "104px", height: "104px" }
      }
    };
  }

  function viewportClass(width, height) {
    if (width < 700 || height < 520) return "compact";
    if (width >= 2500) return "ultrawide";
    return "standard";
  }

  return { viewport: viewport, clampPosition: clampPosition, defaultWindowLayout: defaultWindowLayout, viewportClass: viewportClass };
});

