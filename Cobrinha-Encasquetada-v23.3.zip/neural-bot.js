(function () {
  "use strict";

  var scriptUrl = document.currentScript && document.currentScript.src;
  var modelUrl = scriptUrl ? new URL("bot-model.json", scriptUrl).href : "";
  var model = null;
  var patched = false;
  var announced = false;
  var lastDecisionAt = 0;
  var lastDecision = { steer: 0, boost: false };
  var hidden = null;
  var TAU = Math.PI * 2;
  var SECTORS = 24;
  var RANGE = 1500;
  var tacticState = null;
  var lastTacticLabel = "";
  var humanProfile = null;
  var humanState = null;
  var humanSnakeId = null;
  var gameFeastState = null;
  var gameFeastSnakeId = null;

  function clamp(value, min, max) {
    return value < min ? min : value > max ? max : value;
  }

  function angleDiff(from, to) {
    var value = (to - from) % TAU;
    if (value > Math.PI) value -= TAU;
    if (value < -Math.PI) value += TAU;
    return value;
  }

  function sectorFor(relativeAngle) {
    var normalized = (relativeAngle + Math.PI) / TAU;
    normalized -= Math.floor(normalized);
    return Math.min(SECTORS - 1, Math.floor(normalized * SECTORS));
  }

  function putMax(array, index, value) {
    if (value > array[index]) array[index] = value;
  }

  function observeGame() {
    var input = new Float32Array(99);
    var sx = snake.xx + (snake.fx || 0);
    var sy = snake.yy + (snake.fy || 0);
    var heading = typeof snake.N === "number" ? snake.N : snake.ang;
    var i;

    if (typeof vf === "number" && typeof Fn !== "undefined" && typeof Zn !== "undefined") {
      for (i = 0; i < vf; i++) {
        if (typeof o7 !== "undefined" && o7[i]) continue;
        var fdx = Fn[i] - sx;
        var fdy = Zn[i] - sy;
        var fd2 = fdx * fdx + fdy * fdy;
        if (fd2 > RANGE * RANGE || fd2 < 1) continue;
        var fdist = Math.sqrt(fd2);
        var fsector = sectorFor(angleDiff(heading, Math.atan2(fdy, fdx)));
        var foodValue = typeof Vn !== "undefined" && Vn[i] ? Vn[i] : 1;
        putMax(input, fsector, (1 - fdist / RANGE) * clamp(foodValue / 8, 0.15, 1));
      }
    }

    var enemies = typeof ef !== "undefined" ? ef : [];
    for (i = 0; i < enemies.length; i++) {
      var enemy = enemies[i];
      if (!enemy || enemy === snake || enemy.H || enemy.iA === 0) continue;
      var ex = enemy.xx + (enemy.fx || 0);
      var ey = enemy.yy + (enemy.fy || 0);
      var hdx = ex - sx;
      var hdy = ey - sy;
      var hd2 = hdx * hdx + hdy * hdy;
      if (hd2 <= RANGE * RANGE && hd2 > 1) {
        var hdist = Math.sqrt(hd2);
        var hsector = sectorFor(angleDiff(heading, Math.atan2(hdy, hdx)));
        var headDanger = 1 - hdist / RANGE;
        var headAt = SECTORS * 2 + hsector;
        if (headDanger > input[headAt]) {
          input[headAt] = headDanger;
          var enemyHeading = typeof enemy.N === "number" ? enemy.N : enemy.ang;
          input[SECTORS * 3 + hsector] = Math.cos(angleDiff(enemyHeading, Math.atan2(-hdy, -hdx)));
        }
      }

      var points = enemy.S || [];
      for (var p = 0; p < points.length; p++) {
        var point = points[p];
        if (!point || point.dying) continue;
        var px = point.xx + (point.fx || 0);
        var py = point.yy + (point.fy || 0);
        var bdx = px - sx;
        var bdy = py - sy;
        var bd2 = bdx * bdx + bdy * bdy;
        if (bd2 > RANGE * RANGE || bd2 < 1) continue;
        var bdist = Math.sqrt(bd2);
        var bsector = sectorFor(angleDiff(heading, Math.atan2(bdy, bdx)));
        putMax(input, SECTORS + bsector, 1 - bdist / RANGE);
      }
    }

    var center = typeof af === "number" && af > 0 ? af : 16384;
    var radius = center * 0.98;
    var relX = sx - center;
    var relY = sy - center;
    var radiusSquared = radius * radius;
    for (i = 0; i < SECTORS; i++) {
      var relative = (i + 0.5) / SECTORS * TAU - Math.PI;
      var ray = heading + relative;
      var dx = Math.cos(ray);
      var dy = Math.sin(ray);
      var dot = relX * dx + relY * dy;
      var wallDistance = -dot + Math.sqrt(Math.max(0, dot * dot + radiusSquared - relX * relX - relY * relY));
      putMax(input, SECTORS + i, 1 - clamp(wallDistance / RANGE, 0, 1));
    }

    input[96] = clamp((tf.snakeLength || 0) / 1000, 0, 1);
    input[97] = clamp((snake.O || 0) / 20, 0, 1);
    input[98] = clamp(Math.sqrt(relX * relX + relY * relY) / radius, 0, 1);
    return input;
  }

  function infer(input) {
    var weights = model.weights;
    var architecture = model.architecture;
    var inputs = architecture.inputs;
    var hiddenCount = architecture.hidden;
    if (!hidden || hidden.length !== hiddenCount) hidden = new Float32Array(hiddenCount);

    for (var h = 0; h < hiddenCount; h++) {
      var sum = weights.b1[h];
      var offset = h * inputs;
      for (var i = 0; i < inputs; i++) sum += weights.w1[offset + i] * input[i];
      hidden[h] = sum > 0 ? sum : 0;
    }

    if (model.version >= 2 && Array.isArray(architecture.steering)) {
      var outputCount = architecture.outputs;
      var steeringCount = architecture.steering.length;
      var logits = new Float32Array(outputCount);
      var best = 0;
      for (var o = 0; o < outputCount; o++) {
        var value = weights.b2[o];
        var outputOffset = o * hiddenCount;
        for (h = 0; h < hiddenCount; h++) value += weights.w2[outputOffset + h] * hidden[h];
        logits[o] = value;
        if (o < steeringCount && value > logits[best]) best = o;
      }
      return {
        steer: architecture.steering[best],
        boostScore: 1 / (1 + Math.exp(-clamp(logits[steeringCount], -20, 20)))
      };
    }

    var steer = weights.b2[0];
    var boost = weights.b2[1];
    for (h = 0; h < hiddenCount; h++) {
      steer += weights.w2[h] * hidden[h];
      boost += weights.w2[hiddenCount + h] * hidden[h];
    }
    return {
      steer: Math.tanh(steer) * (model.steeringRadians || 1.1),
      boostScore: 1 / (1 + Math.exp(-clamp(boost, -20, 20)))
    };
  }

  function maximumDanger(input) {
    var danger = 0;
    for (var i = SECTORS; i < SECTORS * 3; i++) if (input[i] > danger) danger = input[i];
    return danger;
  }

  function livePosition(item) {
    return { x: item.xx + (item.fx || 0), y: item.yy + (item.fy || 0) };
  }

  function gameSnakeLength(item) {
    try {
      if (typeof fpsls !== "undefined" && typeof fmlts !== "undefined") {
        return Math.max(0, 15 * (fpsls[item.sct] + item.fam / fmlts[item.sct] - 1) - 5);
      }
    } catch (error) {}
    return (item.S && item.S.length || 0) * 8;
  }

  function gameBodyPoint(point) {
    return { x: point.xx + (point.fx || 0), y: point.yy + (point.fy || 0) };
  }

  function insideGameSnake(x, y, enemy) {
    var points = enemy.S || [];
    if (points.length < 24) return false;
    var first = gameBodyPoint(points[0]);
    var last = gameBodyPoint(points[points.length - 1]);
    var radius = typeof tf.gf === "function" ? tf.gf(enemy.Pf) / 2 : 16;
    var gapX = first.x - last.x, gapY = first.y - last.y;
    var closeEnough = Math.max(130, radius * 9);
    if (gapX * gapX + gapY * gapY > closeEnough * closeEnough) return false;
    var inside = false;
    for (var i = 0, j = points.length - 1; i < points.length; j = i++) {
      var pi = gameBodyPoint(points[i]);
      var pj = gameBodyPoint(points[j]);
      if ((pi.y > y) !== (pj.y > y) && x < (pj.x - pi.x) * (y - pi.y) / ((pj.y - pi.y) || 0.00001) + pi.x) inside = !inside;
    }
    return inside;
  }

  function gameSnakeCenter(enemy) {
    var points = enemy.S || [];
    var x = 0, y = 0, count = 0;
    for (var i = 0; i < points.length; i += 2) {
      if (!points[i] || points[i].dying) continue;
      var point = gameBodyPoint(points[i]);
      x += point.x; y += point.y; count++;
    }
    return count ? { x: x / count, y: y / count } : livePosition(enemy);
  }

  function gameOrbitAim(own, heading, center, radius, direction) {
    var dx = own.x - center.x, dy = own.y - center.y;
    var distance = Math.sqrt(dx * dx + dy * dy) || 1;
    var radial = Math.atan2(dy, dx);
    var error = clamp((distance - radius) / Math.max(45, radius), -0.6, 0.6);
    return radial + direction * (Math.PI / 2 + error);
  }

  function createHumanProfile() {
    var styles = ["assassino", "assassino", "assassino", "assassino", "espreita", "espreita", "oportunista", "oportunista", "estrangulador", "estrangulador", "conservador"];
    var style = styles[Math.floor(Math.random() * styles.length)];
    var defaults = {
      assassino: [.99, .42, .98, .72, .98, .82],
      espreita: [.82, .64, .98, .48, .94, .76],
      conservador: [.28, .96, .64, .28, .86, .3],
      oportunista: [.76, .62, 1, .52, .9, .54],
      estrangulador: [.9, .66, .86, .4, .94, .48]
    }[style];
    return {
      style: style,
      aggression: clamp(defaults[0] + (Math.random() - .5) * .14, .18, 1),
      caution: clamp(defaults[1] + (Math.random() - .5) * .14, .35, 1),
      opportunism: clamp(defaults[2] + (Math.random() - .5) * .14, .4, 1),
      unpredictability: clamp(defaults[3] + (Math.random() - .5) * .14, .1, .95),
      reaction: clamp(defaults[4] + (Math.random() - .5) * .14, .45, 1),
      feint: clamp(defaults[5] + (Math.random() - .5) * .14, .12, .98)
    };
  }

  function chooseGameFeastMove() {
    if (typeof vf !== "number" || typeof Fn === "undefined" || typeof Zn === "undefined" || !snake) return null;
    var currentSnakeId = snake.id;
    if (gameFeastSnakeId !== currentSnakeId) {
      gameFeastSnakeId = currentSnakeId;
      gameFeastState = null;
    }
    var own = livePosition(snake);
    var buckets = Object.create(null);
    var range = 1850, rangeSquared = range * range, cellSize = 190;
    for (var i = 0; i < vf; i++) {
      if (typeof o7 !== "undefined" && o7[i]) continue;
      var dx = Fn[i] - own.x, dy = Zn[i] - own.y;
      var distanceSquared = dx * dx + dy * dy;
      if (distanceSquared > rangeSquared) continue;
      var value = typeof Vn !== "undefined" && Number(Vn[i]) > 0 ? Number(Vn[i]) : 1;
      var cellX = Math.floor(Fn[i] / cellSize), cellY = Math.floor(Zn[i] / cellSize);
      var key = cellX + ":" + cellY;
      var bucket = buckets[key] || (buckets[key] = { x: 0, y: 0, mass: 0, count: 0 });
      var weight = Math.max(1, value);
      bucket.x += Fn[i] * weight;
      bucket.y += Zn[i] * weight;
      bucket.mass += weight;
      bucket.count++;
    }
    var best = null, bestScore = -Infinity;
    Object.keys(buckets).forEach(function (key) {
      var bucket = buckets[key];
      if (bucket.count < 4) return;
      var x = bucket.x / bucket.mass, y = bucket.y / bucket.mass;
      var dx = x - own.x, dy = y - own.y;
      var distance = Math.sqrt(dx * dx + dy * dy);
      var score = bucket.count * 42 + bucket.mass * 38 - distance * .28;
      if (score > bestScore) { bestScore = score; best = { x: x, y: y, distance: distance, mass: bucket.mass, count: bucket.count }; }
    });
    if (!best || bestScore < 220) {
      gameFeastState = null;
      return null;
    }
    var now = performance.now();
    if (gameFeastState && now - gameFeastState.seenAt < 1200) {
      best.x = gameFeastState.x * .35 + best.x * .65;
      best.y = gameFeastState.y * .35 + best.y * .65;
    }
    best.seenAt = now;
    gameFeastState = best;
    return { mode: "corrida pela massa", aim: Math.atan2(best.y - own.y, best.x - own.x), boost: best.distance > 130 && best.distance < 1750, influence: 1 };
  }

  function chooseHumanGameMove() {
    var currentId = snake && snake.id;
    if (!humanProfile || humanSnakeId !== currentId) {
      humanSnakeId = currentId;
      humanProfile = createHumanProfile();
      humanState = { targetId: 0, flank: Math.random() < .5 ? -1 : 1, jitter: 0, nextChangeAt: 0, feintUntil: 0 };
    }

    var now = performance.now() / 1000;
    var own = livePosition(snake);
    var heading = typeof snake.N === "number" ? snake.N : snake.ang;
    var ownLength = tf.snakeLength || gameSnakeLength(snake);
    var enemies = typeof ef !== "undefined" ? ef : [];
    if (now >= humanState.nextChangeAt) {
      humanState.nextChangeAt = now + .28 + Math.random() * (1.15 - humanProfile.reaction * .55);
      humanState.jitter = (Math.random() - .5) * humanProfile.unpredictability * 1.05;
      if (Math.random() < humanProfile.unpredictability * .32) humanState.flank *= -1;
      if (Math.random() < humanProfile.feint * .22) humanState.feintUntil = now + .22 + Math.random() * .65;

      var best = null, bestScore = -Infinity;
      var style = humanProfile.style;
      var attackChance = Math.min(1, humanProfile.aggression * (style === "conservador" ? .38 : style === "espreita" ? .94 : 1.12));
      if (Math.random() <= attackChance) {
        for (var i = 0; i < enemies.length; i++) {
          var enemy = enemies[i];
          if (!enemy || enemy === snake || enemy.H || enemy.iA === 0) continue;
          var enemyPosition = livePosition(enemy);
          var dx = enemyPosition.x - own.x, dy = enemyPosition.y - own.y;
          var distance = Math.sqrt(dx * dx + dy * dy);
          if (distance > 1500 || distance < 55) continue;
          var enemyLength = gameSnakeLength(enemy);
          var sizeRatio = enemyLength / Math.max(1, ownLength);
          var huntsGiants = style === "assassino" || style === "espreita";
          if (!huntsGiants && enemyLength > ownLength * (1.15 + humanProfile.aggression * 1.55 - humanProfile.caution * .35)) continue;
          if (style === "conservador" && sizeRatio > 1.18) continue;
          var crossing = 1 - Math.abs(angleDiff(heading, Math.atan2(dy, dx))) / Math.PI;
          var vulnerable = enemyLength <= ownLength * 1.15 ? 260 : 0;
          var giantPrize = huntsGiants && sizeRatio > 1.4 ? Math.min(1200, Math.sqrt(sizeRatio) * (style === "assassino" ? 300 : 210)) : 0;
          var closingChance = enemyLength < ownLength * 1.45 && distance < 620 ? 360 * humanProfile.aggression : 0;
          var score = vulnerable + giantPrize + closingChance + crossing * 230 + (1500 - distance) * humanProfile.opportunism;
          if (score > bestScore) { bestScore = score; best = enemy; }
        }
      }
      humanState.targetId = best ? best.id : 0;
    }

    var target = null;
    if (humanState.targetId) {
      for (var targetIndex = 0; targetIndex < enemies.length; targetIndex++) {
        if (enemies[targetIndex] && enemies[targetIndex].id === humanState.targetId && !enemies[targetIndex].H) {
          target = enemies[targetIndex];
          break;
        }
      }
    }

    if (!target) {
      var center = typeof af === "number" && af > 0 ? af : 16384;
      var relX = own.x - center, relY = own.y - center;
      var centerDistance = Math.sqrt(relX * relX + relY * relY);
      var centerAim = centerDistance > center * .56 ? Math.atan2(-relY, -relX) : heading;
      return { mode: "imprevisível", aim: centerAim + humanState.jitter, boost: false, influence: .12 + humanProfile.unpredictability * .22 };
    }

    var targetPosition = livePosition(target);
    var tx = targetPosition.x - own.x, ty = targetPosition.y - own.y;
    var targetDistance = Math.sqrt(tx * tx + ty * ty) || 1;
    var enemyHeading = typeof target.N === "number" ? target.N : target.ang;
    var enemySpeed = typeof target.sp === "number" ? target.sp : 180;
    style = humanProfile.style;
    var leadSeconds = Math.min(style === "assassino" ? 1.65 : 1.35, targetDistance / 360);
    var futureX = targetPosition.x + Math.cos(enemyHeading) * enemySpeed * leadSeconds;
    var futureY = targetPosition.y + Math.sin(enemyHeading) * enemySpeed * leadSeconds;
    var flankDistance = Math.min(230, 55 + targetDistance * .2) * humanState.flank;
    if (style === "assassino") flankDistance *= .48;
    if (style === "espreita") {
      futureX -= Math.cos(enemyHeading) * 150;
      futureY -= Math.sin(enemyHeading) * 150;
      flankDistance *= 1.28;
    }
    futureX += -Math.sin(enemyHeading) * flankDistance;
    futureY += Math.cos(enemyHeading) * flankDistance;
    var canCutRoute = style !== "conservador" && targetDistance < 720 && humanProfile.aggression > .62;
    if (canCutRoute) {
      var closingLead = Math.min(2.15, .65 + targetDistance / 430);
      futureX = targetPosition.x + Math.cos(enemyHeading) * enemySpeed * closingLead - Math.sin(enemyHeading) * flankDistance * .18;
      futureY = targetPosition.y + Math.sin(enemyHeading) * enemySpeed * closingLead + Math.cos(enemyHeading) * flankDistance * .18;
    }
    var aim = Math.atan2(futureY - own.y, futureX - own.x) + humanState.jitter * (canCutRoute ? .12 : .35);
    if (now < humanState.feintUntil) aim += humanState.flank * (.42 + humanProfile.unpredictability * .36);
    return {
      mode: canCutRoute ? "corte de rota" : style === "espreita" ? "espreita" : now < humanState.feintUntil ? "finta" : style === "estrangulador" ? "aproximação para estrangular" : "investida",
      aim: aim,
      boost: style !== "conservador" && targetDistance > 125 && targetDistance < 1050 && humanProfile.aggression > .5 && ownLength > 38,
      influence: canCutRoute ? .99 : style === "assassino" ? .96 : style === "espreita" ? .72 : style === "estrangulador" ? .82 : .42 + humanProfile.aggression * .48 - humanProfile.caution * .05
    };
  }

  function chooseGameTactic() {
    var own = livePosition(snake);
    var heading = typeof snake.N === "number" ? snake.N : snake.ang;
    var ownLength = tf.snakeLength || gameSnakeLength(snake);
    var enemies = typeof ef !== "undefined" ? ef : [];
    var i, enemy;

    for (i = 0; i < enemies.length; i++) {
      enemy = enemies[i];
      if (!enemy || enemy === snake || enemy.H || enemy.iA === 0 || gameSnakeLength(enemy) < ownLength * 1.08) continue;
      if (!insideGameSnake(own.x, own.y, enemy)) continue;
      var enclosureCenter = gameSnakeCenter(enemy);
      var ex = own.x - enclosureCenter.x, ey = own.y - enclosureCenter.y;
      var currentRadius = Math.sqrt(ex * ex + ey * ey);
      if (!tacticState || tacticState.mode !== "trapped" || tacticState.targetId !== enemy.id) {
        var trappedCross = Math.cos(heading) * ey - Math.sin(heading) * ex;
        tacticState = { mode: "trapped", targetId: enemy.id, direction: trappedCross >= 0 ? 1 : -1 };
      }
      return { mode: "trapped", label: "Espiral de sobrevivência", aim: gameOrbitAim(own, heading, enclosureCenter, Math.max(60, currentRadius * 0.82), tacticState.direction), boost: false };
    }

    var target = null;
    if (tacticState && tacticState.mode === "constrict") {
      for (i = 0; i < enemies.length; i++) if (enemies[i] && enemies[i].id === tacticState.targetId && !enemies[i].H) target = enemies[i];
      if (!target || ownLength < gameSnakeLength(target) * 1.35) tacticState = target = null;
    }

    var constrictionMinimum = humanProfile && humanProfile.style === "estrangulador" ? 700 : humanProfile && humanProfile.style === "oportunista" ? 900 : 1100;
    if (!target && ownLength > constrictionMinimum) {
      var bestDistance = 1100;
      for (i = 0; i < enemies.length; i++) {
        enemy = enemies[i];
        if (!enemy || enemy === snake || enemy.H || enemy.iA === 0 || ownLength < gameSnakeLength(enemy) * 1.38) continue;
        var enemyPosition = livePosition(enemy);
        var dx = enemyPosition.x - own.x, dy = enemyPosition.y - own.y;
        var distance = Math.sqrt(dx * dx + dy * dy);
        if (distance < bestDistance) { bestDistance = distance; target = enemy; }
      }
      if (target) {
        var targetPosition = livePosition(target);
        var tx = targetPosition.x - own.x, ty = targetPosition.y - own.y;
        var cross = Math.cos(heading) * ty - Math.sin(heading) * tx;
        var enemyRadius = typeof tf.gf === "function" ? tf.gf(target.Pf) / 2 : 16;
        var minimumOrbit = Math.max(105, enemyRadius * 7 + 50);
        var maximumOrbit = Math.min(470, Math.sqrt(ownLength) * 14);
        if (maximumOrbit >= minimumOrbit) {
          tacticState = { mode: "constrict", targetId: target.id, direction: cross >= 0 ? 1 : -1, radius: Math.min(maximumOrbit, Math.max(minimumOrbit, bestDistance * 0.86)) };
        } else target = null;
      }
    }

    if (target && tacticState) {
      var center = livePosition(target);
      var targetRadius = typeof tf.gf === "function" ? tf.gf(target.Pf) / 2 : 16;
      var minimum = Math.max(100, targetRadius * 7 + 46);
      tacticState.radius = Math.max(minimum, tacticState.radius - 0.24);
      var ddx = own.x - center.x, ddy = own.y - center.y;
      var targetDistance = Math.sqrt(ddx * ddx + ddy * ddy);
      return { mode: "constrict", label: "Constrição", aim: gameOrbitAim(own, heading, center, tacticState.radius, tacticState.direction), boost: targetDistance > tacticState.radius * 1.35 && ownLength > 550 };
    }

    tacticState = null;
    return null;
  }

  function patchBot() {
    if (patched || typeof tf === "undefined" || !tf || typeof tf.go !== "function") return;
    var originalGo = tf.go;
    tf.go = function () {
      if (!model || typeof M8 === "undefined" || !M8 || typeof snake === "undefined" || !snake || snake.H) {
        return originalGo.apply(tf, arguments);
      }
      try {
        tf.every();
        if (tf.actionTimeout) {
          clearTimeout(tf.actionTimeout);
          tf.actionTimeout = void 0;
        }

        // O escudo tradicional continua soberano. A rede só assume quando
        // não há colisão imediata ou corredor fechado detectado pelo TT.
        if (tf.Ee() || tf.Zf()) return;

        /* Modelos PPO nativos aprenderam sem táticas prontas. Deixe a política
           decidir ataque, massa e cerco; apenas o escudo TT permanece soberano.
           Modelos antigos continuam recebendo a camada tática híbrida. */
        var nativePolicy = !!(model.metrics && model.metrics.native);
        var tactic = nativePolicy ? null : chooseGameTactic();
        if (tactic) {
          M2(tactic.boost ? 1 : 0);
          tf.ne(tactic.aim);
          if (tactic.label !== lastTacticLabel) {
            lastTacticLabel = tactic.label;
            if (typeof R === "function" && typeof y !== "undefined") R(y, "IA: " + tactic.label);
          }
          return;
        }
        lastTacticLabel = "";

        var now = performance.now();
        if (now - lastDecisionAt >= 80) {
          var input = observeGame();
          var output = infer(input);
          var heading = typeof snake.N === "number" ? snake.N : snake.ang;
          var feastMove = nativePolicy ? null : chooseGameFeastMove();
          var humanMove = nativePolicy ? null : feastMove || chooseHumanGameMove();
          var neuralAim = heading + output.steer;
          var combinedSteer = output.steer;
          if (humanMove) combinedSteer = angleDiff(heading, neuralAim + angleDiff(neuralAim, humanMove.aim) * humanMove.influence);
          var danger = maximumDanger(input);
          var wallReturn = input[98] >= .82;
          if (wallReturn) {
            var ownPosition = livePosition(snake);
            var mapCenter = typeof af === "number" && af > 0 ? af : 16384;
            combinedSteer = angleDiff(heading, Math.atan2(mapCenter - ownPosition.y, mapCenter - ownPosition.x));
          }
          var boostDangerLimit = feastMove ? .3 : humanMove ? .2 : .12;
          lastDecision = {
            steer: clamp(combinedSteer, -1.1, 1.1),
            boost: !wallReturn && ((humanMove && humanMove.boost) || output.boostScore > 0.92) && danger < boostDangerLimit && input[98] < 0.78 && tf.snakeLength > (feastMove ? 38 : 60)
          };
          lastDecisionAt = now;
        }

        M2(lastDecision.boost ? 1 : 0);
        heading = typeof snake.N === "number" ? snake.N : snake.ang;
        tf.ne(heading + clamp(lastDecision.steer, -1.1, 1.1));

        if (!announced) {
          announced = true;
          if (typeof R === "function" && typeof y !== "undefined") R(y, nativePolicy ? "IA PPO nativa ativa + proteção TT" : "IA treinada ativa + proteção TT");
          console.info(nativePolicy ? "[COBRINHA][IA] Política PPO nativa ativa com escudo anticolisão do TT." : "[COBRINHA][IA] Modelo treinado ativo com escudo anticolisão do TT.");
        }
      } catch (error) {
        console.error("[COBRINHA][IA] Falha na inferência; retornando ao bot tradicional.", error);
        return originalGo.apply(tf, arguments);
      }
    };
    patched = true;
  }

  if (modelUrl) {
    fetch(modelUrl, { cache: "no-store" })
      .then(function (response) {
        if (!response.ok) throw new Error("HTTP " + response.status);
        return response.json();
      })
      .then(function (loaded) {
        if (!loaded || !loaded.weights || !loaded.architecture || loaded.architecture.inputs !== 99) {
          throw new Error("modelo incompatível");
        }
        model = loaded;
        RANGE = loaded.range || RANGE;
        patchBot();
      })
      .catch(function (error) {
        console.error("[COBRINHA][IA] Não foi possível carregar o modelo treinado.", error);
      });
  }

  var timer = setInterval(function () {
    patchBot();
    if (patched && model) clearInterval(timer);
  }, 250);
  setTimeout(function () { clearInterval(timer); }, 30000);
})();
