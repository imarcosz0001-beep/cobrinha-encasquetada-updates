(function () {
  "use strict";

  if (window.__cobrinhaDiagnosticsInstalled) return;
  window.__cobrinhaDiagnosticsInstalled = true;
  window.__cobrinhaErrors = [];

  function remember(entry) {
    window.__cobrinhaErrors.push(entry);
    if (window.__cobrinhaErrors.length > 100) window.__cobrinhaErrors.shift();
  }

  function describe(value) {
    if (value == null) return String(value);
    if (value.stack) return String(value.stack);
    if (value.message) return String(value.message);
    try { return typeof value === "string" ? value : JSON.stringify(value); }
    catch (ignore) { return String(value); }
  }

  window.addEventListener("error", function (event) {
    var target = event.target;
    if (target && target !== window && (target.src || target.href)) {
      var resource = target.src || target.href;
      var resourceEntry = {
        type: "resource",
        resource: resource,
        tag: target.tagName || "",
        time: new Date().toISOString()
      };
      remember(resourceEntry);
      console.error("[COBRINHA][RECURSO NÃO CARREGADO]", resourceEntry);
      return;
    }

    var entry = {
      type: "error",
      message: event.message || describe(event.error),
      file: event.filename || "arquivo desconhecido",
      line: event.lineno || 0,
      column: event.colno || 0,
      stack: describe(event.error),
      time: new Date().toISOString()
    };
    remember(entry);
    console.error(
      "[COBRINHA][ERRO GLOBAL] " + entry.message + "\n" +
      entry.file + ":" + entry.line + ":" + entry.column + "\n" + entry.stack,
      entry
    );
  }, true);

  window.addEventListener("unhandledrejection", function (event) {
    var entry = {
      type: "promise",
      message: describe(event.reason),
      stack: event.reason && event.reason.stack ? String(event.reason.stack) : "",
      time: new Date().toISOString()
    };
    remember(entry);
    console.error("[COBRINHA][PROMESSA REJEITADA] " + entry.message, entry);
  });

  console.info(
    "[COBRINHA][DIAGNÓSTICO ATIVO] Erros aparecerão aqui. " +
    "Digite __cobrinhaErrors para consultar os últimos 100 registros."
  );
})();
