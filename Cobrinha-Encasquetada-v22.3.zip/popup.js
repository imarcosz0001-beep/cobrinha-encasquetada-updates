(function () {
  "use strict";
  function status(c, t) {
    var d = document.getElementById("cobrinha-status-dot"), l = document.getElementById("cobrinha-status-text");
    if (d) d.style.background = c;
    if (l) l.innerText = t;
  }
  function logo() {
    var c = document.getElementById("cobrinha-title"), x = c && c.getContext("2d"), i = new Image();
    if (!x) return;
    i.onload = function () {
      x.clearRect(0, 0, c.width, c.height); x.drawImage(i, 4, 2, 78, 78);
      x.textAlign = "left"; x.textBaseline = "middle"; x.fillStyle = "#12351e"; x.font = "bold 18px Arial"; x.fillText("Cobrinha", 87, 30);
      x.fillStyle = "#8b2d0b"; x.font = "bold 15px Arial"; x.fillText("Encasquetada", 87, 52);
    };
    i.src = chrome.runtime.getURL("icon128.png");
  }
  function check() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      if (!tabs || !tabs.length) return status("#888", "no active tab");
      var tab = tabs[0], url = tab.url || tab.pendingUrl || "";
      if (!/slither\.(io|com)/i.test(url)) return status("#888", "not on slither");
      chrome.tabs.sendMessage(tab.id, { greeting: "getCobrinhaStatus" }, function (r) {
        if (chrome.runtime.lastError) return status("#888", "mod not loaded");
        if (!r || !r.ok) return status("#888", r && r.error || "no reply");
        if (r.status.glDisabled) status("#d43a3a", "WebGL off");
        else if (r.status.glReady) status("#3bd43b", "WebGL ready" + (!r.status.webgl ? " (but user disabled)" : ""));
        else if (r.status.webgl) status("#f2b200", "WebGL init…");
        else status("#888", "2D mode");
      });
    });
  }
  window.onload = function () {
    document.getElementById("checkPage").onclick = function () { chrome.tabs.update({ url: "http://slither.io" }); window.close(); };
    document.getElementById("rtl").onclick = function () { chrome.tabs.create({ url: "https://snake-den-hub.lovable.app" }); window.close(); };
    document.getElementById("help").onclick = function () { chrome.tabs.create({ url: "https://snake-den-hub.lovable.app" }); window.close(); };
    document.getElementById("nmv").innerText = "v" + chrome.runtime.getManifest().version;
    logo(); check();
  };
})();
