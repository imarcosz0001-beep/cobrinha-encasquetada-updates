# Atualizações do addon pelo Lovable

O addon consulta a rota pública `POST /api/public/team-api` ao abrir o menu do Slither.io.

## Ação pública de consulta

Payload recebido:

```json
{
  "action": "get_addon_update",
  "current_version": "9.64",
  "extension_id": "id-da-extensao",
  "browser": "user-agent"
}
```

Resposta quando existe uma versão publicada:

```json
{
  "ok": true,
  "version": "9.65",
  "download_url": "https://SEU-ARQUIVO/Cobrinha-Encasquetada-v9.65.zip",
  "notes": "Melhorias nas salas e na interface."
}
```

Se a versão instalada já for a mais recente, a API pode retornar os mesmos dados; o addon compara as versões e não mostra o aviso.

## Mensagem para enviar ao Lovable

> Amplie a rota existente `/api/public/team-api` sem alterar nenhuma das ações atuais. Adicione a ação pública somente de leitura `get_addon_update`. Crie uma tabela de linha única chamada `addon_updates` com `version`, `download_url`, `notes`, `is_active`, `created_at` e `updated_at`. A ação deve retornar `{ ok: true, version, download_url, notes }` para a atualização ativa. Se não houver atualização ativa, retorne `{ ok: true, version: null, download_url: null, notes: null }`. Mantenha CORS aberto para slither.io, slither.com e a extensão. Valide que `version` use apenas números e pontos e que `download_url` seja HTTPS. Não crie nenhuma ação pública de escrita ou publicação de atualização. A publicação e alteração da URL devem ser feitas somente pelo painel administrativo do projeto ou por uma função protegida no servidor. O arquivo ZIP deve ficar em uma URL HTTPS pública e estável.

## Segurança

A consulta pode ser pública. A publicação de versões e a alteração de `download_url` não podem ser públicas, pois essa URL distribui código para todos os usuários do addon.

Em Chrome/Brave no Windows, um addon instalado manualmente não pode substituir a si próprio silenciosamente. O botão baixa o ZIP automaticamente; o usuário ainda precisa substituir a pasta e recarregar a extensão. Atualização totalmente automática exige distribuição pela Chrome Web Store.
