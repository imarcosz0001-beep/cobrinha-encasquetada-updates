(function () {
  "use strict";

  var commands = [
    {
      group: "tags", command: "!criartag", title: "Criar uma tag", server: true,
      detail: "1. Informe os dados. 2. Escolha uma imagem. 3. Ajuste e publique nos cartões seguintes.",
      button: "Escolher imagem e criar",
      fields: [
        { name: "id", label: "ID da tag", placeholder: "minha-tag", required: true },
        { name: "password", label: "Senha", type: "password", placeholder: "senha da tag", required: true },
        { name: "name", label: "Nome", placeholder: "Nome que será exibido", grow: true }
      ]
    },
    {
      group: "tags", command: "!loadtag", title: "Carregar e testar uma tag", server: true,
      detail: "Baixa a tag do seu servidor e a aplica na cobra. A senha é opcional, mas necessária para salvar ajustes.",
      button: "Carregar tag",
      fields: [
        { name: "id", label: "ID", placeholder: "ID da tag", required: true },
        { name: "password", label: "Senha (opcional)", type: "password", placeholder: "senha" }
      ]
    },
    {
      group: "tags", command: "!newtag", title: "Ajustar a tag carregada", server: true,
      detail: "Altera as duas cores e o deslocamento X/Y. Se a tag foi carregada com senha, salva tudo no Lovable.",
      button: "Aplicar ajustes",
      fields: [
        { name: "color1", label: "Cor 1", type: "color", value: "#000000", required: true },
        { name: "color2", label: "Cor 2", type: "color", value: "#ffffff", required: true },
        { name: "x", label: "Posição X", type: "number", value: "-20", required: true },
        { name: "y", label: "Posição Y", type: "number", value: "-120", required: true }
      ]
    },
    {
      group: "tags", command: "!tag", title: "Publicar e ativar uma tag", server: true,
      detail: "Ativa a tag no catálogo e já a carrega na sua cobra.", button: "Ativar tag",
      fields: [
        { name: "id", label: "ID", placeholder: "ID da tag", required: true },
        { name: "password", label: "Senha", type: "password", placeholder: "senha", required: true }
      ]
    },
    {
      group: "tags", command: "!rst", title: "Trocar a senha de uma tag", server: true,
      detail: "Confirma a senha atual antes de registrar a nova senha no servidor.", button: "Trocar senha",
      fields: [
        { name: "id", label: "ID", placeholder: "ID da tag", required: true },
        { name: "old", label: "Senha atual", type: "password", placeholder: "senha atual", required: true },
        { name: "next", label: "Nova senha", type: "password", placeholder: "nova senha", required: true }
      ]
    },
    {
      group: "tags", command: "!forceupdate", title: "Sincronizar tags", server: true,
      detail: "Consulta as versões no Lovable e atualiza a cópia local quando necessário.", button: "Sincronizar"
    },
    {
      group: "tags", command: "!forcecleanupdate", title: "Baixar novamente", server: true, danger: true,
      detail: "Força uma nova leitura do catálogo. A cópia atual é preservada caso o servidor não responda.", button: "Forçar atualização"
    },
    {
      group: "game", command: "!ts", title: "IP do servidor",
      detail: "Mostra ou oculta o endereço do servidor conectado. A escolha não é salva.", button: "Alternar IP"
    },
    {
      group: "game", command: "!sbcx", title: "Liberar as teclas C e X",
      detail: "Alterna o vínculo das teclas C e X e salva a escolha no navegador.", button: "Alternar C e X"
    },
    {
      group: "game", command: "!protocol", title: "Protocolo da conexão",
      detail: "Alterna entre o protocolo padrão v12 e o experimental v13.", button: "Alternar protocolo"
    },
    {
      group: "game", command: "!ellipse", title: "Círculo central do mapa",
      detail: "Define posição e formato. Use 0 para a cabeça atual ou −1 para o centro do mapa.", button: "Aplicar círculo",
      fields: [
        { name: "x", label: "X", type: "number", value: "-1", required: true },
        { name: "y", label: "Y", type: "number", value: "-1", required: true },
        { name: "rx", label: "Raio X", type: "number", value: "100", required: true },
        { name: "ry", label: "Raio Y", type: "number", value: "100", required: true }
      ]
    },
    {
      group: "game", command: "!timedemo", title: "Teste com cobras",
      detail: "Adiciona 10 clones para medir o desempenho na tela de escolha de visual.", button: "Criar 10 clones"
    },
    {
      group: "game", command: "!timedemo1", title: "Teste com comida",
      detail: "Adiciona cerca de 10 mil partículas para testar o desempenho.", button: "Criar comida de teste"
    },
    {
      group: "system", command: "!history", title: "Histórico de comandos",
      detail: "Mostra os últimos 100 comandos executados.", button: "Mostrar histórico"
    },
    {
      group: "system", command: "!clearhistory", title: "Limpar histórico", danger: true,
      detail: "Apaga do navegador o histórico dos comandos usados.", button: "Limpar histórico"
    },
    {
      group: "system", command: "!help", title: "Ajuda em texto",
      detail: "Mantém o !help original e escreve a lista resumida na área de mensagens.", button: "Executar !help"
    }
  ];

  var backdrop;
  var panel;
  var status;
  var operationId = 0;

  function element(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  function setStatus(text, kind, token) {
    if (!status) return;
    status.textContent = text;
    status.dataset.kind = kind || "info";
    status.dataset.operation = token == null ? "" : String(token);
  }

  function execute(text) {
    var token = ++operationId;
    setStatus("Executando: " + text, "busy", token);
    var api = window.CobrinhaCommands;
    if (!api || typeof api.execute !== "function") {
      setStatus("O jogo ainda está carregando. Tente novamente em alguns segundos.", "error");
      return Promise.reject(new Error("API de comandos indisponível"));
    }
    return Promise.resolve(api.execute(text)).then(function () {
      if (status && status.dataset.operation === String(token)) {
        setStatus("Comando executado: " + text, "success");
      }
    }).catch(function (error) {
      setStatus((error && error.message) || "Não foi possível executar o comando.", "error");
    });
  }

  function commandText(definition, card) {
    var values = [];
    var invalid = null;
    card.querySelectorAll("[data-command-value]").forEach(function (input) {
      var value = String(input.value || "").trim();
      if (input.required && !value && !invalid) invalid = input;
      if (value) values.push(value);
    });
    if (invalid) {
      invalid.focus();
      setStatus("Preencha o campo “" + invalid.getAttribute("aria-label") + "”.", "error");
      return null;
    }
    return [definition.command].concat(values).join(" ");
  }

  function createCard(definition) {
    var card = element("article", "cobrinha-command-card");
    card.dataset.group = definition.group;
    var heading = element("div", "cobrinha-command-heading");
    var titleWrap = element("div");
    titleWrap.appendChild(element("strong", "", definition.title));
    titleWrap.appendChild(element("code", "", definition.command));
    heading.appendChild(titleWrap);
    if (definition.server) heading.appendChild(element("span", "cobrinha-server-badge", "Lovable"));
    card.appendChild(heading);
    card.appendChild(element("p", "", definition.detail));

    if (definition.fields && definition.fields.length) {
      var form = element("div", "cobrinha-command-fields");
      definition.fields.forEach(function (field) {
        var label = element("label", field.grow ? "cobrinha-command-grow" : "");
        label.appendChild(element("span", "", field.label));
        var input = document.createElement("input");
        input.type = field.type || "text";
        input.value = field.value || "";
        input.placeholder = field.placeholder || "";
        input.required = Boolean(field.required);
        input.dataset.commandValue = field.name;
        input.setAttribute("aria-label", field.label);
        label.appendChild(input);
        form.appendChild(label);
      });
      card.appendChild(form);
    }

    var run = element("button", definition.danger ? "cobrinha-command-run is-danger" : "cobrinha-command-run", definition.button || "Executar");
    run.type = "button";
    run.addEventListener("click", function () {
      var text = commandText(definition, card);
      if (text) execute(text);
    });
    card.appendChild(run);
    return card;
  }

  function syncCurrentTag() {
    var api = window.CobrinhaCommands;
    var tag = api && typeof api.currentTag === "function" ? api.currentTag() : null;
    if (!tag || !panel) return;
    var card = panel.querySelector('[data-command="!newtag"]');
    if (!card) return;
    var values = { color1: tag.color1, color2: tag.color2, x: tag.x, y: tag.y };
    Object.keys(values).forEach(function (name) {
      var input = card.querySelector('[data-command-value="' + name + '"]');
      if (input && values[name] != null) input.value = values[name];
    });
  }

  function close() {
    if (!panel) return;
    panel.hidden = true;
    backdrop.hidden = true;
  }

  function open() {
    build();
    panel.hidden = false;
    backdrop.hidden = false;
    syncCurrentTag();
    var raw = panel.querySelector("#cobrinha-command-raw");
    if (raw) setTimeout(function () { raw.focus(); }, 0);
  }

  function toggle() {
    if (!panel || panel.hidden) open();
    else close();
  }

  function build() {
    if (panel) return;
    backdrop = element("div", "");
    backdrop.id = "cobrinha-command-backdrop";
    backdrop.hidden = true;
    backdrop.addEventListener("click", close);

    panel = element("section", "");
    panel.id = "cobrinha-command-center";
    panel.hidden = true;
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    panel.setAttribute("aria-label", "Central de comandos da Cobrinha Encasquetada");

    var header = element("header");
    var heading = element("div");
    heading.appendChild(element("strong", "", "Central de comandos"));
    heading.appendChild(element("span", "", "Use pelos botões ou digite um comando — sem abrir o chat"));
    var closeButton = element("button", "", "×");
    closeButton.type = "button";
    closeButton.title = "Fechar";
    closeButton.addEventListener("click", close);
    header.appendChild(heading);
    header.appendChild(closeButton);
    panel.appendChild(header);

    var tabs = element("nav", "cobrinha-command-tabs");
    [
      ["all", "Todos"], ["tags", "Tags"], ["game", "Jogo"], ["system", "Histórico e ajuda"]
    ].forEach(function (tab, index) {
      var button = element("button", index === 0 ? "is-active" : "", tab[1]);
      button.type = "button";
      button.dataset.group = tab[0];
      button.addEventListener("click", function () {
        tabs.querySelectorAll("button").forEach(function (item) { item.classList.toggle("is-active", item === button); });
        panel.querySelectorAll(".cobrinha-command-card").forEach(function (card) {
          card.hidden = tab[0] !== "all" && card.dataset.group !== tab[0];
        });
      });
      tabs.appendChild(button);
    });
    panel.appendChild(tabs);

    status = element("div", "cobrinha-command-status", "Pronto. Os cartões com “Lovable” usam o seu servidor de tags.");
    status.dataset.kind = "info";
    panel.appendChild(status);

    var grid = element("main", "cobrinha-command-grid");
    commands.forEach(function (definition) {
      var card = createCard(definition);
      card.dataset.command = definition.command;
      grid.appendChild(card);
    });
    panel.appendChild(grid);

    var manual = element("footer", "cobrinha-command-manual");
    var input = document.createElement("input");
    input.id = "cobrinha-command-raw";
    input.type = "text";
    input.autocomplete = "off";
    input.placeholder = "Digite um comando, por exemplo: !newtag #00ff88 #ffffff -20 -120";
    var send = element("button", "", "Executar");
    send.type = "button";
    function sendRaw() {
      var value = input.value.trim();
      if (!value) return input.focus();
      execute(value);
    }
    send.addEventListener("click", sendRaw);
    input.addEventListener("keydown", function (event) {
      if (event.key === "Enter") {
        event.preventDefault();
        sendRaw();
      }
    });
    manual.appendChild(input);
    manual.appendChild(send);
    panel.appendChild(manual);

    document.body.appendChild(backdrop);
    document.body.appendChild(panel);
  }

  document.addEventListener("cobrinha:toggle-command-center", toggle);
  document.addEventListener("cobrinha:command-message", function (event) {
    var detail = event.detail || {};
    setStatus(detail.text || "", detail.error ? "error" : "success");
  });
  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && panel && !panel.hidden) {
      event.preventDefault();
      event.stopPropagation();
      close();
    }
  }, true);

  if (document.body) build();
  else document.addEventListener("DOMContentLoaded", build, { once: true });
})();
