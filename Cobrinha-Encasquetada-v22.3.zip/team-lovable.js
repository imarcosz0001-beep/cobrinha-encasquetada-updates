(function () {
  "use strict";

  var API_URL = "https://snake-den-hub.lovable.app/api/public/team-api";
  var ROOM_KEY = "cobrinhaSala";
  var CLIENT_KEY = "cobrinhaCliente";
  var NICK_KEY = "cobrinhaApelido";
  var roomCode = (localStorage.getItem(ROOM_KEY) || "").toUpperCase();
  var clientId = localStorage.getItem(CLIENT_KEY) || makeClientId();
  var nickname = localStorage.getItem(NICK_KEY) || "";
  var busy = false;
  var heartbeatBusy = false;
  var listBusy = false;
  var messageBusy = false;
  var chatApiUnavailable = false;
  var lastMessageId = 0;
  var lastPlayers = [];

  localStorage.setItem(CLIENT_KEY, clientId);

  function makeClientId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return window.crypto.randomUUID();
    }
    return "cobrinha-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
  }

  function post(payload) {
    var controller = new AbortController();
    var timeout = setTimeout(function () { controller.abort(); }, 9000);
    return fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (data) {
        if (!response.ok || data.ok === false) {
          throw new Error(data.error || data.message || "A API recusou a solicitação.");
        }
        return data;
      });
    }).finally(function () {
      clearTimeout(timeout);
    });
  }

  function cleanCode(value) {
    return String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
  }

  function currentNickname() {
    var field = document.getElementById("in_comkey");
    var gameNick = document.getElementById("nick");
    return String((field && field.value) || nickname || (gameNick && gameNick.value) || "").trim().slice(0, 32);
  }

  function currentGameState() {
    var gameSnake = window.snake;
    var isPlaying = Boolean(window.playing && gameSnake);
    var server = "";
    var score = 0;

    if (isPlaying && window.bso && window.bso.ip && window.bso.po) {
      server = window.bso.ip + ":" + window.bso.po;
    } else if (isPlaying && typeof window.KP === "string") {
      server = window.KP;
    }

    if (isPlaying) {
      try {
        score = Math.floor(15 * (window.fpsls[gameSnake.sct] + gameSnake.fam / window.fmlts[gameSnake.sct] - 1) - 5);
      } catch (ignore) {
        score = 0;
      }
    }

    return {
      server_address: server,
      position_x: isPlaying ? Math.round(gameSnake.xx || 0) : 0,
      position_y: isPlaying ? Math.round(gameSnake.yy || 0) : 0,
      score: Math.max(0, score || 0),
      status: isPlaying ? "jogando" : "no menu"
    };
  }

  function setStatus(message, kind) {
    var status = document.getElementById("lovable-team-settings-status");
    if (status) {
      status.textContent = message || "";
      status.setAttribute("data-kind", kind || "ok");
    }
  }

  function systemMessage(message) {
    try {
      if (typeof window.R === "function" && window.y) {
        window.R(window.y, "# " + message);
        return;
      }
    } catch (ignore) {}
    console.log("[Cobrinha Encasquetada]", message);
  }

  function escapeChat(value) {
    return String(value || "").replace(/[&<>]/g, function (character) {
      return character === "&" ? "&amp;" : character === "<" ? "&lt;" : "&gt;";
    });
  }

  function renderRoomMessage(message) {
    if (!message || !message.message) return;
    try {
      if (typeof window.R === "function") {
        window.R(escapeChat(message.nickname || "Jogador"), escapeChat(message.message));
      }
    } catch (ignore) {}
  }

  function sendRoomMessage(text) {
    text = String(text || "").trim().slice(0, 300);
    if (!roomCode || !text || messageBusy) return Promise.resolve();
    messageBusy = true;
    return post({
      action: "send_message",
      room_code: roomCode,
      client_id: clientId,
      nickname: currentNickname() || nickname,
      message: text
    }).then(function () {
      chatApiUnavailable = false;
      return listRoomMessages();
    }).catch(function () {
      if (!chatApiUnavailable) {
        systemMessage("O backend do chat ainda não foi publicado no Lovable. Os comandos com ! continuam funcionando.");
      }
      chatApiUnavailable = true;
    }).finally(function () {
      messageBusy = false;
    });
  }

  function listRoomMessages() {
    if (!roomCode || chatApiUnavailable) return Promise.resolve();
    return post({
      action: "list_messages",
      room_code: roomCode,
      client_id: clientId,
      after_id: lastMessageId
    }).then(function (data) {
      var messages = Array.isArray(data.messages) ? data.messages : [];
      messages.forEach(function (message) {
        var id = Number(message.id) || 0;
        if (id > lastMessageId) {
          renderRoomMessage(message);
          lastMessageId = id;
        }
      });
      var returnedCursor = Number(data.last_id) || 0;
      if (returnedCursor > lastMessageId) lastMessageId = returnedCursor;
    }).catch(function () {
      chatApiUnavailable = true;
    });
  }

  // O campo #ichat passa a usar o chat da sala Lovable. Comandos iniciados por
  // "!" continuam sendo processados pelo próprio mod.
  document.addEventListener("keydown", function (event) {
    var field = event.target;
    if (!field || field.id !== "ichat") return;
    if (!(event.key === "Enter" || event.code === "NumpadEnter" || event.keyCode === 13)) return;
    var value = String(field.value || "").trim();
    if (!value || value.charAt(0) === "!") return;
    if (!roomCode && window.Lf === false) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    field.value = "";
    if (roomCode) sendRoomMessage(value);
    else systemMessage("Entre em uma sala do Lovable antes de enviar mensagens.");
  }, true);

  function setBusy(value) {
    busy = value;
    ["loadkeys", "savekeys", "noteam"].forEach(function (id) {
      var button = document.getElementById(id);
      if (button) button.disabled = value;
    });
  }

  function saveSession(code, nick) {
    var previousRoom = roomCode;
    roomCode = cleanCode(code);
    nickname = String(nick || "").trim().slice(0, 32);
    localStorage.setItem(ROOM_KEY, roomCode);
    localStorage.setItem(NICK_KEY, nickname);
    if (previousRoom !== roomCode) {
      lastMessageId = 0;
      chatApiUnavailable = false;
    }
    updateSettingsValues();
    renderPanel();
  }

  function clearSession() {
    roomCode = "";
    lastMessageId = 0;
    chatApiUnavailable = false;
    lastPlayers = [];
    localStorage.removeItem(ROOM_KEY);
    updateSettingsValues();
    renderPanel();
  }

  function join(code, nick) {
    code = cleanCode(code);
    nick = String(nick || "").trim().slice(0, 32);
    if (code.length !== 8) throw new Error("Digite um código de sala com 8 caracteres.");
    if (!nick) throw new Error("Digite seu apelido.");

    return post({
      action: "join_room",
      room_code: code,
      client_id: clientId,
      nickname: nick
    }).then(function () {
      saveSession(code, nick);
      setStatus("Você entrou na sala " + code + ".", "ok");
      return sendHeartbeat();
    });
  }

  function createRoom() {
    var nick = currentNickname();
    if (!nick) return Promise.reject(new Error("Digite seu apelido antes de criar a sala."));
    return post({ action: "create_room" }).then(function (data) {
      var code = cleanCode(data.code || data.room_code);
      if (code.length !== 8) throw new Error("A API não devolveu um código de sala válido.");
      return join(code, nick).then(function () {
        setStatus("Sala " + code + " criada. Envie este código ao seu amigo.", "ok");
      });
    });
  }

  function leaveRoom() {
    if (!roomCode) {
      clearSession();
      setStatus("Você não está em uma sala.", "ok");
      return Promise.resolve();
    }
    var oldCode = roomCode;
    return post({ action: "leave_room", room_code: oldCode, client_id: clientId })
      .catch(function () {})
      .then(function () {
        clearSession();
        setStatus("Você saiu da sala " + oldCode + ".", "ok");
      });
  }

  function sendHeartbeat() {
    if (!roomCode || heartbeatBusy) return Promise.resolve();
    heartbeatBusy = true;
    var state = currentGameState();
    return post({
      action: "heartbeat",
      room_code: roomCode,
      client_id: clientId,
      nickname: nickname,
      server_address: state.server_address,
      position_x: state.position_x,
      position_y: state.position_y,
      score: state.score,
      status: state.status
    }).catch(function () {
      setStatus("Sem resposta da sala. Tentando novamente...", "error");
    }).finally(function () {
      heartbeatBusy = false;
    });
  }

  function listPlayers() {
    if (!roomCode || listBusy) return Promise.resolve();
    listBusy = true;
    return post({ action: "list_players", room_code: roomCode }).then(function (data) {
      lastPlayers = Array.isArray(data.players) ? data.players : [];
      renderPanel();
      renderTeammatesOnMinimap();
    }).catch(function () {
      renderPanel("Não foi possível atualizar a equipe.");
    }).finally(function () {
      listBusy = false;
    });
  }

  function normalizedServer(value) {
    return String(value || "").trim().toLowerCase().replace(/^wss?:\/\//, "").replace(/\/ptc\/?$/, "");
  }

  function playerCoordinate(player, primary, fallback) {
    var value = Number(player && player[primary]);
    if (!Number.isFinite(value)) value = Number(player && player[fallback]);
    return Number.isFinite(value) ? value : 0;
  }

  function markerColor(value) {
    value = String(value || "amigo");
    var hash = 0;
    for (var index = 0; index < value.length; index++) hash = ((hash << 5) - hash + value.charCodeAt(index)) | 0;
    return "hsl(" + Math.abs(hash % 360) + " 88% 62%)";
  }

  function renderTeammatesOnMinimap() {
    var minimap = document.getElementById("mmap");
    if (!minimap) return;
    var layer = document.getElementById("lovable-team-map-layer");
    if (!layer) {
      layer = document.createElement("div");
      layer.id = "lovable-team-map-layer";
      minimap.appendChild(layer);
    }
    layer.textContent = "";

    var ownState = currentGameState();
    var ownServer = normalizedServer(ownState.server_address);
    if (!roomCode || !ownServer || ownState.status !== "jogando") return;

    var size = minimap.getBoundingClientRect().width || minimap.offsetWidth || 104;
    var scale = size / 104;
    var center = 52 * scale;
    var mapRadius = 40 * scale;
    var worldCenter = Number(window.af);
    if (!Number.isFinite(worldCenter) || worldCenter <= 0) worldCenter = 16384;
    var worldRadius = window.V0 && window.rs ? Number(window.BQ) : worldCenter;
    if (!Number.isFinite(worldRadius) || worldRadius <= 0) worldRadius = worldCenter;

    lastPlayers.forEach(function (player) {
      if (!player || player.client_id === clientId || normalizedServer(player.server_address) !== ownServer) return;
      if (String(player.status || "").toLowerCase() !== "jogando") return;
      var worldX = playerCoordinate(player, "position_x", "x");
      var worldY = playerCoordinate(player, "position_y", "y");
      if (!worldX && !worldY) return;

      var dx = mapRadius * (worldX - worldCenter) / worldRadius;
      var dy = mapRadius * (worldY - worldCenter) / worldRadius;
      var distance = Math.sqrt(dx * dx + dy * dy);
      if (distance > mapRadius - 2) {
        dx *= (mapRadius - 2) / distance;
        dy *= (mapRadius - 2) / distance;
      }

      var marker = document.createElement("div");
      marker.className = "lovable-team-map-marker";
      marker.style.left = (center + dx) + "px";
      marker.style.top = (center + dy) + "px";
      marker.style.setProperty("--friend-color", markerColor(player.client_id || player.nickname));
      marker.title = (player.nickname || "Amigo") + " · tamanho " + (Number(player.score) || 0);

      var dot = document.createElement("span");
      dot.className = "lovable-team-map-dot";
      marker.appendChild(dot);
      var label = document.createElement("span");
      label.className = "lovable-team-map-label";
      label.textContent = String(player.nickname || "Amigo").slice(0, 14);
      marker.appendChild(label);
      layer.appendChild(marker);
    });
  }

  function joinServer(address) {
    if (!address) return;
    var input = document.getElementById("ip-server");
    if (!input) {
      setStatus("O campo de servidor do jogo ainda não está disponível.", "error");
      return;
    }
    input.value = address;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    var play = document.getElementById("connect-btn");
    if (play) play.click();
  }

  function renderPanel(errorMessage) {
    var panel = document.getElementById("lovable-team-panel");
    var official = document.getElementById("divpl");

    if (!roomCode) {
      if (panel) panel.remove();
      if (official) official.style.display = "";
      return;
    }

    if (!panel) {
      panel = document.createElement("div");
      panel.id = "lovable-team-panel";
      document.body.appendChild(panel);
    }
    if (official) official.style.display = "none";

    panel.textContent = "";
    var title = document.createElement("div");
    title.className = "lovable-team-title";
    title.appendChild(document.createTextNode("Equipe — sala "));
    var code = document.createElement("span");
    code.className = "lovable-team-room";
    code.textContent = roomCode;
    title.appendChild(code);
    panel.appendChild(title);

    var status = document.createElement("div");
    status.className = "lovable-team-status";
    status.textContent = errorMessage || (lastPlayers.length + (lastPlayers.length === 1 ? " jogador conectado" : " jogadores conectados"));
    panel.appendChild(status);

    lastPlayers.forEach(function (player) {
      var row = document.createElement("div");
      row.className = "lovable-team-player";
      var name = document.createElement("div");
      name.className = "lovable-team-player-name";
      name.textContent = (player.client_id === clientId ? "● " : "◆ ") + (player.nickname || "Sem nome") + (player.client_id === clientId ? " (você)" : "");
      row.appendChild(name);

      var meta = document.createElement("div");
      meta.className = "lovable-team-player-meta";
      meta.textContent = (player.status || "online") + " · tamanho " + (Number(player.score) || 0) + (player.server_address ? " · " + player.server_address : "");
      row.appendChild(meta);

      var ownServer = currentGameState().server_address;
      if (player.client_id !== clientId && player.server_address && player.server_address !== ownServer) {
        var button = document.createElement("button");
        button.className = "lovable-team-join-server";
        button.type = "button";
        button.textContent = "Entrar no servidor deste amigo";
        button.addEventListener("click", function () { joinServer(player.server_address); });
        row.appendChild(button);
      }
      panel.appendChild(row);
    });
  }

  function updateSettingsValues() {
    var code = document.getElementById("in_tidkey");
    var nick = document.getElementById("in_comkey");
    if (code) code.value = roomCode;
    if (nick) nick.value = nickname;
  }

  function customizeSettings() {
    var page = document.getElementById("settpage");
    var code = document.getElementById("in_tidkey");
    var auth = document.getElementById("in_authkey");
    var nick = document.getElementById("in_comkey");
    if (!page || !code || !auth || !nick) return;
    if (page.getAttribute("data-lovable-team-ready") === "1") return;
    page.setAttribute("data-lovable-team-ready", "1");

    code.maxLength = 8;
    code.placeholder = "código de 8 caracteres";
    code.value = roomCode;
    code.addEventListener("input", function () {
      var cleaned = cleanCode(code.value);
      if (code.value !== cleaned) code.value = cleaned;
    });
    var codeLabel = code.closest("tr").querySelector("td");
    if (codeLabel) codeLabel.textContent = "Código da sala:";

    var authRow = auth.closest("tr");
    if (authRow) authRow.style.display = "none";

    nick.placeholder = "seu nome na equipe";
    nick.value = nickname;
    var nickLabel = nick.closest("tr").querySelector("td");
    if (nickLabel) nickLabel.textContent = "Seu apelido:";

    var create = document.getElementById("loadkeys");
    var enter = document.getElementById("savekeys");
    var leave = document.getElementById("noteam");
    var saved = document.getElementById("select-key");
    var remove = document.getElementById("deletekey");
    if (create) create.textContent = "Criar sala";
    if (enter) enter.textContent = "Entrar";
    if (leave) leave.textContent = "Sair da sala";
    if (saved) saved.style.display = "none";
    if (remove) remove.style.display = "none";

    if (!document.getElementById("lovable-team-settings-row")) {
      var controlsRow = create && create.closest("tr");
      if (controlsRow) {
        var infoRow = document.createElement("tr");
        infoRow.id = "lovable-team-settings-row";
        var cell = document.createElement("td");
        cell.colSpan = 2;
        var info = document.createElement("span");
        info.id = "lovable-team-settings-status";
        info.textContent = roomCode ? "Conectado à sala " + roomCode + "." : "Crie uma sala ou digite o código enviado pelo seu amigo.";
        cell.appendChild(info);
        infoRow.appendChild(cell);
        controlsRow.parentNode.insertBefore(infoRow, controlsRow.nextSibling);
      }
    }
  }

  document.addEventListener("click", function (event) {
    var button = event.target && event.target.closest ? event.target.closest("button") : null;
    if (!button || ["loadkeys", "savekeys", "noteam"].indexOf(button.id) === -1) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (busy) return;

    setBusy(true);
    setStatus("Aguarde...", "busy");
    var operation;
    try {
      if (button.id === "loadkeys") operation = createRoom();
      else if (button.id === "savekeys") operation = join(document.getElementById("in_tidkey").value, currentNickname());
      else operation = leaveRoom();
    } catch (error) {
      operation = Promise.reject(error);
    }
    operation.catch(function (error) {
      setStatus(error && error.message ? error.message : "Não foi possível concluir a operação.", "error");
    }).finally(function () {
      setBusy(false);
    });
  }, true);

  new MutationObserver(function () {
    customizeSettings();
    if (roomCode && !document.getElementById("lovable-team-panel")) renderPanel();
  }).observe(document.documentElement, { childList: true, subtree: true });

  setInterval(function () {
    if (!roomCode) return;
    sendHeartbeat();
    listPlayers();
    listRoomMessages();
  }, 3000);

  setInterval(renderTeammatesOnMinimap, 500);

  if (roomCode && nickname) {
    join(roomCode, nickname).catch(function () {
      clearSession();
    });
  }
  customizeSettings();
  renderPanel();
})();
