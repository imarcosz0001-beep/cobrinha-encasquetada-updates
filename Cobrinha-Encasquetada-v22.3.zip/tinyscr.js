(function () {
  "use strict";
  function get(keys) { return new Promise(function (done) { chrome.storage.local.get(keys, function (d) { done(chrome.runtime.lastError ? {} : d || {}); }); }); }
  function set(data) { return new Promise(function (done) { chrome.storage.local.set(data, function () { done(!chrome.runtime.lastError); }); }); }
  function normalize(key, value) {
    if (value === null || typeof value === "undefined") return undefined;
    if (key === "cstagext" || key === "fstagext") { try { return JSON.parse(value); } catch (ignore) { return []; } }
    if (key === "cstagver" || key === "fstagver" || key === "lastupd") { var n = Number(value); return Number.isFinite(n) ? n : 0; }
    return value;
  }
  async function migrate() {
    var keys = ["menuimg", "cstagext", "fstagext", "cstagver", "fstagver", "lastupd"], data = {}, moved = [];
    keys.forEach(function (key) { if (window.localStorage && key in window.localStorage) { data[key] = normalize(key, localStorage.getItem(key)); moved.push(key); } });
    if (!moved.length || !await set(data)) return;
    moved.forEach(function (key) { localStorage.removeItem(key); });
  }
  async function removeLegacyTagData() {
    var clean = {
      cstagext: [],
      fstagext: [],
      cstagver: 1,
      fstagver: 1,
      lastupd: Math.floor(Date.now() / 1000)
    };
    await set(clean);
    ["cstagext", "fstagext", "cstagver", "fstagver", "lastupd", "hst", "tag"].forEach(function (key) {
      try { localStorage.removeItem(key); } catch (ignore) {}
    });
  }
  function inject() {
    var css = document.createElement("link"); css.href = chrome.runtime.getURL("bootstrap.css"); css.rel = "stylesheet"; document.documentElement.appendChild(css);
    ["jquery-2.2.4.min.js", "fstags.js", "emoji-data.js", "main-mt.js"].reduce(function (chain, file) {
      return chain.then(function () { return new Promise(function (done) {
        var script = document.createElement("script"); script.src = chrome.runtime.getURL(file); script.async = false;
        script.addEventListener("load", done, { once: true }); document.documentElement.appendChild(script);
      }); });
    }, Promise.resolve());
  }
  window.onload = async function () {
    await migrate();
    await removeLegacyTagData();
    localStorage.setItem("loadbench", Date.now());
    localStorage.setItem("cobrinhaRuntimeId", chrome.runtime.id);
    localStorage.setItem(["ti", "nyscrID"].join(""), chrome.runtime.id);
    localStorage.setItem("myscrversion", chrome.runtime.getManifest().version);
    ["logoih", "twt", "fb", "csrvh"].forEach(function (id) { var el = document.getElementById(id); if (el) el.remove(); });
    var stored = await get(["menuimg"]);
    document.body.style.backgroundImage = stored.menuimg ? "url(" + stored.menuimg + ")" : "url(" + chrome.runtime.getURL("bdemo.webp") + ")";
    document.body.style.backgroundSize = "cover"; document.body.style.backgroundRepeat = "no-repeat";
    inject();
    chrome.runtime.onMessage.addListener(function (m) {
      if (["playsrv", "rsvars", "utag"].indexOf(m.greeting) === -1) return;
      var p = {}; p[m.greeting] = m[m.greeting]; postMessage(p, "*");
    });
    var pending = Object.create(null);
    window.addEventListener("message", function (e) {
      var legacyResponse = ["n", "tlStatusResp"].join("");
      var r = e && e.data && (e.data.cobrinhaStatusResp || e.data[legacyResponse]), q = r && pending[r.id]; if (!q) return;
      delete pending[r.id]; clearTimeout(q.timer); q.send({ ok: true, status: r.status });
    });
    chrome.runtime.onMessage.addListener(function (m, sender, reply) {
      if (!m || m.greeting !== "getCobrinhaStatus") return;
      var id = Math.random().toString(36).slice(2) + Date.now().toString(36);
      pending[id] = { send: reply, timer: setTimeout(function () { if (pending[id]) { delete pending[id]; reply({ ok: false, error: "timeout" }); } }, 400) };
      var legacyRequest = ["n", "tlStatusReq"].join(""), payload = {};
      payload[legacyRequest] = { id: id };
      window.postMessage(payload, "*"); return true;
    });
  };
})();
