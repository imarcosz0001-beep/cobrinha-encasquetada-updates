(function () {
  "use strict";
  function stamp() {
    var d = new Date(), p = function (v) { return v < 10 ? "0" + v : String(v); };
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + "-" + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds()) + "-" + d.getMilliseconds();
  }
  function shot(sender, prefix, server, reply) {
    chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png", quality: 100 }, function (url) {
      if (chrome.runtime.lastError || !url) return reply({ msg: "error" });
      reply({ msg: "ok", fn: prefix + server + "-time-" + stamp() + ".png", url: url });
    });
  }
  chrome.runtime.onMessageExternal.addListener(function (m, sender, reply) {
    var parts = String(m && m.greeting || "").split("*"), async = false;
    var oldShot = ["Hi N", "TL ss"].join(""), oldKill = ["Hi N", "TL ak"].join("");
    var oldGet = ["n", "tlStorageGet"].join(""), oldSet = ["n", "tlStorageSet"].join(""), oldRemove = ["n", "tlStorageRemove"].join("");
    if (parts[0] === "Cobrinha screenshot" || parts[0] === "Cobrinha kill" || parts[0] === oldShot || parts[0] === oldKill || parts[0] === "dead") {
      async = true; shot(sender, parts[0] === "dead" ? "cobrinha-morte-servidor-" : parts[0] === "Cobrinha kill" || parts[0] === oldKill ? "cobrinha-abate-servidor-" : "cobrinha-captura-servidor-", parts[1], reply);
    } else if (parts[0] === "dwnldbarOFF" || parts[0] === "dwnldbarON") {
      chrome.downloads.setShelfEnabled(parts[0] === "dwnldbarON"); reply({ ok: true });
    } else if (["playsrv", "utag", "rsvars"].indexOf(parts[0]) !== -1) {
      async = true; chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (!tabs || !tabs.length) return reply({ ok: false });
        chrome.tabs.sendMessage(tabs[0].id, { greeting: parts[0], playsrv: m.playsrv, utag: m.utag, rsvars: m.rsvars }); reply({ ok: true });
      });
    } else if (parts[0] === "cobrinhaStorageGet" || parts[0] === oldGet) {
      async = true; chrome.storage.local.get(m.keys || null, function (d) { reply(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : { ok: true, data: d || {} }); });
    } else if (parts[0] === "cobrinhaStorageSet" || parts[0] === oldSet) {
      async = true; chrome.storage.local.set(m.data || {}, function () { reply(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : { ok: true }); });
    } else if (parts[0] === "cobrinhaStorageRemove" || parts[0] === oldRemove) {
      async = true; chrome.storage.local.remove(m.keys || [], function () { reply(chrome.runtime.lastError ? { ok: false, error: chrome.runtime.lastError.message } : { ok: true }); });
    } else reply({ ok: false, error: "unknown greeting" });
    return async;
  });

  chrome.runtime.onMessage.addListener(function (message, sender, reply) {
    if (!message || message.type !== "cobrinhaDownloadUpdate") return false;
    var url = String(message.url || "");
    var version = String(message.version || "nova").replace(/[^0-9A-Za-z._-]/g, "-");
    if (!/^https:\/\//i.test(url)) {
      reply({ ok: false, error: "Endereço de atualização inválido." });
      return false;
    }
    chrome.downloads.download({
      url: url,
      filename: "Cobrinha-Encasquetada-v" + version + ".zip",
      conflictAction: "uniquify",
      saveAs: false
    }, function (downloadId) {
      if (chrome.runtime.lastError || !downloadId) {
        reply({ ok: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message || "Falha ao iniciar o download." });
      } else {
        reply({ ok: true, downloadId: downloadId });
      }
    });
    return true;
  });
})();
