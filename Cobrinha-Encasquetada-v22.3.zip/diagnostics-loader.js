(function () {
  "use strict";

  var script = document.createElement("script");
  script.src = chrome.runtime.getURL("diagnostics-page.js");
  script.dataset.cobrinhaDiagnostic = "1";
  script.onload = function () { script.remove(); };
  script.onerror = function () {
    console.error("[COBRINHA][DIAGNÓSTICO] Não foi possível instalar o capturador de erros da página.");
  };
  (document.head || document.documentElement).appendChild(script);
})();
