(function () {
  "use strict";

  var STATE_KEY = "cobrinhaPanelStateV1";
  var GAP_KEY = "cobrinhaPanelGapV1";
  var TEAM_MODE_KEY = "cobrinhaTeamPanelMode";
  var BOX_MODE_KEY = "cobrinhaBoxVisualMode";
  var state = loadState();
  var resizeObservers = {};
  var saveTimer = 0;

  function loadState() {
    try {
      var saved = JSON.parse(localStorage.getItem(STATE_KEY) || "{}");
      return saved && typeof saved === "object" ? saved : {};
    } catch (error) {
      return {};
    }
  }

  function saveStateSoon() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      try { localStorage.setItem(STATE_KEY, JSON.stringify(state)); } catch (error) {}
    }, 120);
  }

  function panelState(name) {
    if (!state[name]) state[name] = {};
    return state[name];
  }

  function updateButton(button, collapsed) {
    button.textContent = collapsed ? "+" : "−";
    button.title = collapsed ? "Expandir painel" : "Minimizar painel";
    button.setAttribute("aria-label", button.title);
  }

  function togglePanel(panel, name, button) {
    var saved = panelState(name);
    var collapsing = !panel.classList.contains("cobrinha-panel-collapsed");
    if (collapsing) {
      saved.width = Math.round(panel.getBoundingClientRect().width) + "px";
      saved.height = Math.round(panel.getBoundingClientRect().height) + "px";
    }
    saved.collapsed = collapsing;
    panel.classList.toggle("cobrinha-panel-collapsed", collapsing);
    if (!collapsing) {
      if (saved.width) panel.style.width = saved.width;
      if (saved.height) panel.style.height = saved.height;
    }
    updateButton(button, collapsing);
    saveStateSoon();
  }

  function observeSize(panel, name) {
    if (typeof ResizeObserver !== "function") return;
    if (resizeObservers[name] && resizeObservers[name].panel === panel) return;
    if (resizeObservers[name]) resizeObservers[name].observer.disconnect();
    var observer = new ResizeObserver(function () {
      if (panel.classList.contains("cobrinha-panel-collapsed")) return;
      if (name === "team" && panel.classList.contains("cobrinha-team-minimal")) return;
      var rect = panel.getBoundingClientRect();
      if (rect.width < 1 || rect.height < 1) return;
      var saved = panelState(name);
      saved.width = Math.round(rect.width) + "px";
      saved.height = Math.round(rect.height) + "px";
      saveStateSoon();
    });
    resizeObservers[name] = { panel: panel, observer: observer };
    observer.observe(panel);
  }

  function applySavedPanelState(panel, name) {
    if (panel.dataset.cobrinhaPanelState === "1") return;
    panel.dataset.cobrinhaPanelState = "1";
    var saved = panelState(name);
    if (saved.width) panel.style.width = saved.width;
    if (saved.height && !saved.collapsed) panel.style.height = saved.height;
    if (saved.left != null && saved.top != null) {
      panel.style.left = saved.left;
      panel.style.top = saved.top;
      panel.style.right = "auto";
      panel.style.bottom = "auto";
    }
    panel.style.setProperty("--cobrinha-panel-opacity", String(saved.opacity == null ? 1 : saved.opacity));
    panel.classList.toggle("cobrinha-panel-collapsed", saved.collapsed === true);
    observeSize(panel, name);
  }

  function makeToggle(panel, name) {
    var button = panel.querySelector(":scope > .cobrinha-panel-toggle");
    if (!button) {
      button = document.createElement("button");
      button.type = "button";
      button.className = "cobrinha-panel-toggle";
      button.addEventListener("mousedown", function (event) {
        event.preventDefault();
        event.stopPropagation();
      });
      button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();
        togglePanel(panel, name, button);
      });
      panel.appendChild(button);
    }
    updateButton(button, panel.classList.contains("cobrinha-panel-collapsed"));
  }

  function makeOpacityControl(panel, name) {
    var input = panel.querySelector(":scope > .cobrinha-panel-opacity");
    var saved = panelState(name);
    if (!input) {
      input = document.createElement("input");
      input.type = "range";
      input.className = "cobrinha-panel-opacity";
      input.min = "0.3";
      input.max = "1";
      input.step = "0.05";
      input.title = "Opacidade do painel";
      input.setAttribute("aria-label", input.title);
      input.addEventListener("pointerdown", function (event) { event.stopPropagation(); });
      input.addEventListener("mousedown", function (event) { event.stopPropagation(); });
      input.addEventListener("click", function (event) { event.stopPropagation(); });
      input.addEventListener("input", function (event) {
        event.stopPropagation();
        var opacity = Math.max(0.3, Math.min(1, Number(input.value) || 1));
        panel.style.setProperty("--cobrinha-panel-opacity", String(opacity));
        panelState(name).opacity = opacity;
        saveStateSoon();
      });
      panel.appendChild(input);
    }
    input.value = String(saved.opacity == null ? 1 : saved.opacity);
  }

  function savePanelPosition(panel, name) {
    var saved = panelState(name);
    saved.left = panel.style.left;
    saved.top = panel.style.top;
    saveStateSoon();
    if (name === "shortcuts" || name === "chat") {
      try {
        var info = JSON.parse(localStorage.getItem("infobox") || "{}");
        if (!info || typeof info !== "object") info = {};
        var key = name === "shortcuts" ? "eemenu" : "bchat";
        if (!info[key]) info[key] = {};
        info[key].left = panel.style.left;
        info[key].top = panel.style.top;
        info[key].right = "";
        info[key].bottom = "";
        localStorage.setItem("infobox", JSON.stringify(info));
      } catch (error) {}
    }
  }

  function enableDrag(panel, name, handle) {
    if (!handle || handle.dataset.cobrinhaDrag === "1") return;
    handle.dataset.cobrinhaDrag = "1";
    handle.addEventListener("pointerdown", function (event) {
      if (event.button !== 0 || event.target.closest && event.target.closest("button, input")) return;
      event.preventDefault();
      event.stopPropagation();
      var rect = panel.getBoundingClientRect();
      var offsetX = event.clientX - rect.left;
      var offsetY = event.clientY - rect.top;
      panel.style.left = Math.round(rect.left) + "px";
      panel.style.top = Math.round(rect.top) + "px";
      panel.style.right = "auto";
      panel.style.bottom = "auto";
      panel.classList.add("cobrinha-panel-dragging");

      function move(moveEvent) {
        moveEvent.preventDefault();
        moveEvent.stopPropagation();
        var maxLeft = Math.max(0, window.innerWidth - panel.offsetWidth);
        var maxTop = Math.max(0, window.innerHeight - panel.offsetHeight);
        var left = Math.max(0, Math.min(maxLeft, moveEvent.clientX - offsetX));
        var top = Math.max(0, Math.min(maxTop, moveEvent.clientY - offsetY));
        panel.style.left = Math.round(left) + "px";
        panel.style.top = Math.round(top) + "px";
      }

      function finish(finishEvent) {
        if (finishEvent) finishEvent.stopPropagation();
        document.removeEventListener("pointermove", move, true);
        document.removeEventListener("pointerup", finish, true);
        document.removeEventListener("pointercancel", finish, true);
        panel.classList.remove("cobrinha-panel-dragging");
        savePanelPosition(panel, name);
      }

      document.addEventListener("pointermove", move, true);
      document.addEventListener("pointerup", finish, true);
      document.addEventListener("pointercancel", finish, true);
    });
  }

  function makeDragHandle(panel, name) {
    var handle = panel.querySelector(":scope > .cobrinha-panel-drag-handle");
    if (!handle) {
      handle = document.createElement("div");
      handle.className = "cobrinha-panel-drag-handle";
      handle.title = "Arraste para mover o painel";
      panel.appendChild(handle);
    }
    enableDrag(panel, name, handle);
  }

  function prepareShortcutPanel() {
    var panel = document.getElementById("eemenu");
    if (!panel) return false;
    separateShortcutRows(panel);
    applySavedPanelState(panel, "shortcuts");
    makeToggle(panel, "shortcuts");
    makeOpacityControl(panel, "shortcuts");
    makeDragHandle(panel, "shortcuts");
    return true;
  }

  function separateShortcutRows(panel) {
    Array.prototype.forEach.call(panel.querySelectorAll(".eem"), function (key, index) {
      if (index === 0) return;
      var before = key.previousSibling;
      if (!before || before.nodeType !== 3) return;
      var text = before.nodeValue || "";
      var bracket = text.lastIndexOf("[");
      if (bracket < 0) return;
      var previous = before.previousSibling;
      if (text === "[" && previous && previous.nodeName === "BR") return;
      before.nodeValue = text.slice(0, bracket).replace(/[ \t]+$/, "");
      var line = document.createElement("br");
      line.className = "cobrinha-shortcut-line";
      key.parentNode.insertBefore(line, key);
      key.parentNode.insertBefore(document.createTextNode("["), key);
    });
  }

  function prepareChatPanel() {
    var panel = document.getElementById("bchat");
    if (!panel) return false;
    applySavedPanelState(panel, "chat");
    var bar = panel.querySelector(":scope > .cobrinha-chat-bar");
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "cobrinha-chat-bar";
      bar.textContent = "Mensagens e informações";
      panel.insertBefore(bar, panel.firstChild);
    }
    makeChatExitButton(panel);
    makeToggle(panel, "chat");
    makeOpacityControl(panel, "chat");
    enableDrag(panel, "chat", bar);
    return true;
  }

  function releaseChatFocus() {
    var input = document.getElementById("ichat");
    if (!input) return;
    try {
      if (window.jQuery && jQuery.data(input, "emojiPicker")) jQuery(input).emojiPicker("hide");
    } catch (error) {}
    try { input.blur(); } catch (error) {}
    setTimeout(function () {
      try { input.blur(); } catch (error) {}
      try { window.focus(); } catch (error) {}
    }, 0);
  }

  function makeChatExitButton(panel) {
    var button = panel.querySelector(":scope > .cobrinha-chat-exit");
    if (button) return;
    button = document.createElement("button");
    button.type = "button";
    button.className = "cobrinha-chat-exit";
    button.textContent = "Sair";
    button.title = "Sair do chat e devolver as teclas ao jogo";
    button.setAttribute("aria-label", button.title);
    button.addEventListener("pointerdown", function (event) {
      event.preventDefault();
      event.stopPropagation();
    });
    button.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      releaseChatFocus();
    });
    panel.appendChild(button);
  }

  function prepareTeamPanel() {
    var panel = document.getElementById("lovable-team-panel");
    if (!panel) return false;
    applySavedPanelState(panel, "team");
    applyTeamPanelMode(panel);
    makeToggle(panel, "team");
    makeOpacityControl(panel, "team");
    enableDrag(panel, "team", panel.querySelector(":scope > .lovable-team-title"));
    return true;
  }

  function currentTeamPanelMode() {
    try { return localStorage.getItem(TEAM_MODE_KEY) === "minimal" ? "minimal" : "full"; }
    catch (error) { return "full"; }
  }

  function currentBoxVisualMode() {
    try { return localStorage.getItem(BOX_MODE_KEY) === "minimal" ? "minimal" : "standard"; }
    catch (error) { return "standard"; }
  }

  function applyBoxVisualMode() {
    document.documentElement.classList.toggle("cobrinha-boxes-minimal", currentBoxVisualMode() === "minimal");
  }

  function applyTeamPanelMode(panel) {
    panel = panel || document.getElementById("lovable-team-panel");
    if (!panel) return;
    panel.classList.toggle("cobrinha-team-minimal", currentTeamPanelMode() === "minimal");
  }

  function applyPanelGap() {
    try { if (localStorage.getItem(GAP_KEY) === "1") return true; } catch (error) {}
    var shortcuts = document.getElementById("eemenu");
    var chat = document.getElementById("bchat");
    if (!shortcuts || !chat) return false;

    var shortcutTop = parseFloat(shortcuts.style.top) || 4;
    var shortcutHeight = shortcuts.offsetHeight || parseFloat(shortcuts.style.height) || 215;
    var chatTop = parseFloat(chat.style.top) || 220;
    var requiredChatTop = shortcutTop + shortcutHeight + 12;
    if (chatTop < requiredChatTop) {
      chatTop = requiredChatTop;
      chat.style.top = Math.round(chatTop) + "px";
    }

    var details = document.getElementById("divtl");
    if (details) {
      var chatHeight = chat.offsetHeight || parseFloat(chat.style.height) || 230;
      var detailsTop = parseFloat(details.style.top) || 450;
      var requiredDetailsTop = chatTop + chatHeight + 12;
      if (detailsTop < requiredDetailsTop) details.style.top = Math.round(requiredDetailsTop) + "px";
    }

    try {
      var info = JSON.parse(localStorage.getItem("infobox") || "{}");
      if (!info || typeof info !== "object") info = {};
      if (!info.bchat) info.bchat = {};
      info.bchat.top = chat.style.top;
      if (details) {
        if (!info.divtl) info.divtl = {};
        info.divtl.top = details.style.top;
      }
      localStorage.setItem("infobox", JSON.stringify(info));
      localStorage.setItem(GAP_KEY, "1");
    } catch (error) {}
    return true;
  }

  function prepareAll() {
    var shortcutsReady = prepareShortcutPanel();
    var chatReady = prepareChatPanel();
    prepareTeamPanel();
    if (shortcutsReady && chatReady) applyPanelGap();
    return shortcutsReady && chatReady;
  }

  function resetWindowLayout() {
    clearTimeout(saveTimer);
    state = {};
    Object.keys(resizeObservers).forEach(function (name) {
      resizeObservers[name].observer.disconnect();
    });
    resizeObservers = {};
    try {
      localStorage.removeItem(STATE_KEY);
      localStorage.removeItem(GAP_KEY);
      localStorage.removeItem("infobox");
    } catch (error) {}
    location.reload();
  }

  function createLayoutResetControl() {
    if (!document.body || document.getElementById("cobrinha-layout-gear")) return;

    var gear = document.createElement("button");
    gear.id = "cobrinha-layout-gear";
    gear.type = "button";
    gear.textContent = "⚙";
    gear.title = "Ajustar janelas";
    gear.setAttribute("aria-label", gear.title);

    var popup = document.createElement("section");
    popup.id = "cobrinha-layout-popup";
    popup.hidden = true;
    popup.setAttribute("role", "dialog");
    popup.setAttribute("aria-label", "Ajustes das janelas");

    var title = document.createElement("strong");
    title.textContent = "Janelas da interface";
    var description = document.createElement("p");
    description.textContent = "Escolha o visual dos painéis ou restaure seus tamanhos e posições.";

    var boxMode = document.createElement("label");
    boxMode.className = "cobrinha-layout-team-mode";
    var boxModeText = document.createElement("span");
    boxModeText.textContent = "Todos os painéis";
    var boxModeSelect = document.createElement("select");
    var standardBoxOption = document.createElement("option");
    standardBoxOption.value = "standard";
    standardBoxOption.textContent = "Padrão";
    var minimalBoxOption = document.createElement("option");
    minimalBoxOption.value = "minimal";
    minimalBoxOption.textContent = "Minimalista";
    boxModeSelect.appendChild(standardBoxOption);
    boxModeSelect.appendChild(minimalBoxOption);
    boxModeSelect.value = currentBoxVisualMode();
    boxMode.appendChild(boxModeText);
    boxMode.appendChild(boxModeSelect);

    var teamMode = document.createElement("label");
    teamMode.className = "cobrinha-layout-team-mode";
    var teamModeText = document.createElement("span");
    teamModeText.textContent = "Equipe — sala";
    var teamModeSelect = document.createElement("select");
    var fullOption = document.createElement("option");
    fullOption.value = "full";
    fullOption.textContent = "Completa";
    var minimalOption = document.createElement("option");
    minimalOption.value = "minimal";
    minimalOption.textContent = "Minimalista";
    teamModeSelect.appendChild(fullOption);
    teamModeSelect.appendChild(minimalOption);
    teamModeSelect.value = currentTeamPanelMode();
    teamMode.appendChild(teamModeText);
    teamMode.appendChild(teamModeSelect);
    var reset = document.createElement("button");
    reset.type = "button";
    reset.className = "cobrinha-layout-reset";
    reset.textContent = "Redefinir janelas";

    var confirmation = document.createElement("div");
    confirmation.className = "cobrinha-layout-confirmation";
    confirmation.hidden = true;
    var question = document.createElement("span");
    question.textContent = "Confirmar redefinição?";
    var actions = document.createElement("div");
    var cancel = document.createElement("button");
    cancel.type = "button";
    cancel.textContent = "Cancelar";
    var confirm = document.createElement("button");
    confirm.type = "button";
    confirm.className = "is-confirm";
    confirm.textContent = "Confirmar";
    actions.appendChild(cancel);
    actions.appendChild(confirm);
    confirmation.appendChild(question);
    confirmation.appendChild(actions);

    popup.appendChild(title);
    popup.appendChild(description);
    popup.appendChild(boxMode);
    popup.appendChild(teamMode);
    popup.appendChild(reset);
    popup.appendChild(confirmation);
    document.body.appendChild(popup);
    document.body.appendChild(gear);

    gear.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      popup.hidden = !popup.hidden;
      confirmation.hidden = true;
      reset.hidden = false;
    });
    popup.addEventListener("click", function (event) { event.stopPropagation(); });
    boxModeSelect.addEventListener("change", function () {
      try { localStorage.setItem(BOX_MODE_KEY, boxModeSelect.value === "minimal" ? "minimal" : "standard"); } catch (error) {}
      applyBoxVisualMode();
    });
    teamModeSelect.addEventListener("change", function () {
      try { localStorage.setItem(TEAM_MODE_KEY, teamModeSelect.value === "minimal" ? "minimal" : "full"); } catch (error) {}
      applyTeamPanelMode();
    });
    reset.addEventListener("click", function () {
      reset.hidden = true;
      confirmation.hidden = false;
    });
    cancel.addEventListener("click", function () {
      confirmation.hidden = true;
      reset.hidden = false;
    });
    confirm.addEventListener("click", resetWindowLayout);
    document.addEventListener("click", function () {
      popup.hidden = true;
      confirmation.hidden = true;
      reset.hidden = false;
    });
  }

  function updateLayoutResetVisibility() {
    createLayoutResetControl();
    var gear = document.getElementById("cobrinha-layout-gear");
    var popup = document.getElementById("cobrinha-layout-popup");
    var login = document.getElementById("login");
    if (!gear) return;
    var visible = false;
    if (login) {
      var style = getComputedStyle(login);
      var rect = login.getBoundingClientRect();
      visible = style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity || 1) > 0.05 && rect.width > 0 && rect.height > 0;
    }
    gear.hidden = !visible;
    if (!visible && popup) popup.hidden = true;
  }

  new MutationObserver(function (changes) {
    var relevant = changes.some(function (change) {
      return change.target && (change.target.id === "eemenu" || change.target.id === "bchat" || change.target.id === "lovable-team-panel") ||
        Array.prototype.some.call(change.addedNodes || [], function (node) {
          return node.nodeType === 1 && (node.id === "eemenu" || node.id === "bchat" || node.id === "lovable-team-panel" || node.querySelector && node.querySelector("#eemenu, #bchat, #lovable-team-panel"));
        });
    });
    if (relevant) setTimeout(prepareAll, 0);
  }).observe(document.documentElement, { childList: true, subtree: true });

  document.addEventListener("keydown", function (event) {
    var input = document.getElementById("ichat");
    if (input && document.activeElement === input && event.key === "Escape") {
      event.preventDefault();
      event.stopImmediatePropagation();
      releaseChatFocus();
    }
  }, true);

  document.addEventListener("pointerdown", function (event) {
    var input = document.getElementById("ichat");
    var chat = document.getElementById("bchat");
    if (input && chat && document.activeElement === input && !chat.contains(event.target)) releaseChatFocus();
  }, true);

  var attempts = 0;
  var timer = setInterval(function () {
    if (prepareAll() || ++attempts > 240) clearInterval(timer);
  }, 50);

  applyBoxVisualMode();
  updateLayoutResetVisibility();
  setInterval(updateLayoutResetVisibility, 300);
})();
