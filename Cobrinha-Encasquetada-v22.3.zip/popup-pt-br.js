(function () {
  "use strict";
  const traducoes = {
    "WebGL off": "WebGL desativado",
    "WebGL ready": "WebGL pronto",
    "WebGL init…": "Iniciando WebGL…",
    "2D mode": "Modo 2D",
    "no tabs api": "API de abas indisponível",
    "no active tab": "nenhuma aba ativa",
    "not on slither": "abra o slither.io",
    "mod not loaded": "mod não carregado",
    "no reply": "sem resposta",
    "send failed": "falha no envio",
    "checking…": "verificando…"
  };
  function traduzir() {
    const status = document.getElementById("cobrinha-status-text");
    if (!status) return;
    const sufixo = " (but user disabled)";
    const valor = status.textContent;
    if (valor.endsWith(sufixo)) {
      status.textContent = (traducoes[valor.slice(0, -sufixo.length)] || valor.slice(0, -sufixo.length)) + " (desativado pelo usuário)";
    } else if (traducoes[valor]) {
      status.textContent = traducoes[valor];
    }
  }
  addEventListener("DOMContentLoaded", function () {
    traduzir();
    const status = document.getElementById("cobrinha-status-text");
    if (status) new MutationObserver(traduzir).observe(status, { childList: true, characterData: true, subtree: true });
  });
})();
